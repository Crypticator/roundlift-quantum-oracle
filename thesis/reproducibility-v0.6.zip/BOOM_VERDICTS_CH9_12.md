# Verdict scientifique final · Thèse II

**V0.5 reçue, 90 pages — TAMPON CONDITIONNEL. V0.6 corrigée, douze chapitres, 91 pages — TAMPON SCIENTIFIQUE.**

| Chapitre | Verdict V0.6 | Motif décisif |
|---|---|---|
| 1 · Introduction | TAMPON SCIENTIFIQUE | Les contributions, les sources et le modèle étudié sont délimités. |
| 2 · Quotient et reste | TAMPON SCIENTIFIQUE | La bijection des fibres et les identités de retenue ont les hypothèses requises. |
| 3 · Algèbre structurée | TAMPON SCIENTIFIQUE | Les signes négacycliques et les dépendances des blocs sont conservés. |
| 4 · Spécification | TAMPON SCIENTIFIQUE | Pièces, seuils et encodages déterminent une expérience reproductible. |
| 5 · Correction | TAMPON SCIENTIFIQUE | Témoin légal et certificat rationnel établissent les deux bornes sur la moyenne des maxima par clé. |
| 6 · IND-CPA | TAMPON SCIENTIFIQUE | Les deux hybrides conservent le relèvement conditionnel et le secret commun. |
| 7 · Cryptanalyse | TAMPON SCIENTIFIQUE | Les points MATZOV et coded-dual sont attribués à leur modèle et à leur exécution documentée. |
| 8 · FO classique | TAMPON SCIENTIFIQUE | La composition est justifiée dans le ROM classique à défi initial, avec son budget de requêtes. |
| 9 · QROM | TAMPON SCIENTIFIQUE | Couplage de rejet cohérent et substitution à HHM vérifiés, sous les deux hypothèses sources et aux ressources indiquées. |
| 10 · Recherche d’échecs | TAMPON SCIENTIFIQUE | Jeux NK et NG spécifiés, dépendances préservées, second moment certifié en arithmétique entière. |
| 11 · Registre des preuves et coûts | TAMPON SCIENTIFIQUE | Chiffres reproduits ou identifiés comme historiques, vérificateur du supplément réparé. |
| 12 · Conclusions | TAMPON SCIENTIFIQUE | Tirage frais à l’encapsulation rétabli dans la synthèse ; les problèmes ouverts restent explicités. |

Les quatre nouveaux chapitres appelaient respectivement en V0.5 une justification plus explicite de l’import HHM, une correction de définition de jeu, une réparation du supplément et une correction de spécification dans la conclusion. Les critères et leur vérification sont consignés dans le rapport et le tableau des corrections. Pour les huit premiers chapitres, la comparaison avec la base V0.4 et les preuves et calculs de cette base fondent la continuité de la décision.

**Portée.** Ce verdict de lecture scientifique porte sur les énoncés du manuscrit et le supplément joint. La réduction QROM est mono-utilisateur, avec oracles idéaux frais, clé remise avant les requêtes et décapsulation classique après le défi. Restent ouverts la difficulté quantitative des sources, le transfert FFP-NG à la construction complète, la sécurité de SHAKE256 dans ce rôle et une certification postquantique à 128 bits. L’évaluation ne constitue pas une soutenance institutionnelle ni une décision d’éditeur.

**PDF auquel ce verdict est attaché, SHA-256**

`d79e79a2ea313f047ad43df5624e5a29f907d8ce0a4f39c37e44bbd28128c0af`
