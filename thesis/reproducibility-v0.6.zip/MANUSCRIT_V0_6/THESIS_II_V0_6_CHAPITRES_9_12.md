---
title: 'From Correctness to the Quantum Oracle'
subtitle: 'Exact Modular Rounding, Structured Cryptanalysis, and Conditional Security of C1-K4'
author: 'Samir Bouftass'
date: 'Chapters 9–12 — 18 November 2026 — Version 0.6'
lang: en-US
documentclass: report
classoption: [oneside]
fontsize: 11pt
papersize: a4
geometry:
  - top=29mm
  - bottom=28mm
  - left=30mm
  - right=28mm
colorlinks: true
linkcolor: MidnightBlue
urlcolor: MidnightBlue
toc: true
toc-depth: 2
numbersections: true
header-includes: |
  \usepackage{amsmath,amssymb,amsthm,mathtools}
  \usepackage{microtype}
  \usepackage{booktabs}
  \usepackage{enumitem}
  \usepackage{fancyhdr}
  \usepackage{float}
  \definecolor{MidnightBlue}{RGB}{20,51,87}
  \fancypagestyle{plain}{\fancyhf{}\fancyfoot[C]{\thepage}\renewcommand{\headrulewidth}{0pt}}
  \pagestyle{fancy}
  \fancyhf{}
  \fancyhead[L]{\small From Correctness to the Quantum Oracle}
  \fancyhead[R]{\small Thesis II · Version 0.6}
  \fancyfoot[C]{\thepage}
  \setlength{\headheight}{14pt}
  \setlist{itemsep=0.2em,topsep=0.35em}
  \emergencystretch=2em
  \newtheorem{thm}{Theorem}[chapter]
  \newtheorem{lemma}[thm]{Lemma}
  \newtheorem{prop}[thm]{Proposition}
  \newtheorem{definition}[thm]{Definition}
---

\setcounter{chapter}{8}

# The Quantum Random-Oracle Boundary: A Conservative Conditional Route

## What changes when an oracle becomes quantum accessible

The classical argument in Chapter 8 makes a sequence of public and private computations while observing an adversary that submits ordinary strings to ideal hash functions. A quantum random oracle is not an ordinary table accessed only through classical calls. If $H:\mathcal X\to\{0,1\}^{\ell}$ is a sampled function, the adversary receives the unitary evaluation interface

$$
U_H:\ |x\rangle|y\rangle\longmapsto|x\rangle|y\oplus H(x)\rangle,
$$

and may evaluate $U_H$ on a superposition of addresses. A proof that programs one address *after* observing some oracle queries must specify the indistinguishability loss of that intervention. Merely remarking that a random 256-bit address is unlikely to have been sampled classically does not suffice. Conversely, a finite patch chosen and installed *before* a fresh quantum adversary is given its oracle does not involve retrospective reprogramming.

This chapter gives a single-user quantum random-oracle reduction for the frozen C1-K4 construction. Proposition 9.2 concerns the two exact CBD1 Module-LWE distributions. Lemma 9.5 links the ciphertext-dependent key derivation and implicit fallback to the explicitly rejecting reference transform. Theorem 9.6 then applies the extractable-oracle result of Hövelmanns, Hülsing and Majenz [R2] to this experiment.

## The complete key-first experiment

**Definition 9.1 (single-user key-first QROM IND-CCA experiment).** Independently sample the ideal matrix oracle $H_A$, the encryption-tape oracle $G$, and the KDF oracle $H$, with injective domain encodings and distinct oracle-family prefixes. Generate one C1-K4 key pair in that environment, with a fresh uniform 256-bit fallback secret $z$. Give the public key to the adversary *before its first oracle query*. The adversary may issue quantum queries to $H_A,G,H$ and classical decapsulation queries, may retain quantum workspace, and chooses two classical 256-bit challenge messages only in the associated PKE subexperiments. In the KEM experiment the challenger samples the encapsulation message $m_*$ uniformly and returns a classical challenge ciphertext $c_*$ together with either the real 256-bit KDF output or an independent random key. The adversary must output a classical bit. The exact challenge ciphertext $c_*$ may not be submitted for decapsulation after challenge delivery.

The adversary has no *earlier* queries or auxiliary advice correlated with the same sampled oracle tables. Its independent side information may be quantum, but the freshness condition is substantive. Oracle domains for $H_A$, $G$ and $H$ are pairwise separated even if an implementation were to use the same primitive under different prefixes. The good and fallback KDF inputs are **not** given artificial branch separators: both are evaluated by $H(pk,\cdot,c)$, as the frozen algorithm specifies.

To prevent an unnoticed change of adversarial power, we make the interface explicit.

| Interface | Input and reply | Allowed adversarial use | Excluded extension |
|---|---|---|---|
| Matrix oracle $H_A$ | Indexed 512-byte responses | Quantum, after $pk$ | Previously fixed oracle-correlated advice |
| Tape oracle $G$ | Encoded $(pk,m)$ to 2816 bytes | Quantum | An oracle with a different tape distribution |
| Key oracle $H$ | Encoded $(pk,m,c)$ to 32 bytes | Quantum | Artificially split good/fallback oracle families |
| Decapsulation | Classical ciphertext byte string to 32 bytes | Classical and adaptive | Quantum superposition of ciphertexts |
| Challenge | A classical 1760-byte ciphertext and key challenge | Once; challenge-first with respect to decapsulation in the reference game | Multi-user or arbitrary pre-challenge decapsulation |

The reference challenger may generate the independent encapsulation challenge when it generates the key and the simulator may withhold it during any initial hash-query phase. Evaluation at the hidden address uses the already sampled functions. Before delivery no decapsulation is allowed. The challenge-first restriction should not be confused with the key-first restriction: the public key comes before *any* oracle call, while the challenge arrives before the decapsulation part of the reference experiment. The latter matters for the application of [R2]. The restriction cannot be removed merely by citing a separate collision estimate.

For source $j\in\{4,5\}$, define a **quantum** decision gap $\epsilon_{4,j}^{Q}(T,\mathbf q)$ for distinguishing $(B,Bt+e)$ from $(B,y)$ with $B\leftarrow U(R^{j\times4})$, $t\leftarrow\chi^{1024}$ and $e\leftarrow\chi^{256j}$. The bound must apply to the *constructed* source distinguisher, including its run time, auxiliary quantum oracles and classical arithmetic. It is not the cost estimate of an attack algorithm and is not an assertion that every such distinguisher is inefficient.

## Reusing the passive hybrids without cloning quantum state

The two hybrids of Chapter 6 are classical data transformations applied to the challenge of a quantum adversary. A source distinguisher need not rewind or copy the adversary's state: it embeds its single source sample, runs the adversary once, and measures the final classical decision. In the first transition it gives $A$ together with $F_4(y)$. In the second, it partitions a five-row source matrix into $(A^T;V^T)$, publishes $(A,F_4(V))$ and forms the challenge from the five source response rows. The same source secret is used in all five rows. Because $V\leftrightarrow(F_4(V),[V]_4)$ is a bijection, the hidden remainder is uniform *conditioned on the published matrix and quotient $(A,F_4(V))$, before the challenge response is formed* as a consequence of the uniform five-row *matrix* law in both response branches. In the structured branch the response also depends on this same $V$.

A subtler point is the 32-byte seed in the compact public key. At the start of the reduction the simulator receives the source matrix $A$, selects a new seed $\sigma$, and installs the raw outputs associated with $\sigma$ into the otherwise fresh oracle $H_A$. Each 12-bit coefficient of $A$ is completed to a 16-bit raw word by four independently uniform high bits. Distinct $(\sigma,i,j)$ addresses are encoded injectively, so the 16 matrix-polynomial responses are jointly uniform with their exact raw-word distribution. The quantum adversary is then invoked *after* this random function has been defined.

This is a distributional coupling, not a proof that SHAKE256 behaves as an independent oracle. No oracle is changed after a query. A coherent implementation can compare an address with the finite programmed set, compute the appropriate raw word through a reversible table evaluation, XOR it into the answer register and uncompute the comparison. The extra reversible gates, memory and calls to the remaining oracle must be charged to $\epsilon_{4,j}^{Q}$.

**Proposition 9.2 (conditional quantum passive transfer).** In the fresh, key-first ideal-oracle model, if the two source quantum gaps at the augmented budgets are bounded by $\epsilon_{4,4}^{Q}$ and $\epsilon_{4,5}^{Q}$, then

$$
\operatorname{Adv}^{Q}_{\mathrm{CPA,bias}}\le
\epsilon_{4,4}^{Q}+\epsilon_{4,5}^{Q}.
$$

The proof is the pair of joint-distribution simulations just described. It is conditional on the source gaps and on the specified fresh-oracle experiment. It does not inherit Chapter 6's classical *prior-query conflict term*, since the quantum simulation selects and patches the seed before the first adversarial oracle query. Allowing historical oracle queries would require a new analysis.

## Two structural properties independent of source hardness

**Lemma 9.3 (rigidity).** Let $\operatorname{Dec}_1$ decrypt and accept only if the exact canonical input ciphertext equals $\operatorname{Enc}_1(pk,m')$, where $m'$ was obtained by decryption. Then

$$
\operatorname{Dec}_1(sk,c)=m'\neq\bot
\quad\Longrightarrow\quad
c=\operatorname{Enc}_1(pk,m').
$$

This follows by definition of the exact re-encryption check. It is not equivalent to perfect correctness, and it does not assert that the map from all 2816-byte tapes to ciphertexts is injective. Indeed, ignored tape bits make that latter statement false.

**Lemma 9.4 (spreadness).** For any honestly generated public key $pk$, any fixed message $m$, and any ciphertext byte string $c$,

$$
\Pr_{\omega}[\operatorname{Enc}(pk,m;\omega)=c]
\le\left(\frac34\right)^{1280}.
$$

To prove it, fix $r$ and the full lift vector $\rho$. Each coefficient of $e_1$ enters one of the 1024 components of $c_1$ and each coefficient of $e_2$ enters one of the 256 components of $c_2$, after a deterministic pre-error offset. The three possibilities $x-1,x,x+1$ under CBD1 have weights $1/4,1/2,1/4$; any floor cell of width two contains at most weight $3/4$, including when the modulus wraps. All 1280 error coefficients are still independent under this conditioning. Multiply the individual masses and then average over $(r,\rho)$. Therefore the spreadness exponent is

$$
\gamma\ge1280\log_2(4/3)
=531.247999\ldots.
$$

This lemma describes the randomized encryption distribution. A *deterministic* encryption with its oracle-derived tape fixed does not have this spreadness bound as an additional independent randomness source.

## The exact good/fallback graph under coherent access

Let $(pk_*,sk_*)$ be the reference challenge key. An explicitly rejecting reference transform uses a tape oracle $g(m)$ and a key oracle $h(m)$, together with deterministic encryption

$$
E(m)=\operatorname{Enc}(pk_*,m;g(m)).
$$

For the target prefix the reference $g$ outputs a uniform full tape and $h$ outputs a uniform key. A fresh secret $z$ is sampled independently of the reference experiment and kept for all simulated decapsulations. Its accepted decapsulation returns $h(m)$ and its rejected decapsulation returns $\bot$. To simulate the **actual** ciphertext-dependent and implicitly rejecting C1-K4 KEM, sample independent auxiliary random oracles $G_0(pk,m)$ and $H_0(pk,m,c)$ and define

$$
\widehat G(pk,m)=
\begin{cases}
 g(m),&pk=pk_*,\\
 G_0(pk,m),&pk\neq pk_*;
\end{cases}
$$

$$
\widehat H(pk,m,c)=
\begin{cases}
 h(m),&pk=pk_*\ \text{and}\ c=E(m),\\
 H_0(pk,m,c),&\text{otherwise}.
\end{cases}
$$

**Lemma 9.5 (conditional graph-oracle coupling).** Conditioned on the table of $g$ and on the complete key/matrix environment, $\widehat H$ is a uniform random function on its encoded domain, independent of $\widehat G$; the pair has the target joint law. Further, the target adversary's oracle queries can be simulated coherently and its *classical* decapsulation transcript has exactly the implicit-rejection law.

*Proof.* Define the graph $\mathcal G=\{(pk_*,m,E(m)):m\in\{0,1\}^{256}\}$. Two distinct messages have different graph addresses because the message is explicitly part of the address, even if their ciphertexts collide. Conditional on $g$, each graph address receives an independent uniform $h(m)$, and each nongraph address receives an independent uniform $H_0$ value. Hence every finite collection of distinct addresses has the product-uniform law. This conditional law is unchanged by the graph itself, so $\widehat H$ is independent of $g$ and of the independent off-prefix $G_0$ table as well, and hence of $\widehat G$. The matrix-oracle environment is preserved on both sides.

For quantum evaluation, reversibly compute the predicate $[pk=pk_*\wedge c=E(m)]$ using coherent access to $g$ and to the fixed matrix oracle. Obtain a candidate answer from $h(m)$ on the graph branch and from $H_0(pk,m,c)$ on the other branch. XOR the selected value into the output register. Reverse all computations and uncompute the temporary predicates and candidate registers. Because no measurement is used, linearity proves correctness on arbitrary superpositions. A repeated address has the same table value; when $m=z$ and a fallback address lies on the graph, the same $\widehat H$ value is used rather than an artificial independent fallback hash.

For a classical decapsulation query, forward the ciphertext to the explicit-rejection reference oracle. If it returns a key, rigidity implies that the ciphertext is $E(m')$ for its accepted message, and the reply equals $\widehat H(pk_*,m',c)$. If it rejects, the target reply is $\widehat H(pk_*,z,c)$ with the one sampled fallback secret $z$. Preserve the raw ciphertext byte string in the fallback hash even if parsing fails. The reference oracle's acceptance flag is never exposed directly to the target adversary. In the real-key branch the challenge key is $h(m_*)=\widehat H(pk_*,m_*,E(m_*))$. In the random-key branch the challenger supplies an independent uniform key with the same ciphertext. Thus the simulated and target transcripts have the same joint law. $\square$

The proof concerns ideal random functions and exact arithmetic in a reversible circuit. It does not furnish a reversible implementation with measured gate counts, nor does it establish the assumptions of an actual compiled hash function. The finite graph may be exponentially large as a mathematical oracle table; a reduction must charge the coherent cost of computing $E(m)$ rather than pretend to store it explicitly.

## Search for honest decryption failures

Let $K$ denote the entire honest key and matrix environment. Chapter 5 gives

$$
d(K)=\max_m\Pr_{\omega}[F(K,m,\omega)],
\qquad \delta_{wc}=\mathbb E_K[d(K)]<2^{-212},
$$

where $F$ is the honest decryption-failure event. Section 5.3 shows for this decoder that the all-one message realizes the maximum for each key, but the conservative QROM search argument needs only the displayed definition.

The extractable-oracle search result of Hövelmanns--Hülsing--Majenz [R2] bounds, for a fixed relation with maximum accepting oracle-output density $d$, the probability that an adversary with $u$ relevant oracle queries produces an accepting address by $152(u+1)^2 d$, capped at one. The published search lemma is Lemma 4, equation (30), while the cited full version uses Lemma 5, equation (51); its final evaluation contributes the $+1$. Extraction calls, oracle-table independence and the intended experiment are part of that theorem's hypotheses and cannot be erased when importing it.

For $c=\operatorname{Enc}(pk,m;g(m))$, a correct base decryption to $m$ always passes re-encryption with the same $g(m)$. If base decryption returns a different value, the checked decryption can only return that value or reject. Thus the failure predicate for the deterministic reference challenge is exactly the base failure predicate on the oracle tape. Fix $K$ *before* sampling the independent fresh tape oracle. Apply the search lemma to the relation $\{(m,\omega):F(K,m,\omega)\}$. The adversary may have $pk$ and may select $m$ adaptively; its fresh oracle output for a fixed address is distributed as an honest encryption tape. The density is at most $d(K)$ for every message. Averaging over $K$ and using the cap gives

$$
\begin{split}
\operatorname{Adv}^{\mathrm{FFP\text{-}CPA}}(u)
&\le\mathbb E_K\min\{1,152(u+1)^2d(K)\}\\
&\le\min\{1,152(u+1)^2\delta_{wc}\}.
\end{split}
$$

The worst-case-correctness alternative of Hövelmanns and Majenz [R11] provides further context. The constants used here come from [R2]. The right-hand side does **not** follow by naively replacing $\mathbb E_K\max_m$ with $\max_m\mathbb E_K$. The key is fixed only for the search-lemma argument and averaged afterwards. The estimate is an *upper bound on failure-finding success in the imported extractable-oracle setting*, not a theorem that every ciphertext is correctly decrypted.

## Composing the conservative conditional bound

Let $q_A,q_G,q_H,q_D$ be upper bounds on matrix-, tape-, KDF- and classical decapsulation calls made by the target quantum adversary. The graph simulation can conservatively make two reference-$g$ calls per target $G$ call, two reference-$g$ and two reference-$h$ calls per target $H$ call, and two of each per simulated fallback. Define

$$
Q_G=2(q_G+q_H+q_D),\qquad
Q_H=2(q_H+q_D),
$$

$$
R_Q=Q_G+Q_H,\qquad U_Q=R_Q+q_D.
$$

The symbol $R_Q$ denotes an oracle-query count, not the polynomial ring $R$. These allowances are deliberately conservative; they count compute--use--uncompute, do not assume gratis controlled calls, and do not include an explicit numerical circuit cost for every arithmetic step. The constructed source algorithms must pay for the additional matrix-oracle, extraction and auxiliary-oracle work.

**Theorem 9.6 (single-user conditional QROM bound).** Suppose the exact C1-K4 source problems have quantum distinguishing gaps bounded by $\epsilon_{4,4}^Q$ and $\epsilon_{4,5}^Q$ at the augmented resources used by the simulations. Assume the key-first, single-user, fresh ideal-oracle, challenge-first and classical-decapsulation interfaces of Definition 9.1, with independent matrix and auxiliary oracle interfaces available to the constructed algorithms and their calls charged to the resource budgets. Then the exact 1760-byte C1-K4 KEM satisfies the following conservative bound:

$$
\boxed{\begin{aligned}
\operatorname{Adv}^{Q}_{\mathrm{CCA,bias}}
\le\min\biggl\{\frac12,\;&
4\sqrt{2U_Q(\epsilon_{4,4}^Q+\epsilon_{4,5}^Q)}
+8U_Q\,2^{-128}\\
&+(q_D+1)\min\{1,152(U_Q+1)^2\,2^{-212}\}\\
&+24q_D(Q_G+4q_D)(3/4)^{640}
\biggr\}.
\end{aligned}}
$$

*Derivation and provenance.* Use [R2], full version, Corollary 8, equations (69)–(70), for the explicitly rejecting, message-only key derivation $\mathrm{FO}^{\bot}_m$ of its Figure 2. Figure 5 gives the ordinary classical challenge and decapsulation interface. Use the reductions relative to the independent matrix and auxiliary oracle families. All games share them, including public encryption and its reversible evaluation. Their gates act on separate tables from the compressed $g,h$ database, so they are available between queries. Their calls, time and memory count toward the constructed adversaries; the source gaps are those in this joint experiment. Lemma 9.5 supplies the explicit-rejection reference adversary, Lemma 9.4 supplies $\gamma$, and Section 9.6 supplies the failure relation. Let $d$ be the reference query depth and $w$ its width. Serializing gives $d\le R_Q$; the IND-CPA branch does not use the alternative OW-CPA term involving $w$. Its bound is

$$
\begin{aligned}
&4\sqrt{(d+q_D)\alpha_{\mathrm{CPA}}}+
8(Q_G+Q_H+q_D)/\sqrt{|\mathcal M|}\\
&\quad +(q_D+1)\operatorname{Adv}_{\mathrm{FFP\text{-}CPA}}
+24q_D(Q_G+4q_D)2^{-\gamma/2}.
\end{aligned}
$$

Here $\alpha_{\mathrm{CPA}}$ is an *acceptance-probability gap*, whereas the CPA quantity in Proposition 9.2 is a *success bias*, so $\alpha_{\mathrm{CPA}}\le2(\epsilon_{4,4}^Q+\epsilon_{4,5}^Q)$. For a fair bit, $|\Pr[\hat b=b]-1/2|=|\Pr[\hat b=1\mid b=1]-\Pr[\hat b=1\mid b=0]|/2$. The reference KEM advantage already uses success bias. Corollary 8 gives the failure adversary at most $U_Q$ calls to eCO.RO and $q_D$ to eCO.E. The search lemma charges the final output evaluation separately and allows these extraction queries. Use $d+q_D\le U_Q$, the message space $|\mathcal M|=2^{256}$, the search bound with $u=U_Q$ and $\delta_{wc}<2^{-212}$, and $2^{-\gamma/2}\le(3/4)^{640}$. The coupling in Lemma 9.5 transfers the reference-game bound to the exact good/fallback hash interface. The result is a direct restatement and parameter substitution of the V4.2 companion's conditional result, not a newly discovered independent quantum-security theorem.

The time overhead includes coherent C1-K4 re-encryption, matrix oracle expansion, the finite seed patch, address comparisons and the extractable-oracle simulation. A schematic ledger is

$$
T_{\mathrm{sim}}=O\big((q_G+q_H+q_D)T_{\mathrm{Enc}}+
(q_A+q_G+q_H+q_D)L_{\mathrm{cmp}}\big)
+T_{\mathrm{eCO}}(R_Q+q_D),
$$

plus arithmetic and source-simulation overhead. Extraction has a resource cost even though its query count does not enter the density multiplier. The source budgets include the quantum workspace for the compressed database and reversible encryption. For variable-length raw ciphertexts the time bound uses the longest input the adversary presents within its running-time limit. Here $L_{\mathrm{cmp}}$ represents reversible comparisons, controls, and table-lookups. Every $\epsilon_{4,j}^Q$ must apply at the resulting resources. No independent statement about the concrete quantum difficulty of these sources is known from this derivation.

## Boundaries and counterfactual changes

The proven structural lemmas of this chapter use the frozen ciphertext and sampling law. Several attractive changes would alter the theorem: adding a 256-bit confirmation tag changes the format to 1792 bytes; using a distinct fallback hash family would change the graph coupling; removing the random lift changes the second source simulation; supplying a quantum decapsulation oracle changes the threat model; instantiating $H_A,G,H$ with SHAKE256 changes the ideal-oracle hypotheses. The conservative theorem does not silently cover any of these changes.

A large conditional exponent in a particular *classical* attack-cost model cannot replace $\epsilon_{4,j}^{Q}$ in the square-root term. Even if every displayed arithmetic factor were checked, the resulting inequality would not certify 128-bit post-quantum security without independent source hardness and resource-conversion premises. The exact question for the closing chapters is whether a stronger *failure-game* analysis can improve the conservative failure term while respecting the same frozen protocol. Chapter 10 treats that question.


# Finding Failures: Shared Tapes, Second Moments, and the FFP Frontier

## Why correctness is not the same experiment as failure finding

Chapter 5 bounds the probability that honestly sampled encryption coins cause an error. A random-oracle KEM permits a qualitatively different adversarial action: an attacker can evaluate an oracle on many messages and try to choose the message whose oracle-derived tape is unusually unfavorable. Whether such selection can exploit a *public key* is another, still more delicate, question. These effects are the reason that a small decryption-failure probability is not automatically a complete chosen-ciphertext security proof.

This chapter separates four random objects: the generated key, the message, the complete encryption tape, and the adversary's observable view. It then reconstructs the independent-key second-moment argument from companion Article [S4]. The theorem is conditional only on the specified distribution of key generation and tapes, not on hardness of Module-LWE. Its relevance to a QROM reduction depends on a separately identified search lemma. The current Ring/Module-LWE literature on public-key-dependent failure finding is considered explicitly rather than dismissed on the basis of noise nomenclature.

## A dictionary of failure parameters

Let $K=(pk,sk,H_A)$ stand for a full generated key environment. Let $\omega$ be a complete honest uniform encryption tape, *including* all ephemeral CBD1 and lift coordinates. Define the honest failure predicate

$$
F(K,m,\omega)=
\mathbf1\{\operatorname{Dec}_{sk}(\operatorname{Enc}_{pk}(m;\omega))\ne m\}.
$$

The parameter used in Chapters 5, 8 and 9 is

$$
d(K)=\max_m\Pr_\omega[F(K,m,\omega)=1],
\qquad
\delta_{wc}=\mathbb E_K d(K).
$$

The maximum is *inside* the key expectation. In this particular C1-K4 decoder, the all-one message is maximal at each fixed key, because only the decision ties at $1024$ and $3072$ break bit symmetry. Section 5.3 proves the pointwise inclusion of failure events for the two bits; enumeration of all 4096 residues also verifies the endpoints. Consequently, $d(K)$ also equals the honest error probability for the all-one message at that key. We retain the general notation $d(K)$ because the proof strategy should not depend on a coincidence that can fail for another decoder.

For a message and tape held fixed, sample an **independent fresh key** and define

$$
p_m(\omega)=\Pr_K[F(K,m,\omega)=1],
\quad
\delta_{ik}=\max_m\mathbb E_{\omega}p_m(\omega),
\quad
\sigma_{\delta ik}^2=
\max_m\operatorname{Var}_{\omega}(p_m(\omega)).
$$

The letter $ik$ refers to an independent key in the FFP-NK setting, not to a key $K$ that is revealed to the adversary. Interchanging the two maxima and expectations without a coupling proof is generally invalid. For the frozen decoder, the all-one message is a simultaneous maximizer for each key, so the equality $\delta_{ik}=\delta_{wc}$ holds under the identical honest distributions. The generic inequality $\delta_{ik}\le\delta_{wc}$ would suffice elsewhere.

| Quantity | What is fixed | What is averaged | What it does not bound |
|---|---|---|---|
| $d(K)$ | One full honest key | Fresh tape, maximum over messages | Every alternative generated key |
| $\delta_{wc}$ | C1-K4 algorithm | Average of $d(K)$ over keys | Worst-case malicious keys |
| $p_m(\omega)$ | One message and one complete tape | Fresh independent keys | Failure rate conditional on a matching public key |
| $\delta_{ik}$ | Message before maximizing | Tape and independent key | Public-key-dependent tape selection |
| $\sigma_{\delta ik}$ | Same message | Standard deviation across complete tapes, maximized over messages | Full IND-CCA advantage |
| FFP-NG advantage | Public key is visible | Random target-key experiment and adversarial coins | Itself a CCA bound without composition |

An elementary but useful observation is $0\le p_m(\omega)\le1$. Hence $\operatorname{Var}p_m\le\mathbb E p_m$ and $\sigma_{\delta ik}<2^{-106}$ follows directly from the $2^{-212}$ correctness theorem. The aim below is a stronger result obtained without pretending that different output coefficients have independent tapes.

## FFP-NK and FFP-NG are different games

**Definition 10.1 (FFP-NK).** The adversary uses the specified extractable tape-oracle interface and outputs only a classical message $m$. The challenger evaluates $\omega=\mathrm{eCO.RO}(m)$ at the end and tests $F(K,m,\omega)$ with a fresh independent honest key $K$. The tape includes all 2816 bytes. The tested key and its environment are independent of the adversary's oracle setup. Success is the probability of the failure event. Allowing the adversary to supply an arbitrary tape would define a different game.

**Definition 10.2 (one-pair FFP-NG).** Draw independent honest keys $K_0,K_1$ and a fair hidden bit $b$. Give $pk_0$ to the adversary. It may submit one chosen pair $(m,\omega)$ of a message and a full tape, receive $F(K_b,m,\omega)$ and output $b'$. Its advantage is $|\Pr[b'=b]-1/2|$. The distinction from FFP-NK is twofold: here the adversary knows $pk_0$ and chooses its tape. Its final decision can use its entire public-key-dependent view.

In FFP-NK, the final oracle tape is independent of the unknown tested key. In FFP-NG, the tape may be a function of $pk_0$ and may correlate with the actual secret through the *public* arithmetic. That correlation is precisely what a hardness or reduction argument must address. The FFP-NG game is not solved by the two-key second moment alone, and an inability to find an attack among a handful of tested heuristics is not a proof of the absence of such a correlation.

## A same-tape, two-independent-key identity

Take two independent copies $K^{(1)},K^{(2)}$ of the complete honest key experiment, including the stipulated matrix environments. Feed them the *same* complete tape $\omega$ and fixed message $m$. Conditional independence of the two keys for each fixed tape implies the exact identity

$$
\mathbb E_\omega[p_m(\omega)^2]
=\Pr_{\omega,K^{(1)},K^{(2)}}
[F(K^{(1)},m,\omega)=1\ \wedge\ F(K^{(2)},m,\omega)=1].
$$

This identity is simple but important. It transforms a variance question into a probability of two simultaneous failures. It does **not** make the two events independent unconditionally, since the tape is shared. Nor may a proof replace the tape by independent tapes for each key: doing so would produce $(\mathbb E p_m)^2$, a different quantity.

The key environment matters when using a compact seeded representation. The theorem uses two independently drawn honest key environments, with the independently specified seed/matrix law, while the same encryption tape is shared. If an implementation or a multi-user experiment forces both keys to share an oracle state with seed collisions, the coupling of the two environments must first be re-established. The two-key estimate must not silently be transplanted to such a variant.

## The diagonal moment calculation and why Cauchy--Schwarz is necessary

Write $\varepsilon_i(K,\omega)$ for the integer error lift of output coefficient $i$. From the Chapter 5 containment, each failure implies that for some coefficient $i$ and sign $a\in\{\pm1\}$, $a\varepsilon_i\ge1024$. For a fixed $u>1$ set

$$
g_{i,a}(\omega)=\mathbb E_K u^{a\varepsilon_i(K,\omega)}.
$$

At two possibly distinct indices and signs, $g_{i,a}$ and $g_{j,b}$ share the tape and need not be independent. Cauchy--Schwarz gives the valid substitute

$$
\mathbb E_\omega[g_{i,a}g_{j,b}]
\le
\sqrt{\mathbb E_\omega[g_{i,a}^2]\,\mathbb E_\omega[g_{j,b}^2]}.
$$

It suffices to dominate each diagonal square $\mathbb E g_{i,a}^2$ uniformly. The same-index diagonal is special: in each negacyclic block, the two keys see the *same signed permutation* of the common tape coordinates. This makes a coordinatewise conditioning argument possible. The negacyclic sign is absorbed by maximizing over the two signs in the following exact finite moments.

Let $E,E',S,S',R$ be independent CBD1 variables; let $T$ be uniform on $\{0,1,2,3\}$; and let $E_1,E_2$ be fresh CBD1 variables shared by the two key calculations. Define

$$
\begin{aligned}
A_2(u)=\max_{a,b\in\{\pm1\}}\mathbb E_{E,E'}\,
\max_{t,t'\in\{0,1,2,3\}}
\mathbb E_{R,T}
 u^{R[a(E+T-t)+b(E'+T-t')]},\\
B_2(u)=\max_{a,b\in\{\pm1\}}\mathbb E_{S,S'}\,
\max_{c,c'\in\{0,1\}}
\mathbb E_{E_1}
 u^{aS([c+E_1]_2-E_1)+bS'([c'+E_1]_2-E_1)},\\
C_2(u)=\max_{a,b\in\{\pm1\}}
\mathbb E_{E_2}\,
\max_{t,t'\in\{0,1\}}
 u^{a(E_2-t)+b(E_2-t')}.
\end{aligned}
$$

The placement of the *inner* maxima is part of the theorem: it prevents replacing correlated derived remainders by independent samples. The offset maxima in $A_2$ and $B_2$ occur after the indicated conditional expectation, while the maximum over the final two remainders in $C_2$ stays within the expectation over $E_2$. Moving either maximum could produce a smaller, unjustified upper bound.

**Theorem 10.3 (same-tape second-moment bound).** Under the two-independent-key and shared-tape law,

$$
\mathbb E_\omega[p_m(\omega)^2]
\le4n^2u^{-P/2}\bigl(A_2(u)B_2(u)\bigr)^{kn}C_2(u),
$$

for any fixed message $m$, with $n=256$, $k=4$, $P=4096$ and $u>1$.

*Proof.* Fix a coefficient and a tail sign. In the simultaneous two-key exponential moment, eliminate the two final remainders pointwise and then average the *shared* $e_2$ using $C_2$, without claiming its independence from those remainders. Condition on both complete key-generation draws (including the latent errors $e_0^{(1)},e_0^{(2)}$), the shared $r,\rho$, and the parity offsets; average each independent shared $e_1$ coefficient and maximize over its pair of fixed offsets. This produces a product of functions of two key-secret coefficients, not yet the scalar $B_2^{kn}$. Next hold both actual $r_0$ vectors fixed under their corresponding keys, average each independent shared pair of $r$ and $\rho$ coefficients matched by the signed permutation for output $i$ and maximize the two hidden public remainder values. This produces a product of functions of the two corresponding key-generation errors. Only then average the independent secret and key-error coefficients across the two keys. The signed permutations are bijections at the same output index, giving $kn=1024$ factors of the bounded $A_2B_2$ product. Thus each diagonal expectation is at most $C_2(A_2B_2)^{kn}$. Use Cauchy--Schwarz for arbitrary pairs of output indices and signs. A two-tail exponential Markov bound at total threshold $2\cdot(P/4)=P/2$, followed by the union bound over $4n^2$ index/sign pairs, gives the stated inequality. $\square$

At the exact rational choice $u=6/5$, enumeration of the finite supports gives

$$
A_2=\frac{99036386572201}{83980800000000},\qquad
B_2=\frac{489677}{480000},\qquad
C_2=\frac{3721}{2500}.
$$

Consequently,

$$
\begin{split}
M_2&=4\cdot256^2\left(\frac65\right)^{-2048}
\left(\frac{99036386572201}{83980800000000}
\frac{489677}{480000}\right)^{1024}\frac{3721}{2500},\\
M_2&<2^{-247},\qquad
\log_2 M_2\approx-247.024841645.
\end{split}
$$

The strict comparison is between *integers* after clearing denominators; it is not a test of a floating-point logarithm. The accompanying verification script reconstructs this exact rational and checks the strict inequality. Since variance is bounded by the second moment,

$$
\boxed{\sigma_{\delta ik}<2^{-123.5}.}
$$

This is a new application-specific probability estimate in [S4] that extends the simpler Chapter 5 first-moment bound. It does not itself provide a small FFP-NG advantage or a quantum LWE theorem.

## Search bounds and the essential scope of the oracle lemma

Consider the HHM search lemma [R2], with $q$ queries to its specified extractable oracle before the adversary's final output. Write $D_q=152(q+1)^2$. In the independent-key FFP-NK experiment, if the key is not known to the attacker and the oracle is fresh, the relation for any fixed target key has maximum tape density $d(K)$. Applying the search lemma and then averaging the key gives the **direct** bound

$$
\operatorname{Adv}_{\mathrm{FFP\text{-}NK}}\le
\min\{1,D_q\delta_{wc}\}.
$$

It uses $\mathbb E_K\max_m$, not merely $\max_m\mathbb E_K$. If only $\delta_{ik}$ were available, one can instead apply Markov to $p_m(\omega)$ with a threshold $t$; for a single fixed adversary this yields

$$
\Pr[p_m(\omega_{\mathrm{out}})\ge t]
\le\min\{1,D_q\delta_{ik}/t\}.
$$

For $a=D_q\delta_{ik}\in(0,1)$, integrating that tail distribution bounds the mean failure success by

$$
\mathbb E\,p_m(\omega_{\mathrm{out}})\le a(1+\ln(1/a)).
$$

For $a=0$ take zero, and for $a\ge1$ cap the bound at one. The threshold and direct formulas use different correctness hypotheses and should not be conflated. The imported FFP-NK variance refinement can inform some decompositions, but the leading variance-dependent summand alone cannot be presented as an end-to-end KEM bound. The advantage normalization also matters: a failure-event probability needs no factor of two, whereas a distinguishing bias generally does.

As an illustration, taking $q=2^{32}$ and the upper bound $\delta_{wc}<2^{-212}$ gives

$$
D_q\delta_{wc}<152(2^{32}+1)^2 2^{-212}
\approx2^{-140.752}.
$$

That exponent describes the stated direct *failure-game component*. It must not be advertised as a 140-bit security certificate for the complete QROM KEM: source hardness, oracle composition and other positive terms remain.

## Generic bad tapes versus public-key-dependent tape selection

The supplementary experiments of [S4] distinguish two mathematically different protocols. In the first, a procedure generates a *family* of structured tapes and resamples selected lift coordinates from trial to trial. In the second, a **complete fixed tape** is held unchanged across independent keys. The latter is the direct empirical analogue of $p_m(\omega)$ for that tape. Mixing the two protocols into a single frequency would silently change the sampled random variable.

The reported finite controls use 128 trials per arm with integer negacyclic convolution. With three all-one active ephemeral module components and all lift coefficients set to zero, failures were observed in all 128 trials in both independent arms; with fresh uniform lifts in their separate controls, the observed counts were zero in the stated arms. These observations demonstrate strongly structured *possible* failure tapes, not their probability under an honest random oracle. Their sampling procedure does not define an FFP-NG attack because the tape was not selected from a matching public key. The proofs in this chapter do not depend on those frequencies.

The separate FFP-NG pilot of [S4] tested four elementary public-key-dependent tape-selection rules: a midpoint-sign rule, a parity rule, a three-valued threshold rule, and a local-difference sign rule. Each was tested on 128 independently generated key pairs, and the reported failure frequencies in both arms were zero. The resulting plug-in bias is zero **for those samples only**. No conclusion about true zero advantage, universal resistance, or negligible asymptotic advantage follows. Adaptive polynomial-time and quantum adversaries cover a far larger class of algorithms than these four rules.

## A contemporary Ring/Module-LWE result and a missing bridge

Majenz--Sisinni [R4] studied a non-generic failure-finding reduction in an LWE setting. Their later work [R5], *Provable Decryption Failure Security for Practical Lattice-Based PKE* (IACR ePrint 2025/1997, also listed as accepted at SAC 2026), explicitly extends the analysis to Ring/Module-LWE families and subgaussian errors including centered binomial laws. Therefore the statement “FFP-NG theory exists only for Gaussian LWE” would be scientifically incorrect. The applicability of [R5] to the **exact** C1-K4 quotient/lift mechanism still requires checking the hypotheses of the version to be cited.

| Interface to match | Frozen C1-K4 specification | Necessary comparison before importing an FFP-NG theorem |
|---|---|---|
| Public operator | Uniform four-by-four matrix over $\mathbb Z_{4096}[x]/(x^{256}+1)$ in the ideal model | Same ring/module generation and public-view assumptions |
| Secret | Independent coefficient CBD1 | Permitted secret support, covariance and reduction interface |
| Explicit key error | Independent coefficient CBD1 | Required noise splitting or subgaussian conditions |
| Public rounding | $F_4(As+e_0)$ | Whether quotient observation and discarded remainder fit the theorem's encryption law |
| Encryption lift | $v=4b+\rho$ with fresh uniform $\rho$ | Joint law of $v$, $b$ and public key; no artificial independence |
| Ciphertext compression | $F_2$ on both components | Treatment of the resulting dependent remainders and failure predicate |
| Shared ephemeral secret | Same $r$ in $c_1,c_2$ | Sample correlations and matrix augmentation permitted by the theorem |
| Failure-selection interface | Attacker may choose tape using public view | Exact FFP-NG game and key/coin quantifiers |
| Security model | Key-first fresh QROM for Chapter 9 | Distinguishing gap, query model and any additional assumptions |

A statement about the distribution family alone is insufficient: C1-K4's compression and randomized lifting may place it outside an otherwise applicable standard PKE template. Conversely, the fact that its coefficients have dependent remainders does not prove the reduction impossible. The right verdict, until every row is matched and the source theorem is instantiated, is **open**, not refuted and not automatically proved.

## Chapter conclusion

The same-tape second moment and the direct extractable-oracle search bound quantify two important ways in which failure probabilities enter a QROM analysis. They demonstrate that the generic bad-tape issue can be bounded in an explicit model without forcing a full FFP-NG reduction into the conservative composition of Chapter 9. They do *not* neutralize a hypothetical key-dependent adversary outside those game interfaces. The sharper match to [R5], with all C1-K4 quotient, lift and compression details exposed, remains a genuine research problem. Chapter 11 will combine the contributions in a ledger that prevents these distinct claims from being mistaken for interchangeable security guarantees.


# Evidence, Assumptions, and the Cost of a Security Claim

## A theorem has an experiment attached to it

A cryptographic manuscript is not adequately summarized by its largest exponent. It must explain what the exponent measures and to which probability experiment its supporting proof applies. The C1-K4 case presents four distinct kinds of knowledge. Exact equalities and rational bounds follow from fixed algebraic laws. Hybrid reductions convert one specified advantage into a sum of other specified advantages. Cryptanalytic cost models estimate known algorithmic strategies under heuristic formulas. Implementation and experimental reports show only what has been executed on particular programs or data. Confusing one category with another can turn a scientifically useful research candidate into an unsupported product claim.

This chapter records the principal results of the first ten chapters with their quantifiers and explicit boundaries. It is part of the scientific argument: a reader should be able to reconstruct both what follows and what does not follow from the definitions, proofs, source versions and recorded computations.

## Frozen parameters, objects, and exact numerical statements

The immutable instance is

$$
R=\mathbb Z_{4096}[x]/(x^{256}+1),\quad
(k,n,P,Q,C)=(4,256,4096,4,2),\quad \chi=\mathrm{CBD}_1.
$$

Secrets, key errors and encryption errors are sampled coefficientwise from $\chi$; the lift $\rho$ is uniform on $\{0,1,2,3\}^{1024}$. The public quotient $b=F_4(As+e_0)$ and the lifted value $v=4b+\rho$ are **not independently sampled** under a real key. The same $r$ appears in both ciphertext components. These choices define the experiment; changing any of them creates a new scheme rather than an optimization of the same theorem.

The exact core statements are:

$$
\varepsilon=(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2,
$$

$$
2^{-8192}\le\delta_{wc}<2^{-212},
\qquad
\mathbb E_\omega[p_m(\omega)^2]<2^{-247},
$$

$$
|pk|=1313\ \mathrm{bytes},\qquad
|ct|=1760\ \mathrm{bytes},
\quad\gamma\ge1280\log_2(4/3).
$$

The correctness parameter is averaged over honest generated keys after maximizing the per-key honest message-failure probability. The same-tape second moment uses two independent complete key environments and a shared honest tape. The byte counts concern canonical packed public payloads in the 256-bit ideal matrix-seed model; they are not totals for a finished KEM API with all secret-key fields, algorithm identifiers and transport framing.

**Claim register (exact statements).**

| Claim | Where it is established | Crucial condition |
|---|---|---|
| Unique quotient/remainder coordinates and carries | Chapter 2; [S3] | Canonical residues and stated divisibility |
| Negacyclic block signs and module transpose | Chapter 3 | $x^{256}=-1$, ring coefficient law |
| Complete C1-K4 algorithms | Chapter 4 | Exact CBD1, lifting and shared $r$ |
| Error congruence and nonperfect correctness | Chapter 5; [S1] | Honest keys and tapes; actual derived remainders |
| Uniform-lift simulation | Chapter 6 | Uniform $V$ *jointly* with the public quotient |
| Rigidity | Chapters 8--9 | Full byte-exact re-encryption comparison |
| Spreadness | Chapter 9; [S2] | Randomized encryption with independent $e_1,e_2$ |
| Same-tape second moment | Chapter 10; [S4] | Two independent key environments and one shared tape |

A script reproducing a fraction proves that the fraction was computed, not that the conditioning argument from which it arose was correct. The latter must be read at the level of the proof. In Chapter 5 the rational upper bound uses $u=4/3$ and $kn=1024$; in Chapter 10 the second-moment bound uses $u=6/5$ with a different sequence of conditional maxima. Their numerically similar forms are not interchangeable.

## A graph of the conditional reductions

The passive-security chain is

$$
\mathrm{DMLWE}_{4,4}^{\chi}
\ \&\ \mathrm{DMLWE}_{4,5}^{\chi}
\Longrightarrow\ \text{conditional C1-K4 IND-CPA}.
$$

This is an implication **under small exact source gaps at the reductions' budgets**, not a theorem proving those gaps small. The four-row source simulates the public quotient; the five-row source simulates the joint challenge with a shared ephemeral secret and a lifted public quotient. In the seeded model the matrix oracle must be included in the source distinguishers' resource accounting. The direction of implication is not reversed by displaying an attack estimate.

The classical wrapper chain, for one key and the challenge-first ROM model of Chapter 8, is

$$
\operatorname{Adv}^{\mathrm{classical}}_{\mathrm{CCA,bias}}
\le4\epsilon_{4,4}+4\epsilon_{4,5}+8\epsilon_A
+2Q\,2^{-212}+(3Q+1)2^{-256},
$$

with $Q=q_G+q_H+3q_D+2$ in that chapter's allowance. Its terms have different origins: source gaps, a prior-query matrix-seed conflict in the applicable classical simulation, a correctness contribution, and random guessing. The inequality cannot be transplanted to a quantum adversary by replacing $q$ with a quantum query count. The quantum key-first source coupling does not even use the same matrix-seed conflict term.

Chapter 9, using the published/full-version extractable-oracle route of [R2], gives a distinct **conditional quantum** inequality with a square root in the quantum source gaps and explicit spreadness and failure-finding contributions. Its $U_Q$ is not equal to the classical $Q$ above. The correct comparison is between *fully stated experiments*, not merely formulas. The sharper FFP-NG route is marked open because the contemporary structured-lattice theorem's hypothesis match to C1-K4 is not established in Chapter 10.

**Claim register (conditional statements).**

| Claim | Security experiment | External premise or unfinished check |
|---|---|---|
| Two-source CPA transfer | Classical or quantum with specified oracle treatment | Small exact decision gaps for $j=4,5$ |
| Classical FO/implicit-rejection bound | Single-user, ideal classical ROM, challenge-first | Corrected [R1] game interfaces and augmented budgets |
| Graph simulation | Fresh key-first QROM, classical decapsulation | Exact reversible oracle coupling and [R2] reference transform |
| Conservative QROM expression | Same quantum experiment as Chapter 9 | Quantum source gaps and [R2] hypotheses/normalization |
| Refined FFP-NG composition | Would require fully specified FFP-NG experiment | Exact instantiation of [R5] or a new reduction |

The words *conditional* and *conservative* have distinct meanings. Conditional names the external premise: the source distributions and imported theorem must satisfy the stated bounds. Conservative means the proof deliberately uses a coarse upper bound that may be far from tight. Neither adjective means incorrect or insignificant; neither alone implies a concrete numerical security level.

## Work, advantage, time, and memory must not be silently identified

A dual or lattice attack estimator returns a number of modeled primitive operations at a point in a parameter search. A security reduction supplies a computational transformation of one adversary into a distinguisher for an assumed-hard source problem. These numbers measure different quantities until a common cost model is fixed. In particular, if a model predicts work $2^{206.211}$ for a named strategy, the model supplies an example of a candidate attack cost, **not** the inequality that every attack takes at least $2^{206.211}$ steps. Subtracting a hypothetical reduction overhead of approximately $2^{22.17}$ does not repair the logical reversal.

The evidence from Chapter 7 is limited as follows.

| Evaluated attack model | Reported $\log_2$ work | Evidence limit |
|---|---:|---|
| Classical primal uSVP | 227.176 | Baseline heuristic |
| Classical plain dual | 235.060 | Baseline heuristic |
| MATZOV expanded local search | 213.656698256 | Best point found in documented scan, not a global minimum |
| Rotation-aware coded-dual | 206.210581344 | Pinned Sage model and two adaptations; historical full cost evaluation |

The MATZOV run at fixed $m=1024$ found the point

$$
(\beta,p,k_{enu},k_{fft},k_{lat},d)=(731,3,6,114,904,1928).
$$

The separately reported probe with $m=1280$ required gives $221.9708\ldots$ at its local point. The larger number cannot establish a higher minimum work requirement for the five-row source: a solver may ignore 256 of its 1280 observations and use the four-row strategy. The coded-dual reported point uses $m=770$ and has a valid checked search-bracket crossing at $R=137829$ in its specified model, but this does not resolve all rotation-compatible selections or untested variants. These statements are about the coverage of the *search*, not the truth of a general hardness conjecture.

The modeled re-encryption schedule counts 63,200 abstract operations and uses a conservative $2^{16}$ bound with $2^{17}$ precomputation allowance. The value $\bar\kappa=393217$ and $\log_2(12\bar\kappa)\approx22.16992867$ are bookkeeping outputs, not processor measurements or a quantum gate count. A reproducible thesis may print them for transparency but must not silently identify their units with those of the attack estimates. A concrete reduction-to-security-bits conversion would additionally require source work/advantage curves, adversary memory bounds, sample complexity and oracle/circuit costs.

## Two numerical examples that should not be overinterpreted

At the classical ROM query allowance $Q=2^{32}$, the explicitly bounded correctness term in Chapter 8 satisfies $2Q2^{-212}=2^{-179}$; the guessing term is $(3Q+1)2^{-256}<2^{-222}$. These small terms leave the source gaps $\epsilon_{4,4},\epsilon_{4,5}$ entirely unknown. Thus the numerical example does not imply an IND-CCA advantage below $2^{-128}$.

At the QROM failure-search allowance $u=2^{32}$, the direct extracted-oracle failure component is less than $2^{-140.75}$, as Chapter 10 explains. It is nevertheless multiplied by $(q_D+1)$ in the composed inequality and accompanied by a square-root source-advantage term and a spreadness term. Furthermore $u$ must be the **translated** extractable-oracle query budget, not an original user-facing query count. Reporting $2^{-140.75}$ in isolation as the system's security would discard the very components a proof is designed to retain.

## Reproducibility hierarchy and versions

The intended public archive should separate three sources of evidence. A proof document gives definitions and inference steps. Executable checks regenerate exact finite fractions, parameter counts and specified model outputs. An immutable reference to public attack code records the cost formula and search environment used at the time of the calculation. A prose report may explain how an audit was conducted, but its verdict is **not** a replacement for these objects.

Chapters 1–8 derive from V0.4. Chapters 9–12 were introduced in V0.5 and revised in this edition. The sources of their conditional quantum and two-key claims are [S2] V4.2, [S4] V4.4 and the forms of the external theorems specified in Chapters 9 and 10.

An audit-ready release should include: exact source Markdown and generated LaTeX, a visually inspected PDF, an editable word-processing edition where possible, the four separately identifiable companion manuscripts and their supplements, clean-output verification commands, pinned code commits, and a SHA-256 manifest. Each experiment must record its seed, sample law, trial count, implementation and output path. Historic Sage output remains labelled historic unless the exact Sage computation is newly executed.

The accompanying checks enumerate finite supports for the moments and rounding cells, compare exact integers and exercise the graph coupling on small finite domains. The proof of the quantum reduction uses the oracle identities and [R2].

## A consolidated decision table

The following table is the minimal truthful executive summary of C1-K4 in this edition.

| Question | Answer in this edition |
|---|---|
| Are the public-key and ciphertext algorithms completely specified? | Yes, for the research ideal-oracle profile. |
| Is honest decryption perfectly correct? | No; an explicit event proves nonzero failure. |
| Is the average worst-message honest failure small? | Yes, an exact bound is proved. |
| Is IND-CPA unconditional? | No, it depends on two precise Module-LWE decision gaps. |
| Is the classical ROM route completely general? | No, the stated experiment is single-user and challenge-first. |
| Is a coherent QROM route described? | Yes, conditional in the single-user, fresh, key-first model of Theorem 9.6. |
| Is the sharper FFP-NG reduction established? | No; applicability of [R5] is unresolved. |
| Do the reported attacks prove a minimum security level? | No. |
| Is SHAKE256 instantiation proved equivalent to the ideal oracles? | No. |
| Can the candidate be called *certified PQ-128*? | No. |

The legitimate contribution is not an unearned security label. It is the preservation of exact arithmetic and dependent remainders all the way to clearly delimited reductions and adversarial models. Chapter 12 uses this ledger to state the final conclusions, limits and next research obligations.


# Conclusions, Open Problems, and the Research Program Beyond C1-K4

## What this thesis has established

The central argument of this thesis begins with the identity $[z]_P=DF_D(z)+[z]_D$ for $D\mid P$. Its quotient seems simple because a remainder has disappeared from the displayed value. The remainder has not disappeared from the probability space. When quotient values enter later bilinear computations, the discarded coordinates continue to influence carries, errors, and correlations. In C1-K4 the effect is visible in three places: key-generation rounding, ciphertext compression, and randomized lifting of the public quotient. Keeping all three remainders in the same probability experiment is the decisive mathematical discipline of the construction.

Chapters 2--5 established the exact foundations and one nontrivial correctness result. With the frozen ring, module rank, modulus and CBD1 laws, honest decryption obeys

$$
z\equiv2048\mu+
(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2
\pmod{4096}.
$$

The dependent-remainder moment proof yields an average-over-keys worst-message bound below $2^{-212}$. A distinct positive-probability event establishes that correctness is not perfect: $\delta_{wc}\ge2^{-8192}$. Together these claims are more informative than a Gaussian approximation or a simulation that happens to show no failures. The lower bound prevents future reductions from casually discarding the correctness term. The upper bound controls it within its precise quantifier order.

Chapters 6--8 moved to cryptography. They exhibited the two decision-source interfaces $\mathrm{DMLWE}_{4,4}^{\mathrm{CBD1}}$ and $\mathrm{DMLWE}_{4,5}^{\mathrm{CBD1}}$, with a shared secret in the latter's five rows and an exact relation between the public quotient and its retained lift. These are conditional security transfers, not hardness results for arbitrary LWE. The classical Fujisaki--Okamoto construction uses a compact 1313-byte public key, a 1760-byte ciphertext, a fresh uniform 256-bit encapsulation message, an exact re-encryption test, and a stable implicit-rejection fallback. Within the single-user, challenge-first classical-ROM game established in Chapter 8, the security implication has explicit source and correctness terms. The hypothesis that the exact sources are hard remains external.

Chapters 9--10 confronted the quantum and failure-finding interfaces. A fresh, key-first quantum random-oracle experiment allows the matrix oracle to be installed before the adversary's first quantum query, rather than trying to reprogram a previously observed oracle. The ciphertext-dependent KDF and fallback use one underlying hash family; a coherent graph simulation of that fact is crucial. The conservative conditional QROM bound imported from [S2] combines quantum passive-security gaps, the spreadness estimate, an extractable-oracle failure search bound and a reference-transform theorem. The sharper same-tape second moment from [S4] gives $\mathbb E[p_m(\omega)^2]<2^{-247}$ under two independent keys. Neither result is a completed reduction from a standard worst-case lattice problem to the exact compact KEM.

The synthesis of Chapter 11 is deliberately less dramatic than a headline exponent. Each claim is assigned an experiment, assumptions and evidence. A cost estimate near $2^{206.211}$ for one specified adapted coded-dual model is meaningful evidence for that attack model, but not a theorem that every classical or quantum adversary requires that many steps. Our objective is an auditable mathematical case study, not a numerical security certification.

## The main contribution and its limits

The contribution is the integration of several separately difficult interfaces under a single frozen algorithmic specification. The exact error identity was not replaced by independent artificial noise. The CPA source reductions preserve the complete joint distribution. The FO analysis retains a nonzero failure probability. The quantum analysis treats oracle access as a coherent operation and distinguishes a preselected oracle patch from adaptive quantum programming. The FFP analysis separates independent-key rare-event search from public-key-dependent tape selection. Finally, the cryptanalytic evidence reports its search domain and provenance.

There are important boundaries to this claim. Euclidean division, Toeplitz/negacyclic algebra, Module-LWE and the FO family are established foundations; the thesis does not claim their invention. The new C1-K4-specific claims concern the application of those foundations to the specified construction, the dependent-remainder correctness estimate, the exact source-game coupling, and the numerical/modeling evidence. The second-moment argument is an imported companion result with its own hypotheses. The QROM theorem in Chapter 9 is a conditional restatement and derivation from [S2] and [R2], under the oracle and resource assumptions stated in Theorem 9.6.

A good cryptographic conclusion should also say what it does *not* establish. This manuscript does not prove the quantum computational hardness of either exact source distribution, the security of SHAKE256 as a concrete substitute for three independent ideal oracles, a concrete 128-bit post-quantum work factor, resistance to all structural/2-adic attacks, multi-user security, superposition decapsulation security, or security against shared prior random-oracle advice. It does not provide a hardened, constant-time, independently tested software implementation.

## Six specific open problems

### Problem 12.1 — Source hardness for the exact small-secret module laws

The passive and quantum reductions terminate in $\mathrm{DMLWE}_{4,4}^{\mathrm{CBD1}}$ and $\mathrm{DMLWE}_{4,5}^{\mathrm{CBD1}}$. A useful next result would be a rigorously quantified hardness reduction or a controlled cryptanalysis of these exact distributions, with $R=\mathbb Z_{4096}[x]/(x^{256}+1)$ and sample counts fixed. The reduction must state whether it is classical or quantum, the law of the public operator, the secret, the additive error, the allowed number of rows, and the advantage/runtime loss. Generic LWE theorems cannot be imported by merely expanding the 1024 secret coefficients into a vector.

**Closure criterion:** a theorem with explicit source and target distributions and resource accounting, or a reproducible counterexample/attack invalidating a claimed equivalence.

### Problem 12.2 — Exact FFP-NG hypothesis matching

The newer work of Majenz--Sisinni [R5] is relevant because it studies Ring/Module-LWE and centered-binomial-like noise. The missing mathematical bridge is to show whether its assumptions match the real C1-K4 quotient $b=F_4(As+e_0)$, the conditional uniform lift $v=4b+\rho$, the two $F_2$ ciphertext compressions and the common ephemeral $r$. This could produce a sharper failure contribution than the coarse $152(u+1)^2\delta_{wc}$ route. It could also reveal a precise obstruction. Neither outcome should be presumed in advance.

**Closure criterion:** a theorem-by-theorem correspondence table followed by a reduction with the exact FFP-NG game, or a documented mismatch that identifies a genuinely missing lemma.

### Problem 12.3 — Complete augmented quantum resource budgets

The QROM source gaps refer to algorithms generated by a transformation, not to the original attacker's nominal query count. A concrete comparison needs a reversible implementation of the oracle graph test, full matrix expansion, encryption arithmetic, extraction, uncomputation and classical decapsulation simulation, together with quantum gate, depth, memory and query budgets. The present symbolic overhead is useful for logic but insufficient for a cost-conversion claim.

**Closure criterion:** an independently checked gate/resource account for the composed reduction, and quantitative source-advantage bounds at those exact augmented resources.

### Problem 12.4 — From an ideal oracle to a real expander

The 32-byte seed is modeled by an ideal random matrix oracle with independent raw 512-byte responses. Instantiating that oracle with SHAKE256 or another concrete primitive would not make the complete matrix uniform in the information-theoretic sense. The correct statement would need a suitable cryptographic assumption, a provable pseudorandom generation construction, or an explicitly distinguished implementation assumption. Domain separation alone does not prove the desired distributional replacement.

**Closure criterion:** a precisely formulated computational replacement game and a justified advantage bound for the concrete generator, including the high raw-word bits visible at its oracle interface.

### Problem 12.5 — Broader games: pre-challenge, multi-user, shared-oracle advice

The classical chapter identifies a bounded pre-challenge ciphertext collision term but does not equate that observation with a complete adaptive pre-challenge CCA proof. The quantum chapter assumes a key-first adversary, fresh oracles and classical decapsulation. A natural extension would allow genuinely adaptive pre-challenge decapsulation, several correlated challenge public keys, or advice based on a previously sampled random oracle. Each extension changes what can be patched or conditioned upon and how failures and collisions accumulate.

**Closure criterion:** a separate game statement and complete reduction for each extension, with no silent inheritance from the narrower single-user experiment.

### Problem 12.6 — Adversarial cryptanalysis and implementation evidence

The existing MATZOV and coded-dual searches are documented points, not a complete minimum over all attacks. More exhaustive structured, 2-adic, hybrid, rotation-aware and quantum analyses should test the exact four- and five-row instances. A trustworthy practical KEM would in parallel require constant-time encoding/decoding, malformed-input fuzzing, deterministic cross-platform tests, correct fallback handling, randomness health checks and a side-channel review.

**Closure criterion:** pinned code and search domains for new attack results, together with independent implementation audits. No test campaign, even a broad one, can by itself prove universal absence of attacks.

## Toward a versioned, reproducible edition

The source editions are identified in the bibliography. The reproducibility dossier contains hashes of the inputs and corrected manuscript, the fresh calculations, their commands and the historical status of the Sage result. Versioning the experiment matters: changes in the decoder, oracle interface or key distribution can change a proof even when the parameter sizes stay fixed.

## Final statement

This thesis argues that **mathematical exactness and security claims must travel together**. The quotient–remainder calculus can be exact while the hardness of its distributions is assumed. A small decryption-failure parameter can be rigorously bounded while the failure-finding game remains a separate adversarial problem. A coherent QROM security implication can be meaningful while the quantum hardness of its source remains unproved. A cryptanalytic estimate can be reproducible while saying nothing universal about the minimum cost of an undiscovered attack.

C1-K4 is therefore best described as a carefully specified and mathematically analyzable research candidate. Its principal value is an explicit route from exact modular arithmetic to conditional cryptographic experiments, accompanied by precise unsolved questions. The scientific task of turning those conditional statements into a robust, concretely assessed system is **future work**. A claim of “PQ-128 certified” would be premature. The research program remains valuable precisely because its boundaries have been made visible enough to be challenged, reproduced and improved.


# References and source manuscripts {-}


**[R1]** Dennis Hofheinz, Kathrin Hövelmanns, Eike Kiltz. “A Modular Analysis of the Fujisaki–Okamoto Transformation.” *TCC 2017*, LNCS 10677, pp. 341–371; corrected full version, 2 November 2021, Definition 2.1, Theorems 3.2 and 3.4 and errata, IACR ePrint 2017/604. <https://eprint.iacr.org/2017/604>

**[R2]** Kathrin Hövelmanns, Andreas Hülsing, Christian Majenz. “Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform.” *ASIACRYPT 2022*, LNCS 13794, pp. 414–443. Published Lemma 4, (30), p. 439. Full version, arXiv:2203.10182v1, Lemma 5 (51), p. 34 and Corollary 8 (69)–(70), pp. 37–38. <https://doi.org/10.1007/978-3-031-22972-5_15> · <https://arxiv.org/abs/2203.10182v1>

**[R3]** MATZOV. “Report on the Security of LWE: Improved Dual Lattice Attack.” Version 2, 2022. <https://doi.org/10.5281/zenodo.6493704>

**[R4]** Christian Majenz, Fabrizio Sisinni. “Provable Security Against Decryption Failure Attacks from LWE.” *CRYPTO 2024*, LNCS 14921, pp. 456–485. <https://doi.org/10.1007/978-3-031-68379-4_14>

**[R5]** Christian Majenz, Fabrizio Sisinni. “Provable Decryption Failure Security for Practical Lattice-Based PKE.” IACR ePrint 2025/1997, preprint, accepted at SAC 2026. The comparison in Section 10.8 refers to the ePrint version. <https://eprint.iacr.org/2025/1997>

**[R6]** Jianhua Hou, Haodong Jiang, Tabitha Ogilvie. “Careful with the Ring! Concrete Hardness Gaps Between LWE and MLWE.” Full version (a), T. Ogilvie, ePrint 2026/279. *CRYPTO 2026*, LNCS 16802, pp. 462–497. <https://doi.org/10.1007/978-3-032-35377-1_15>

**[R7]** *CodedDualAttack*, branch eprint-2026-279, commit 7cce6a557242 (full identifier in Section 7.5). [Pinned source](https://github.com/identitymapping/CodedDualAttack/tree/7cce6a5572420004da31be58f26954cedfc885d0).

**[R8]** Kévin Carrier, Charles Meyer-Hilfiger, Yixin Shen, and Jean-Pierre Tillich. *Assessing the Impact of a Variant of MATZOV’s Dual Attack on Kyber*. CRYPTO 2025, LNCS 16000, pp. 444–476. <https://doi.org/10.1007/978-3-032-01855-7_15>.

**[R9]** Abhishek Banerjee, Chris Peikert and Alon Rosen. “Pseudorandom Functions and Lattices.” EUROCRYPT 2012. <https://doi.org/10.1007/978-3-642-29011-4_42>.

**[R10]** Eiichiro Fujisaki and Tatsuaki Okamoto. “Secure Integration of Asymmetric and Symmetric Encryption Schemes.” CRYPTO 1999, LNCS 1666, pp. 537–554.

**[R11]** Kathrin Hövelmanns and Christian Majenz. “A Note on Failing Gracefully: Completing the Picture for Explicitly Rejecting Fujisaki–Okamoto Transforms Using Worst-Case Correctness.” *PQCrypto 2024*, LNCS 14772, pp. 245–265. <https://doi.org/10.1007/978-3-031-62746-0_11>.

**[S1]** Samir Bouftass. “C1-K4-P12-CBD1: Exact Correctness, Conditional Security, and Reproducible Attack Estimates.” Corrected preprint v1.1, 18 November 2026. Research assistance: ChatGPT (OpenAI); publication review in progress.

**[S2]** “C1-K4 in the QROM: Structural Bounds and a Conservative Conditional Reduction.” Companion manuscript, revision V4.2, 13 November 2026. Current source document, not a claimed externally refereed publication.

**[S3]** “A Quotient–Remainder Calculus for Modular Rounding.” Companion manuscript, revision V4.3, 13 November 2026. Current source document.

**[S4]** “Find-Failing-Plaintext Analysis of C1-K4-P12-CBD1.” Companion manuscript, revision V4.4, 13 November 2026. Current source document.
