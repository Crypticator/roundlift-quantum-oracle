"""Arguments: loose V0.5 inputs, V0.5 ZIP, V0.4 markdown, corrected manuscript directory, optional recomposed V0.5 PDF."""
import sys,zipfile,hashlib,io,json,re,difflib,platform
from pathlib import Path
import pymupdf as fitz
from lxml import etree
def sha(x):return hashlib.sha256(x).hexdigest()
def pdfinfo(d):
    pages=[]
    for i,p in enumerate(d):
        t=p.get_text()
        blocks=[b for b in p.get_text('blocks') if b[4].strip()]
        assert blocks and all(b[0]>=0 and b[1]>=0 and b[2]<=p.rect.width+.5 and b[3]<=p.rect.height+.5 for b in blocks)
        pages.append(dict(physical=i+1,text=sha(t.encode()),pixels=sha(p.get_pixmap(colorspace=fitz.csGRAY,matrix=fitz.Matrix(.75,.75)).samples),chapter=(m.group(1) if (m:=re.match(r'Chapter (\d+)\n',t)) else None)))
    return pages
def chapters(s):
 p=re.split(r'(?m)(?=^# )',s)
 return {t.splitlines()[0]:t.strip().splitlines() for t in p if t.startswith('# ')}
inputs,archive,base,corrected=map(Path,sys.argv[1:5])
summary={'python':platform.python_version(),'PyMuPDF':fitz.VersionBind,'inputs':{},'input_pages':{},'corrected':{},'chapter_changes':{}}
with zipfile.ZipFile(archive) as z:
 entries=z.read('SHA256SUMS.txt').decode().splitlines()
 for row in entries:
    h,n=row.split('  ',1);assert sha(z.read(n))==h
 summary['zip_manifest_verified']=len(entries)
 for p in sorted(inputs.iterdir()):
    summary['inputs'][p.name]=sha(p.read_bytes())
    if p.suffix=='.zip':continue
    n=next(n for n in z.namelist() if n.endswith('/'+p.name))
    if p.suffix=='.pdf':
        a=pdfinfo(fitz.open(p));b=pdfinfo(fitz.open(stream=z.read(n),filetype='pdf'))
        assert a==b
        summary['input_pages'][p.name]={'pages':len(a),'zip_bytes_identical':sha(z.read(n))==sha(p.read_bytes()),'archive_sha256':sha(z.read(n)),'all_pages_render_identically':True,'chapters':{x['chapter']:x['physical'] for x in a if x['chapter']}}
    else:assert z.read(n)==p.read_bytes()
 c=chapters(next(inputs.glob('*.md')).read_text())
 for k,lines in list(chapters(base.read_text()).items())[2:-1]:
    assert k in c
    summary['chapter_changes'][k]=[list(x) for x in difflib.SequenceMatcher(None,lines,c[k],autojunk=False).get_opcodes() if x[0]!='equal']
 for n in range(9,13):
    key=f'CHAPITRES_9_12/CHAPTER_{n:02d}.md'
    sect=chapters(z.read(key).decode());assert len(sect)==1
    title,lines=next(iter(sect.items()));assert lines==c[title]
for p in sorted(corrected.glob('*.pdf')):
    pages=pdfinfo(fitz.open(p))
    summary['corrected'][p.name]={'sha256':sha(p.read_bytes()),'pages':len(pages),'chapter_openings':{x['chapter']:x['physical'] for x in pages if x['chapter']}}
s=next(corrected.glob('*1_12.md')).read_text(); e=next(corrected.glob('*9_12.md')).read_text(); marker='# The Quantum Random-Oracle Boundary'
assert s[s.index(marker):]==e[e.index(marker):]
with zipfile.ZipFile(next(corrected.glob('*.docx'))) as w:
 doc=etree.fromstring(w.read('word/document.xml'));ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
 math=len(doc.xpath('//m:oMath',namespaces=ns)); assert math>300
 ts=' '.join(doc.xpath('//w:t/text()',namespaces=ns));assert 'Samir Bouftass' in ts and 'ChatGPT' in ts and 'Corollary 8' in ts
 summary['docx_math_objects']=math
if len(sys.argv)>5:
 d=fitz.open(next(inputs.glob('*1_12.pdf')));r=fitz.open(sys.argv[5])
 assert len(d)==len(r)
 diff=[]
 for i,(p,q) in enumerate(zip(d,r)):
    x=p.get_text();y=q.get_text()
    if x!=y:diff.append([i+1,re.sub(r'[-\s]','',x)==re.sub(r'[-\s]','',y)])
 summary['V05_rebuild_text_differences_after_page_extraction']=diff
 assert all(norm for _,norm in diff)
print(json.dumps(summary,indent=2,ensure_ascii=False))
