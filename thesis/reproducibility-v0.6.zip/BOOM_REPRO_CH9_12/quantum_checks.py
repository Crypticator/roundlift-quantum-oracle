"""Finite checks for Ch. 9-11. Run with Python 3.11+; writes JSON to stdout."""
from collections import Counter
from decimal import Decimal,localcontext
from fractions import Fraction as F
from itertools import product
from math import log2
import json

def graph():
    # Two public prefixes, two messages and two ciphertexts; a one-bit KDF.
    tests=cases=0
    for graph_values in product(range(2),repeat=2):
        counts=Counter()
        for keys in product(range(2),repeat=2):
            for aux in product(range(2),repeat=8):
                table=[]
                for p,m,c in product(range(2),repeat=3):
                    loc=(p*2+m)*2+c
                    expected=keys[m] if p==0 and c==graph_values[m] else aux[loc]
                    # XOR implementation. Uncompute predicate and each work register.
                    for y in (0,1):
                        y0=y
                        tape=graph_values[m]; on=int(p==0 and c==tape)
                        val=aux[loc]; kval=keys[m]
                        y^=kval if on else val
                        kval^=keys[m]; val^=aux[loc]
                        on^=int(p==0 and c==tape); tape^=graph_values[m]
                        assert (y,tape,on,val,kval)==(y0^expected,0,0,0,0)
                        tests+=1
                    table.append(expected)
                counts[tuple(table)]+=1
        assert len(counts)==256 and set(counts.values())=={4}
        # Independent raw malformed address c=2; base parser rejects it.
        for h in product(range(2),repeat=2):
            for aux in product(range(2),repeat=6):
                def H(m,c):return h[m] if graph_values[m]==c else aux[m*3+c]
                for dec in product(range(2),repeat=2):
                    for c,z in product(range(3),range(2)):
                        m=dec[c] if c<2 else None
                        accepted=m is not None and graph_values[m]==c
                        target=H(m,c) if accepted else H(z,c)
                        reference=h[m] if accepted else H(z,c)
                        assert reference==target
                        cases+=1
    return {'graph_maps':4,'tables_per_graph':256,'xor_basis_cases':tests,'classical_reference_target_cases':cases}

def moments():
    u=F(6,5)
    # Expand the four equiprobable bit pairs directly.
    cbd=(-1,0,0,1)
    pairs=list(product(cbd,repeat=2))
    results=[]
    for a,b in product((-1,1),repeat=2):
        A,B=0,0
        for x,y in pairs:
            A+=max(sum(u**(r*(a*(x+t-i)+b*(y+t-j))) for r,t in product(cbd,range(4)))/16 for i,j in product(range(4),repeat=2))
            B+=max(sum(u**(a*x*((i+e)%2-e)+b*y*((j+e)%2-e)) for e in cbd)/4 for i,j in product(range(2),repeat=2))
        C=sum(max(u**(a*(e-i)+b*(e-j)) for i,j in product(range(2),repeat=2)) for e in cbd)/4
        results.append([A/16,B/16,C])
    A,B,C=map(max,zip(*results))
    M=4*256**2*(A*B)**1024*C/u**2048
    assert (1<<247)*M.numerator < M.denominator < (1<<248)*M.numerator
    with localcontext() as ctx:
        ctx.prec=45
        log=(Decimal(M.numerator).ln()-Decimal(M.denominator).ln())/Decimal(2).ln()
    hist=Counter(max(Counter(((x+e)%4096)//2 for e in cbd).values()) for x in range(4096))
    assert hist=={3:4096}
    return {'A2':str(A),'B2':str(B),'C2':str(C),'log2_upper':str(log),'integer_comparison':'2^247 N < D < 2^248 N','N_bits':M.numerator.bit_length(),'D_bits':M.denominator.bit_length(),'offsets_check':dict(hist),'gamma':1280*log2(4/3)}

def budgets():
    cases=0
    for g,h,d in product(range(6),repeat=3):
        qg=2*(g+h+d);qh=2*(h+d);u=qg+qh+d
        assert u==2*g+4*h+5*d and qg+qh<=u
        for fal in range(d+1):
            assert 2*(g+h+fal)<=qg and 2*(h+fal)<=qh
        cases+=1
    q=1<<32
    term=F(152*(q+1)**2,1<<212)
    # A freely chosen 16-bit tape can always hit the singleton zero;
    # a zero-query, final-oracle-output game has success only 2^-16.
    assert F(152,1<<16)<1
    return {'query_triples':cases,'q32_search_value':str(term),'q32_search_minus_log2':-log2(term),'q32_classical_correctness':str(F(2*q,1<<212)),'free_tape_counterexample':{'tape_bits':16,'q':0,'free':1,'oracle':'1/65536'}}
print(json.dumps({'graph':graph(),'moments':moments(),'budgets':budgets()},indent=2))
