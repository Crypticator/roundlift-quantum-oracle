# Reproduire le contrôle scientifique et documentaire

Depuis la racine du dossier décompressé, vérifier les octets, puis choisir un nom de répertoire de sortie encore inexistant.

```bash
sha256sum -c SHA256SUMS.txt
bash BOOM_REPRO_CH9_12/reproduire.sh "$PWD/nouvelle_execution"
```

Environnement employé : Python 3.12.14, NumPy 2.3.5, PyMuPDF 1.26.6, lxml 6.1.1, unzip, Pandoc 3.1.11.1, XeTeX 0.999996 (TeX Live 2025/dev/Debian). Les deux scripts de calcul rationnel utilisent uniquement la bibliothèque standard Python. Les vérifications des fichiers requièrent PyMuPDF et lxml, le contrôle des bandes fixes utilise NumPy. Ne pas lancer Python avec l’option -O qui désactive les assertions.

- `entrees/candidat/` contient les six fichiers originaux de V0.5. Son ZIP contient aussi l’archive de la campagne V0.4, ses scripts et son registre de coûts. `entrees/articles/` contient les compagnons V4.2 et V4.4 utilisés pour les chapitres 9–10.
- `verify_manuscript.py` reproduit le calcul fourni, avec des chemins explicites et une nouvelle sortie obligatoire. `candidate_verifier_as_shipped.log` documente le défaut initial. Les JSON `replay_v0_5` et `replay_v0_6` sont des exécutions distinctes.
- `quantum_checks.py` développe directement CBD1 sur ses quatre paires de bits, calcule le majorant rationnel indépendant, examine tous les décalages de cellule, teste les petits graphes d’oracle et les comptages de requêtes. La démonstration générale figure au rapport.
- `replay_fixed_tapes.py` exécute le contrôle de [S4] dans un dossier temporaire vide et vérifie le résultat contre les données archivées. Le coût Sage du chapitre 7 relève de la campagne documentée dans l’archive V0.4.
- `check_editions.py` vérifie les vingt entrées du manifeste entrant, compare les sources, les textes et les rendus des PDF, les versions de chapitre et les objets mathématiques du DOCX. L’argument optionnel final est un PDF V0.5 recompilé pour le comparer au PDF reçu. Le premier contrôle consigné dans `editions.json` utilise aussi cet argument. Les planches figurent dans `rendus/`.
- `V0_5_vers_V0_6.diff` fournit le relevé exact des changements du manuscrit complet.

Pour recompiler les PDF dans un dossier de travail neuf avec Pandoc, XeLaTeX et les paquets du préambule, utiliser les sources `.tex` livrées. Une nouvelle compilation peut modifier les dates ou identifiants PDF. Exemple pour le volume :

```bash
mkdir nouvelle_compilation
cp MANUSCRIT_V0_6/THESIS_II_V0_6_CHAPITRES_1_12.tex nouvelle_compilation/doc.tex
(cd nouvelle_compilation && for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode doc.tex > "pass$i.log" || exit 1; done)
```

Pour régénérer le TeX depuis le Markdown, utiliser `pandoc -s -N --toc -t latex source.md -o sortie.tex`. Pour le DOCX, utiliser `pandoc -s -N --toc --mathml source.md -o sortie.docx`. Le PDF est la référence pour les renvois paginés.
