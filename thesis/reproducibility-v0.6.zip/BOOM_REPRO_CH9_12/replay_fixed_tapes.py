"""Recompute fixed-tape controls from the immutable [S4] zip in a clean temp folder."""
import sys,tempfile,subprocess,json,hashlib
from pathlib import Path
from zipfile import ZipFile
src=Path(sys.argv[1]); target=Path(sys.argv[2]); assert not target.exists()
with ZipFile(src) as z, tempfile.TemporaryDirectory() as d:
    name='ARTICLE4_SUPPLEMENTARY_DATA_V4/independent_controls/'
    script=Path(d)/'ffp_independent_fixed_tape_controls.py'; script.write_bytes(z.read(name+script.name))
    entry='INDEPENDENT_FIXED_TAPE_RESULTS.json'
    subprocess.run([sys.executable,str(script)],cwd=d,stdout=subprocess.DEVNULL,check=True)
    data=(Path(d)/entry).read_bytes()
    assert json.loads(data)==json.loads(z.read(name+entry))
    with target.open('xb') as out:out.write(data)
    print('Independent fixed/fresh lift control. JSON matches archive. SHA-256',hashlib.sha256(data).hexdigest())
