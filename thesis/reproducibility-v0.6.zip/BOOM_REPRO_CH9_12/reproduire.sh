#!/usr/bin/env bash
# Run from any current directory. The only required argument is a new output directory.
set -eu
r=$(cd "$(dirname "$0")" && pwd)
m=$(cd "$r/../MANUSCRIT_V0_6" && pwd)
in="$r/entrees/candidat"
archive="$in/THESE_II_CHAPITRES_9_12_ET_MANUSCRIT_V0_5_2026-11-18.zip"
out=$(realpath -m "${1:?fournir un nouveau repertoire de sortie}")
mkdir "$out"
unzip -p "$archive" AUDIT_BASE_V0_4/THESIS_II_V0_4_CHAPITRES_1_8.md > "$out/base_v0_4.md"
python "$r/verify_manuscript.py" "$in/THESIS_II_V0_5_CHAPITRES_1_12.md" "$out/replay_v0_5.json" > "$out/calcul-v05.log"
python "$r/verify_manuscript.py" "$m/THESIS_II_V0_6_CHAPITRES_1_12.md" "$out/replay_v0_6.json" > "$out/calcul-v06.log"
python "$r/quantum_checks.py" > "$out/quantum_checks.json"
python "$r/replay_fixed_tapes.py" "$r/entrees/articles/ARTICLE4_CLOSED_V4_4_REPRODUCIBLE.zip" "$out/fixed_tapes_new.json" > "$out/fixed_tapes.log"
python "$r/check_editions.py" "$in" "$archive" "$out/base_v0_4.md" "$m" > "$out/editions.json"
python - "$r" "$out" "$archive" <<'PY'
from pathlib import Path
from zipfile import ZipFile
import json,sys
r,out,archive=map(Path,sys.argv[1:])
with ZipFile(archive) as z:
    assert z.read('VERIFICATIONS/verify_results.json')==(out/'replay_v0_5.json').read_bytes()
for name in ['quantum_checks.json','fixed_tapes_new.json','replay_v0_5.json','replay_v0_6.json']:
    assert json.loads((r/name).read_bytes())==json.loads((out/name).read_bytes()),name
a,b=[json.loads((p/'editions.json').read_bytes()) for p in (r,out)]
for key in ['inputs','input_pages','corrected','chapter_changes','zip_manifest_verified','docx_math_objects']:
    assert a[key]==b[key],key
print('Reproduction OK')
PY
