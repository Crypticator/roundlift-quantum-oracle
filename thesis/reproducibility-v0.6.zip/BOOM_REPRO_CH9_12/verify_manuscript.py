"""Exact finite arithmetic checks for Thesis II V0.5.

These are checks of explicit finite identities and displayed inequalities.
They are NOT a verification of QROM game reductions, a Sage rerun,
or any hardness/security certificate.
"""
from fractions import Fraction as F
from math import log2,log
import json, pathlib, hashlib, argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("manuscript",type=pathlib.Path)
parser.add_argument("output",type=pathlib.Path)
args=parser.parse_args()
u=F(4,3)
a=F(744601,663552); b=F(589,576); c=F(49,48)
B=F(256,1)*(1+u)*(a*b)**1024*c*u**(-1024)
assert 0 < B < F(1,2**212)
A2=F(99036386572201,83980800000000)
B2=F(489677,480000)
C2=F(3721,2500)
u2=F(6,5)
M2=4*256**2*(A2*B2)**1024*C2*u2**(-2048)
assert 0 < M2 < F(1,2**247)
# Independent enumeration: the exact maximum floor-cell point mass under CBD1.
probs={-1:F(1,4),0:F(1,2),1:F(1,4)}
max_cell=F(0)
for offset in range(4096):
    dist={}
    for err,p in probs.items():
        val=((offset+err)%4096)//2
        dist[val]=dist.get(val,F(0))+p
    max_cell=max(max_cell,*dist.values())
assert max_cell==F(3,4)
assert 1+32+1024*10//8==1313
assert 1280*11//8==1760
assert 2304+512==2816
# Toy validity check for graph KDF identical-address handling.
# Explicit rejection fallback must use the SAME H table if (pk,z,c) hits graph.
pk='demo'; graph={(pk,m,m%2):f'h{m}' for m in range(4)}
H0={(pk,m,c):f'r{m}{c}' for m in range(4) for c in range(2)}
def Hhat(m,c):
    key=(pk,m,c)
    return graph[key] if key in graph else H0[key]
z=1
assert Hhat(z,z%2)==graph[(pk,z,z%2)]
# The following are arithmetic demonstrations of one term, not entire CCA bounds.
q=2**32
failure_search=152*(q+1)**2*F(1,2**212)
classical_correctness=2*q*F(1,2**212)
classical_guessing=F(3*q+1,2**256)
assert failure_search < F(1,2**140)
assert classical_correctness == F(1,2**179)
assert classical_guessing < F(1,2**222)
res={
 'status':'PASS -- finite arithmetic and toy coupling only',
 'decryption_failure_first_moment':{'log2_upper':log2(B.numerator)-log2(B.denominator),'strict_below_2^-212':bool(B < F(1,2**212))},
 'two_key_second_moment':{'log2_upper':log2(M2.numerator)-log2(M2.denominator),'strict_below_2^-247':bool(M2 < F(1,2**247))},
 'max_rounded_CBD1_cell_probability':str(max_cell),
 'spreadness_exponent_lower':1280*log2(F(4,3)),
 'public_key_bytes':1313,'ciphertext_bytes':1760,'tape_bytes':2816,
 'q32_failure_component_neglog2':-(log2(failure_search.numerator)-log2(failure_search.denominator)),
 'q32_classical_correctness_neglog2':179,
 'hashlib_sha256_full_md':hashlib.sha256(args.manuscript.read_bytes()).hexdigest(),
 'caveat':'Does not audit quantum oracle lemma, proof assumptions, Sage models or source hardness'
}
with args.output.open('x',encoding='utf-8') as output:
    output.write(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
