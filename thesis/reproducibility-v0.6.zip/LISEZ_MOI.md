# Thèse II · édition scientifique V0.6

Ouvrir le PDF complet dans `MANUSCRIT_V0_6/`. Ce dossier contient aussi le texte anglais modifiable (Markdown, TeX, DOCX) et l’extrait corrigé des quatre derniers chapitres.

Le verdict des douze chapitres se trouve dans `BOOM_VERDICTS_CH9_12.md`. Le rapport `BOOM_AUDIT_THESE_II_CH9_12.md` motive les résultats nouveaux et vérifie la continuité des huit premiers chapitres. Le tableau `BOOM_CORRECTIONS_CH9_12.md` localise les modifications.

Pour reproduire les calculs et comparer les éditions, suivre `BOOM_REPRO_CH9_12/README.md`. Les documents reçus restent accessibles sous `BOOM_REPRO_CH9_12/entrees/candidat/`. Leur ZIP contient l’audit et les programmes de la première campagne de huit chapitres dans `AUDIT_BASE_V0_4/`.

Les rapports sont rédigés en français et le manuscrit en anglais. La date de cette édition est le 18 novembre 2026.
