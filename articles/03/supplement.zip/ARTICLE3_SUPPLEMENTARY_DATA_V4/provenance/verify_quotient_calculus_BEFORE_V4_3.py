#!/usr/bin/env python3
"""
Exact verification for Article 3.

Standard-library only.  This script checks:
- decomposition and equal fibers;
- addition and multiplication identities;
- multioperand addition for triples;
- nested truncation/composition;
- homomorphism characterization on small domains;
- floor-LWR equivalence;
- non-divisible fiber counts;
- the explicit nearest-rounding counterexample;
- the min-entropy fiber inequality for exhaustive small integer-weight laws.

These checks support arithmetic reproducibility.  They are not cryptographic
security proofs.
"""
from itertools import product
from fractions import Fraction
import math, json

MAX_M = 48

def qr(x,M,D):
    z=x % M
    return z//D, z%D

def floor_lwr(x,q,p):
    z=x%q
    return (p*z)//q

def nearest_tie_floor_num(num,den):
    # nearest integer to num/den; exact half ties go downward
    a,r=divmod(num,den)
    if 2*r <= den:
        return a
    return a+1

counts={
    "decomposition":0,
    "fiber":0,
    "addition":0,
    "multiplication":0,
    "multioperand_triples":0,
    "composition":0,
    "floor_lwr":0,
    "entropy_weight_laws":0,
    "nondivisible_fibers":0,
}

for M in range(1,MAX_M+1):
    for D in range(1,M+1):
        if M%D:
            continue
        L=M//D

        # decomposition + fibers + floor-LWR
        fibers=[[] for _ in range(L)]
        for x in range(M):
            q,r=qr(x,M,D)
            assert x == D*q+r
            assert 0 <= r < D
            fibers[q].append(x)
            assert q == floor_lwr(x,M,L)
            counts["decomposition"] += 1
            counts["floor_lwr"] += 1
        assert all(len(f)==D for f in fibers)
        counts["fiber"] += L

        # addition and multiplication
        for a,b in product(range(M), repeat=2):
            qa,ra=qr(a,M,D); qb,rb=qr(b,M,D)
            qsum,rsum=qr(a+b,M,D)
            assert qsum == (qa+qb+(ra+rb)//D)%L
            assert rsum == (ra+rb)%D
            qprod,rprod=qr(a*b,M,D)
            assert qprod == (D*qa*qb + qa*rb + qb*ra + (ra*rb)//D)%L
            assert rprod == (ra*rb)%D
            counts["addition"] += 1
            counts["multiplication"] += 1

        # triples for modest domains
        if M <= 18:
            for xs in product(range(M), repeat=3):
                qrs=[qr(x,M,D) for x in xs]
                qwant=(sum(q for q,r in qrs)+sum(r for q,r in qrs)//D)%L
                rwant=sum(r for q,r in qrs)%D
                qgot,rgot=qr(sum(xs),M,D)
                assert (qgot,rgot)==(qwant,rwant)
                counts["multioperand_triples"] += 1

        # homomorphism iff D=1 or L=1
        is_hom=True
        for a,b in product(range(M), repeat=2):
            if qr(a+b,M,D)[0] != (qr(a,M,D)[0]+qr(b,M,D)[0])%L:
                is_hom=False
                break
        assert is_hom == (D==1 or L==1)

# composition
for M in range(1,MAX_M+1):
    for D1 in range(1,M+1):
        if M%D1: continue
        for D2 in range(1,M//D1+1):
            if M%(D1*D2): continue
            L=M//(D1*D2)
            for x in range(M):
                q1,r1=qr(x,M,D1)
                q2,r2=qr(q1,D2*L,D2)
                qdirect,rdirect=qr(x,M,D1*D2)
                assert q2==qdirect
                assert D1*r2+r1==rdirect
                counts["composition"] += 1

# non-divisible fibers
for M in range(2,40):
    for D in range(2,M+2):
        if M%D==0: continue
        a,r=divmod(M,D)
        vals=[(x//D) for x in range(M)]
        maxq=max(vals)
        fibers=[sum(v==q for v in vals) for q in range(maxq+1)]
        if a==0:
            assert fibers==[M]
        else:
            assert fibers[:-1]==[D]*a
            assert fibers[-1]==r
        counts["nondivisible_fibers"] += len(fibers)

# exhaustive small integer-weight laws for output min-entropy bound:
# max fiber mass <= D * max point mass.
for M in range(2,9):
    for D in range(1,M+1):
        if M%D: continue
        L=M//D
        for weights in product(range(3), repeat=M):
            if not any(weights): continue
            max_point=max(weights)
            max_fiber=max(sum(weights[D*q:D*q+D]) for q in range(L))
            assert max_fiber <= D*max_point
            counts["entropy_weight_laws"] += 1

# nearest-rounding mismatch
M,D,L,x=16,4,4,3
qfloor=qr(x,M,D)[0]
qnear=nearest_tie_floor_num(L*x,M)%L
assert qfloor==0 and qnear==1

result={
    "status":"PASS",
    "max_modulus_exhaustive":MAX_M,
    "checks":counts,
    "nearest_rounding_counterexample":{
        "M":M,"D":D,"L":L,"x":x,
        "floor_moddiv":qfloor,
        "nearest_lwr":qnear
    }
}
print(json.dumps(result,indent=2))
with open("VERIFICATION_RESULTS.json","w",encoding="utf-8") as f:
    json.dump(result,f,indent=2)
