# Related work notes

1. J. Alwen, S. Krenn, K. Pietrzak, D. Wichs,
   *Learning with Rounding, Revisited: New Reduction, Properties and Applications*,
   CRYPTO 2013 / IACR ePrint 2013/098.
   - Defines floor rounding `x -> floor((p/q) x)` over canonical residues.
   - Notes the choice of floor rather than ceiling/nearest is arbitrary for that formulation.

2. S. Bai, K. Boudgoust, D. Das, A. Roux-Langlois, W. Wen, Z. Zhang,
   *Middle-Product Learning with Rounding Problem and Its Applications*,
   ASIACRYPT 2019 / IACR ePrint 2019/1001.
   - Uses nearest-integer modular rounding in the main definition.
   - Explicitly notes floor rounding as another possible convention.
   - Defines MP-CLWR and proves a reduction from MP-LWE for its exact setting.

3. F.-H. Liu, Z. Wang,
   *Rounding in the Rings*, CRYPTO 2020.
   - Develops Ring/Module-LWR hardness theory.
   - Explicitly requires the rounding basis to be specified.

4. H. Jin, F.-H. Liu, Z. Wang, Y. Yu et al.,
   *Revisiting the Robustness of (R/M)LWR under Polynomial Moduli with Its Applications*,
   ASIACRYPT 2025 / IACR ePrint 2024/1696.
   - Gives modern hardness results for Ring/Module-LWR with polynomial moduli and entropic secrets.

5. A. Basso et al.,
   *Using Learning with Rounding to Instantiate Post-Quantum Cryptographic Algorithms*,
   2025 preprint / 2026 ACM journal publication.
   - Systematization of LWR theory and practical schemes.

6. J. Renes et al.,
   *Radical Ring-LWR: Efficient Key Encapsulation and Signatures from Structured Rounding*,
   IACR ePrint 2026/2078.
   - Recent structured-LWR direction, reinforcing that operator structure is part of the problem.
