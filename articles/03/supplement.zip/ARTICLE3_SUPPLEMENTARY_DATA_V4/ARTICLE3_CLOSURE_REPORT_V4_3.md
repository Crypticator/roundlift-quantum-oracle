# Article 3 — fermeture V4.3

**13 novembre 2026 — Samir Bouftass and ChatGPT (OpenAI)**

**Verdict : tampon interne accordé au périmètre arithmétique et distributionnel de l'article.** Les résultats sont valables sous leurs hypothèses explicites. Ce rapport ne certifie ni la difficulté de MODDIV, ni une réduction générale LWE–MODDIV, ni une sécurité cryptographique à 128 bits. Il s'agit d'une correction et d'une relecture interne, pas d'une expertise externe indépendante.

## Ce qui a été vérifié

Les décompositions, additions, retenues multiples, produits et troncatures imbriquées ont été relus avec leurs preuves. Les identités centrales du manuscrit V4 résistent. Deux formulations générales étaient cependant trop fortes dans les cas dégénérés ; elles sont maintenant bornées correctement.

Les preuves d'entropie sont rendues autonomes. Le lemme de post-traitement indique le simulateur, le sens du transfert, l'égalité des avantages et son coût. Les exemples ajoutés ferment les ambiguïtés sur le bruit, la loi conjointe, les changements de base et les opérateurs structurés.

## Registre de fermeture

Identifiants locaux au présent rapport.

| Point | Correction ou contrôle | Statut |
|---|---|---|
| A3-01 — domaine des fibres | Préimages prises dans Z_M avec représentants canoniques ; bijection d'ensembles distinguée d'un isomorphisme de groupes. | CLOSED |
| A3-02 — relèvement et indépendance | L=1 traité explicitement : le quotient constant est indépendant du relevé. Loi conjointe avec l'information publique précisée. | CLOSED |
| A3-03 — retenues et produit | t≥1 et preuve de la retenue multiple ajoutés. L'affirmation « les quotients ne déterminent pas le produit » est limitée à D>1 et L>1, avec témoin explicite. | CLOSED |
| A3-04 — entropie conditionnelle | Définition par probabilité moyenne de deviner, information auxiliaire finie classique, deux preuves complètes et contre-exemple à une lecture événement par événement. | CLOSED |
| A3-05 — problème LWR exact | Matrice, secret, nombre d'observations et monde nul définis ; égalité de la fonction d’arrondi distinguée des hypothèses de difficulté. | CLOSED |
| A3-06 — arrondis et structures | Contre-exemples conservés/précisés ; non-égalité n'est pas déclarée impossibilité de réduction. La réversion Hankel–Toeplitz est explicitement reconnue. | CLOSED |
| A3-07 — post-traitement | Distingueur composé explicite, égalité de l'écart d'acceptation, coût additionnel de la fonction d’arrondi et loi nulle conjointe indépendante du public. | CLOSED |
| A3-08 — bruit avant quotient | Identité pour perturbation signée et exemples de frontières : Q(As+e) n'est pas remplacé sans justification par Q(As). | CLOSED |
| A3-09 — non-divisibilité | Loi conjointe exacte, cas D>M, critère d'indépendance et relèvement avec quotient pondéré décrits. | CLOSED |
| A3-10 — bibliographie | Cinq références du manuscrit vérifiées sur leurs sources primaires ; supplément aligné sur ces références. | CLOSED pour les affirmations utilisées |
| A3-11 — reproductibilité | Résultat écrit à côté du script ; exécution propre depuis un autre dossier ; comparaison avec les résultats recalculés. | CLOSED |

Aucun point bloquant ou majeur n'est conservé dans ce périmètre après correction. Les identités élémentaires ne sont pas revendiquées comme une nouvelle théorie des nombres.

## Preuves et limites importantes

La borne d'entropie du quotient et la borne sur l'entropie de X après observation de son quotient sont deux résultats différents. Leur version conditionnelle est moyenne ; elle n'offre pas une garantie identique pour chaque événement rare.

Le transfert par post-traitement conserve l'avantage d'un distingueur en le composant avec la fonction d’arrondi. Il requiert déjà une prémisse d'indistinguabilité sur le transcript entier. Il ne prouve pas cette prémisse, ne supprime pas le bruit du problème source et n'extrait pas un secret depuis un quotient.

La différence entre une matrice uniforme et une matrice Hankel est démontrée sur leur loi affichée, sans en déduire l'impossibilité d'une réduction. La conversion exacte Hankel–Toeplitz par réversion des colonnes exige de réverser également le secret et de vérifier sa loi.

Pour les modules non divisibles, l'ancien relèvement par deux variables uniformes indépendantes ne s'applique plus. Un relèvement exact reste possible avec les masses réelles des fibres ; le texte ne confond plus ces deux procédures.

## Contrôles effectivement exécutés

Le script utilise uniquement la bibliothèque standard Python et des calculs entiers ou rationnels pour les assertions. Les domaines sont finis et annoncés ; les tests ne remplacent pas les preuves générales.

| Famille | Vérifications |
|---|---:|
| Décomposition et égalité avec floor-LWR, modules jusqu'à 48 | 5 433 chacune |
| Addition | 183 633 couples |
| Multiplication | 183 633 couples |
| Triples de retenues, modules jusqu'à 18 | 117 496 |
| Troncatures imbriquées | 15 852 |
| Lois de poids pour l'entropie de sortie | 34 316 |
| Lois conjointes pour l'entropie conditionnelle, X de taille ≤4, Z de taille 2 | 21 304 |
| Perturbations signées, modules jusqu'à 32 | 88 022 |
| Périodicité sur représentants signés | 183 633 |
| Lois conjointes quotient/reste, y compris D>M | 1 599 |
| Points de relèvement pondéré | 41 860 |

Les contre-exemples d'arrondi au plus proche, de base, de bruit et d'uniformité seulement marginale sont également contrôlés. La différence de distribution dans les deux exemples de marginalité a distance statistique exactement 1/2.

Le contrôle final part d'une copie propre sans ancien fichier de résultats, lance le script depuis un répertoire courant étranger et vérifie que le nouveau JSON est créé à l'emplacement attendu. Les résultats correspondent à la référence recalculée. Le journal et FRESH_CHECKS.json sont livrés.

## Vérification bibliographique

La convention floor et la définition du LWR sont vérifiées dans Alwen–Krenn–Pietrzak–Wichs, Section 2.1. La référence MP-CLWR est une réduction depuis MP-LWE décisionnel vers le problème computationnel publié, pas une réduction générique vers tous les problèmes Hankel arrondis. Les sources primaires confirment la nécessité de préciser la base en Ring/Module-LWR.

Pour l'article ASIACRYPT 2025, le nom des quatre auteurs et leur ordre dans la publication, les pages, le DOI, la date de mise en ligne 2025 et l'année de citation Springer 2026 ont été vérifiés. Les notes annexes ne mélangent plus cette référence avec des entrées supplémentaires non utilisées par le manuscrit. Aucune instanciation des théorèmes cryptographiques cités n'est revendiquée ici.

## Livraison et périmètre préservé

Le manuscrit autonome et sa copie dans le supplément sont identiques. La version précédente, les différences, les sources des tests, les résultats, le journal et les manifestes SHA-256 sont inclus. Le paquet général est actualisé uniquement pour l'article 3 et son suivi.

Les manuscrits et suppléments des articles 1, 2 et 4 restent octet pour octet inchangés. Aucun audit de l'article 4 n'est lancé.

**TAMPON — ARTICLE 3 V4.3 : FERMETURE INTERNE ARITHMÉTIQUE ET DISTRIBUTIONNELLE.**
