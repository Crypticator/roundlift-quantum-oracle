#!/usr/bin/env python3
"""
Exact verification for Article 3 V4.3.

Standard-library only.  This script checks:
- decomposition and equal fibers;
- addition and multiplication identities;
- multioperand addition for triples;
- nested truncation/composition;
- homomorphism characterization on small domains;
- floor-LWR equivalence;
- non-divisible fiber counts;
- the explicit nearest-rounding counterexample;
- the min-entropy fiber inequality for exhaustive small integer-weight laws.

These checks support arithmetic reproducibility.  They are not cryptographic
security proofs.
"""
from itertools import product
from fractions import Fraction
import json
from pathlib import Path
from collections import Counter

MAX_M = 48
OUT = Path(__file__).resolve().parent / "VERIFICATION_RESULTS.json"

def qr(x,M,D):
    z=x % M
    return z//D, z%D

def floor_lwr(x,q,p):
    z=x%q
    return (p*z)//q

def nearest_tie_floor_num(num,den):
    # nearest integer to num/den; exact half ties go downward
    a,r=divmod(num,den)
    if 2*r <= den:
        return a
    return a+1

counts={
    "decomposition":0,
    "fiber":0,
    "addition":0,
    "multiplication":0,
    "multioperand_triples":0,
    "composition":0,
    "floor_lwr":0,
    "entropy_weight_laws":0,
    "nondivisible_fibers":0,
}

for M in range(1,MAX_M+1):
    for D in range(1,M+1):
        if M%D:
            continue
        L=M//D

        # decomposition + fibers + floor-LWR
        fibers=[[] for _ in range(L)]
        for x in range(M):
            q,r=qr(x,M,D)
            assert x == D*q+r
            assert 0 <= r < D
            fibers[q].append(x)
            assert q == floor_lwr(x,M,L)
            counts["decomposition"] += 1
            counts["floor_lwr"] += 1
        assert all(len(f)==D for f in fibers)
        counts["fiber"] += L

        # addition and multiplication
        for a,b in product(range(M), repeat=2):
            qa,ra=qr(a,M,D); qb,rb=qr(b,M,D)
            qsum,rsum=qr(a+b,M,D)
            assert qsum == (qa+qb+(ra+rb)//D)%L
            assert rsum == (ra+rb)%D
            qprod,rprod=qr(a*b,M,D)
            assert qprod == (D*qa*qb + qa*rb + qb*ra + (ra*rb)//D)%L
            assert rprod == (ra*rb)%D
            counts["addition"] += 1
            counts["multiplication"] += 1

        # triples for modest domains
        if M <= 18:
            for xs in product(range(M), repeat=3):
                qrs=[qr(x,M,D) for x in xs]
                qwant=(sum(q for q,r in qrs)+sum(r for q,r in qrs)//D)%L
                rwant=sum(r for q,r in qrs)%D
                qgot,rgot=qr(sum(xs),M,D)
                assert (qgot,rgot)==(qwant,rwant)
                counts["multioperand_triples"] += 1

        # homomorphism iff D=1 or L=1
        is_hom=True
        for a,b in product(range(M), repeat=2):
            if qr(a+b,M,D)[0] != (qr(a,M,D)[0]+qr(b,M,D)[0])%L:
                is_hom=False
                break
        assert is_hom == (D==1 or L==1)

# composition
for M in range(1,MAX_M+1):
    for D1 in range(1,M+1):
        if M%D1: continue
        for D2 in range(1,M//D1+1):
            if M%(D1*D2): continue
            L=M//(D1*D2)
            for x in range(M):
                q1,r1=qr(x,M,D1)
                q2,r2=qr(q1,D2*L,D2)
                qdirect,rdirect=qr(x,M,D1*D2)
                assert q2==qdirect
                assert D1*r2+r1==rdirect
                counts["composition"] += 1

# non-divisible fibers
for M in range(2,40):
    for D in range(2,M+2):
        if M%D==0: continue
        a,r=divmod(M,D)
        vals=[(x//D) for x in range(M)]
        maxq=max(vals)
        fibers=[sum(v==q for v in vals) for q in range(maxq+1)]
        if a==0:
            assert fibers==[M]
        else:
            assert fibers[:-1]==[D]*a
            assert fibers[-1]==r
        counts["nondivisible_fibers"] += len(fibers)

# exhaustive small integer-weight laws for output min-entropy bound:
# max fiber mass <= D * max point mass.
for M in range(2,9):
    for D in range(1,M+1):
        if M%D: continue
        L=M//D
        for weights in product(range(3), repeat=M):
            if not any(weights): continue
            max_point=max(weights)
            max_fiber=max(sum(weights[D*q:D*q+D]) for q in range(L))
            assert max_fiber <= D*max_point
            counts["entropy_weight_laws"] += 1

# nearest-rounding mismatch
M,D,L,x=16,4,4,3
qfloor=qr(x,M,D)[0]
qnear=nearest_tie_floor_num(L*x,M)%L
assert qfloor==0 and qnear==1
nearest_case={"M":M,"D":D,"L":L,"x":x,"floor_moddiv":qfloor,"nearest_lwr":qnear}


# Additional closure checks; no old generated result is read.
counts.update({
    "signed_periodicity":0,"signed_noise":0,"conditional_entropy_laws":0,
    "joint_uniform_pairs":0,"nondivisible_joint_laws":0,"weighted_lift_points":0,
    "multiplication_information_boundary":0,"extended_carries":0,
})

for M in range(1,MAX_M+1):
    for D in range(1,M+1):
        if M%D:continue
        L=M//D
        for x,y in product(range(M),repeat=2):
            assert qr((x-M)+(y+M),M,D)==qr(x+y,M,D)
            assert qr((x-M)*(y+M),M,D)==qr(x*y,M,D)
            counts['signed_periodicity']+=1
        if M<=32:
            for x in range(-M,M):
                q,r=qr(x,M,D)
                for e in range(-D-1,D+2):
                    assert qr(x+e,M,D)[0]==(q+(r+e)//D)%L
                    counts['signed_noise']+=1
        pairs=Counter((qr(x,M,D)[0],qr(x,M,D)[1]) for x in range(M))
        assert len(pairs)==M and set(pairs.values())=={1}
        outpairs=Counter((qr(x,M,D)[0],qr(y,M,D)[0]) for x,y in product(range(M),repeat=2))
        assert len(outpairs)==L*L and set(outpairs.values())=={D*D}
        counts['joint_uniform_pairs']+=1
        if D>1 and L>1:
            assert qr(0,M,D)[0]==qr(1,M,D)[0]==0
            assert qr(D*0,M,D)[0]==0 and qr(D*1,M,D)[0]==1
        elif D==1:
            assert all(qr(x,M,D)[0]==x for x in range(M))
        else:
            assert all(qr(x,M,D)[0]==0 for x in range(M))
        counts['multiplication_information_boundary']+=1
        for t in (1,2,4,7):
            xs=[(-1)**i*(M+i+D) for i in range(t)]
            qrs=[qr(x,M,D) for x in xs]
            carry=sum(r for q,r in qrs)//D
            assert 0<=carry<=t-1
            assert qr(sum(xs),M,D)==((sum(q for q,r in qrs)+carry)%L,sum(r for q,r in qrs)%D)
            counts['extended_carries']+=1

# Average conditional guessing probabilities, including zero-probability Z rows.
# All joint integer-weight laws on two Z values, M<=4, weights in {0,1,2}.
for M in range(1,5):
    for D in range(1,M+1):
        if M%D:continue
        L=M//D
        for w in product(range(3),repeat=2*M):
            if not any(w):continue
            rows=(w[:M],w[M:])
            guess_xz=sum(max(row) for row in rows)
            guess_qz=sum(max(sum(row[D*q:D*(q+1)]) for q in range(L)) for row in rows)
            guess_xzq=sum(sum(max(row[D*q:D*(q+1)]) for q in range(L)) for row in rows)
            assert guess_qz<=D*guess_xz
            assert guess_xzq<=L*guess_xz
            counts['conditional_entropy_laws']+=1

# Nondivisible joint law and exact independence criterion, including D>M and M=1.
for M in range(1,40):
    for D in range(1,2*M+2):
        a,rem=divmod(M,D)
        joint=Counter(qr(x,M,D) for x in range(M))
        margq=Counter(q for q,r in joint for _ in range(joint[q,r]))
        margr=Counter(r for q,r in joint for _ in range(joint[q,r]))
        independent=True
        for q,r in product(range((M-1)//D+1),range(D)):
            valid=q*D+r<M
            assert joint[q,r]==int(valid)
            if joint[q,r]*M!=margq[q]*margr[r]:independent=False
        assert independent==(rem==0 or D>M)
        for q in margq:
            size=min(D,M-D*q)
            assert margq[q]==size
            for r in range(size):
                assert Fraction(size,M)*Fraction(1,size)==Fraction(1,M)
                counts['weighted_lift_points']+=1
        counts['nondivisible_joint_laws']+=1

# Counterexamples are exact, not numerical simulations.
assert qr(3+1,16,4)[0]==1 and qr(3,16,4)[0]==0
assert qr(0-1,16,4)[0]==3 and qr(0,16,4)[0]==0
assert (qr(2,8,2)[0],qr(1,8,2)[0])==(1,0)
assert (qr(1,8,2)[0]+qr(1,8,2)[0],qr(1,8,2)[0])==(0,0)
diag=Counter((z//2,z//2) for z in range(4))
assert diag=={(0,0):2,(1,1):2}
tv_diag=sum(abs(Fraction(diag[a,b],4)-Fraction(1,4)) for a,b in product(range(2),repeat=2))/2
assert tv_diag==Fraction(1,2)
public=Counter((z,z//2) for z in range(4))
tv_public=sum(abs(Fraction(public[z,q],4)-Fraction(1,8)) for z,q in product(range(4),range(2)))/2
assert tv_public==Fraction(1,2)
lift=Counter((z,2*z+rho) for z,rho in product(range(2),repeat=2))
assert Counter(b for z,b in lift)=={0:1,1:1,2:1,3:1}
assert all(z==b//2 for z,b in lift)
weights=(2,2,1,0)
assert max(weights[2:])==sum(weights[2:])==1
assert Fraction(2,5)*2<1  # the claimed per-event leakage bound would fail
assert Fraction(3,5)<=Fraction(2,5)*2  # the average bound holds

# Column reversal gives Toeplitz and the corresponding reversed secret.
for ribbon in product(range(3),repeat=3):
    H=((ribbon[0],ribbon[1]),(ribbon[1],ribbon[2]))
    T=tuple(tuple(reversed(row)) for row in H)
    assert T[0][0]==T[1][1]
    for v in product(range(3),repeat=2):
        assert tuple(sum(H[i][j]*v[j] for j in range(2))%3 for i in range(2))==tuple(sum(T[i][j]*v[1-j] for j in range(2))%3 for i in range(2))

result={
    "status":"PASS",
    "revision":"V4.3",
    "arithmetic_only":True,
    "classical_finite_side_information":True,
    "conditional_entropy_domain":{"X_max_size":4,"Z_size":2,"joint_weights":[0,1,2]},
    "signed_noise_max_modulus":32,
    "nondivisible_joint_max_modulus":39,
    "marginal_only_counterexamples_tv":"1/2",
    "hardness_certification":False,
    "max_modulus_exhaustive":MAX_M,
    "checks":counts,
    "nearest_rounding_counterexample":nearest_case
}
print(json.dumps(result,indent=2))
with OUT.open("w",encoding="utf-8") as f:
    json.dump(result,f,indent=2)
    f.write("\n")
