# Related work and source checks — Article 3 V4.3

These notes cover only the five references actually used in the manuscript.
They identify conventions and published contribution scope; they do not instantiate
the cited cryptographic theorems for MODDIV.

1. Banerjee, Peikert, Rosen, *Pseudorandom Functions and Lattices*, EUROCRYPT 2012,
   LNCS 7237, pp. 719–737. Publisher record (authors, pages, title, DOI):
   https://doi.org/10.1007/978-3-642-29011-4_42
   The historical introduction of LWR is also identified by reference 2.

2. Alwen, Krenn, Pietrzak, Wichs, *Learning with Rounding, Revisited*, CRYPTO 2013.
   Primary full text: https://crypto.ethz.ch/publications/files/AKPW13.pdf
   Section 2.1 defines floor rounding on canonical representatives; Definition 2.8
   specifies the uniform-secret LWR problem. Section 2 recalls average conditional
   min-entropy and the finite-leakage bound. Footnote 8 distinguishes the choice
   of rounding convention. No parameter-specialized reduction is imported here.

3. Bai, Boudgoust, Das, Roux-Langlois, Wen, Zhang, *Middle-Product Learning with
   Rounding Problem and Its Applications*, ASIACRYPT 2019, pp. 55–81.
   https://eprint.iacr.org/2019/1001
   https://doi.org/10.1007/978-3-030-34578-5_3
   The primary abstract and introduction identify the direction from decisional
   MP-LWE to the computational MP-CLWR problem (Section 4). This is not a generic
   decision-to-decision claim for all Hankel rounded observations.

4. Liu, Wang, *Rounding in the Rings*, CRYPTO 2020, pp. 296–326.
   https://doi.org/10.1007/978-3-030-56880-1_11
   Primary indexed full-text passage, p. 4:
   https://iacr.org/archive/crypto2020/12171112/12171112.pdf
   The rounding basis must be specified and can affect reductions. The primary
   publisher abstract confirms the Ring/Module-LWR scope. Direct PDF retrieval
   was blocked; the indexed passage and publisher record were inspected, not an
   independently downloaded complete paper.

5. Wang, Jin, Liu, Yu, *Revisiting the Robustness of (R/M)LWR Under Polynomial
   Moduli with Its Applications*, ASIACRYPT 2025, LNCS 16247, pp. 167–199.
   https://doi.org/10.1007/978-981-95-5099-9_6
   Publisher metadata: online 8 December 2025; citation/copyright year 2026.
   The primary abstract concerns entropic secret laws and polynomial moduli.
   This published author order is retained. The corresponding revised preprint
   https://eprint.iacr.org/2024/1696 lists the authors in a different order;
   publication and preprint metadata are not silently interchanged.

No full independent audit of these five external papers is claimed. Superseded
supplement notes are preserved under `provenance/`, not used as current references.
