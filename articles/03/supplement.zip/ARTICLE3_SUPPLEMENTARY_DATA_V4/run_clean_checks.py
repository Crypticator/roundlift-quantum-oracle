#!/usr/bin/env python3
"""Run only Article 3 from a clean copy, with a foreign working directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

root=Path(__file__).resolve().parent
script=root/'verify_quotient_calculus.py'
expected=json.loads((root/'VERIFICATION_RESULTS.json').read_text()) if (root/'VERIFICATION_RESULTS.json').exists() else None
with tempfile.TemporaryDirectory(prefix='article3-v4-3-clean-') as tmp:
    work=Path(tmp)/'source'; work.mkdir()
    foreign=Path(tmp)/'foreign'; foreign.mkdir()
    shutil.copy2(script,work/script.name)
    target=work/'VERIFICATION_RESULTS.json'
    target.unlink(missing_ok=True)
    started=time.time_ns()
    p=subprocess.run([sys.executable,str(work/script.name)],cwd=foreign,
                     capture_output=True,text=True)
    assert p.returncode==0,p.stdout+p.stderr
    assert target.exists() and target.stat().st_mtime_ns>=started
    result=json.loads(target.read_text())
    assert result['nearest_rounding_counterexample']=={'M':16,'D':4,'L':4,'x':3,'floor_moddiv':0,'nearest_lwr':1}
    if expected is not None:assert result==expected,'fresh result differs from reference snapshot'
    assert not (foreign/'VERIFICATION_RESULTS.json').exists()
    shutil.copy2(target,root/'VERIFICATION_RESULTS.json')
    (root/'RUN.log').write_text(p.stdout+p.stderr)
    checks={'status':'PASS','scope':'Article 3 quotient identities, distributions and arithmetic only',
            'python':sys.version,'started_ns':started,'finished_ns':time.time_ns(),
            'foreign_cwd':True,'prior_generated_json_absent':True,'output_fresh':True,
            'matches_reference_snapshot':None if expected is None else True,
            'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
            'results_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
            'machine_checked_security_proof':False,'other_articles_run':False}
    (root/'FRESH_CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))
