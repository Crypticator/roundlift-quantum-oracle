# Article 3 — V4.3

Read `ARTICLE3_REVISED_V4.md` and `ARTICLE3_CLOSURE_REPORT_V4_3.md`.
The paper proves arithmetic and explicitly scoped distributional statements.
It does not establish a new LWE/LWR hardness theorem or certify a cryptosystem.

With Python 3 (standard library only):

```bash
python run_clean_checks.py
```

The runner copies the current checker into a clean temporary directory, removes
any prior generated output and runs from a foreign working directory. The checker
writes `VERIFICATION_RESULTS.json` beside its own source, not in the caller's cwd.
The runner compares the fresh output with the supplied reference snapshot, if any.
`FRESH_CHECKS.json` and `RUN.log` record the actual execution.

Checks cover finite exact arithmetic, probability-law identities, conditional
guessing probabilities and counterexamples. Bounds of the finite domains are in
the source and JSON; no exhaustive cryptographic security audit is claimed.

Files under `provenance/` are historical, never used by the current runner.
In particular, the old checker there retains its historical cwd behavior.
The delivered manifest covers every other file; a fresh run changes the timestamped
execution report, so that manifest describes the delivery rather than future runs.
