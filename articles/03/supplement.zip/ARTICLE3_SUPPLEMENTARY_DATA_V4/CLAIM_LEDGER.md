# Claim ledger — Article 3 V4.3

- PROVED: quotient/remainder decomposition, fibers, uniform-input independence,
  addition, multiplication, multioperand carries and aligned nested truncation.
- PROVED: output and average conditional min-entropy bounds for finite classical
  variables; the two guessing tasks are distinguished.
- PROVED: scalar equivalence to floor-LWR when M=D L; the complete LWR problem
  additionally fixes matrix law, secret law, dimensions, rounding and null law.
- PROVED: advantage-preserving deterministic post-processing of an existing
  joint indistinguishability premise; the composed distinguisher is explicit.
- PROVED: nondivisible joint law, constant-quotient exception and weighted lift.
- COUNTEREXAMPLES: nearest rounding, basis change, marginal-only uniformity,
  signed perturbations crossing boundaries and per-event entropy interpretation.
- NOT CLAIMED: new number theory, independent structured remainders, universal
  source hardness, removal of LWE noise, secret extraction, IND-CPA/IND-CCA,
  PQ-128, or impossibility of reductions between structured descriptions.
- REVIEW STATUS: internal arithmetic/distributional closure; no external peer
  review and no new audit of the companion articles.
