# C1-K4 in the QROM: Rigidity, Spreadness, and the Remaining Decryption-Failure Barrier

**Revision V4 — 13 November 2026 — canonical cross-reference and bibliography synchronization**

**Samir Bouftass and ChatGPT (OpenAI)**

## Abstract

We revisit the C1-K4-P12-CBD1 KEM candidate in the quantum random-oracle model. The base public-key encryption scheme has a proved nonzero decryption-failure probability below \(2^{-212}\) and is conditionally IND-CPA under two explicit small-secret Module-LWE source assumptions. We audit two Fujisaki–Okamoto routes.

For the compact wrapper with re-encryption and implicit rejection, we prove two structural properties. First, the deterministic re-encryption-check transformation is rigid by construction. Second, the randomized PKE is \(\gamma\)-spread with
\[
\gamma \ge 1280\log_2(4/3)=531.247999\ldots.
\]

The decryption-failure analysis is only partially closed. Existing correctness gives
\[
\delta_{ik}<2^{-212}.
\]
The generic variance consequence \(\sigma_{\delta ik}<2^{-106}\) is weak, while Article 4 proves the stronger second-moment certificate
\[
\mathbb E[p_m(\omega)^2]<2^{-247},
\qquad
\sigma_{\delta ik}<2^{-123.5}.
\]
A separate integrated mean-only bound also gives substantially better FFP-NK diagnostics than the earlier single-threshold estimate, but these terms have not yet been composed with all losses of the exact KEM transformation.

For FFP-NG, the earlier statement that only discrete-Gaussian results were available is no longer current. Majenz and Sisinni (ePrint 2025/1997) announce an analysis for Ring/Module-LWE with a subgaussian family including centered binomials. This materially weakens the previous bibliographic obstruction, but the applicability of their exact hypotheses to the C1-K4 compression, lifting, secret law, and failure interface is not established here.

We also record a 256-bit key-confirmation variant with a 1792-byte transmitted ciphertext. A generic HHK/QFO theorem interface appears relevant, but this article does not instantiate the complete wrapper, oracle domains, query budgets, KDF variants, correctness term, and all reduction losses into one final inequality. It is therefore presented as a conditional route, not as a completed QROM proof for this frozen profile.

Thus the compact C1-K4 KEM is not certified at 128 post-quantum bits by this article. The remaining work is to match the exact FFP-NG theorem hypotheses and to complete the end-to-end QROM accounting.

## 1. Frozen compact wrapper

Let
\[
\operatorname{Enc}_1(pk,m)=\operatorname{Enc}(pk,m;G(pk,m)),
\]
with canonical ciphertext encoding. Key generation stores a 256-bit fallback secret \(z\). Encapsulation samples uniform \(m\), computes \(c=\operatorname{Enc}_1(pk,m)\), and derives the session key from a domain-separated hash of \((pk,m,c)\). Decapsulation decrypts to \(m'\), recomputes \(\operatorname{Enc}_1(pk,m')\), compares the complete canonical ciphertext bytes, and returns either the good key or a deterministic fallback key derived from \((pk,z,c)\). No validity bit is exposed.

The public key remains 1313 bytes and the compact ciphertext remains 1760 bytes.

## 2. Rigidity

Define deterministic decryption \(\operatorname{Dec}_1\) to output \(m'\) only when decrypting and re-encrypting produces the exact input ciphertext; otherwise it outputs failure. Then
\[
\operatorname{Dec}_1(sk,c)=m\ne\bot
\Longrightarrow
c=\operatorname{Enc}_1(pk,m).
\]

Hence the deterministic scheme is rigid exactly. No injectivity of the encryption-randomness map is required.

## 3. Spreadness

Fix \(pk,m\) and an arbitrary target ciphertext \((c_1,c_2)\). Condition on the ephemeral secret \(r\) and the lifting vector \(\rho\).

For a fixed pre-error coefficient \(x\), the map
\[
e\in\{-1,0,1\}
\longmapsto
\left\lfloor\frac{[x+e]_{4096}}{2}\right\rfloor
\]
assigns probability at most \(3/4\) to any fixed output value under CBD1. The 1024 coefficients of \(e_1\) affect the 1024 compressed coefficients of \(c_1\) independently once \(r\) is fixed. The 256 coefficients of \(e_2\) affect the 256 coefficients of \(c_2\) independently once \((r,\rho)\) is fixed. Therefore
\[
\Pr[\operatorname{Enc}(pk,m)=c\mid r,\rho]
\le(3/4)^{1280}.
\]

Averaging over \((r,\rho)\) preserves the same upper bound, so
\[
\boxed{\gamma\ge1280\log_2(4/3)=531.247999\ldots.}
\]

## 4. FFP-NK: certified pieces and present limitation

Let \(\delta_{wc}\) be the averaged worst-message decryption-failure probability. Article 1, Sections 4–5 and Corollary 4, proves
\[
\delta_{wc}<2^{-212}.
\]
The Failing-Gracefully definitions give
\[
\delta_{ik}\le\delta_{wc}<2^{-212}.
\]

If \(p_m(\omega)\) is the failure probability over a fresh key for fixed message and complete encryption tape, then \(0\le p_m(\omega)\le1\), so
\[
\operatorname{Var}[p_m(\omega)]
\le
\mathbb E[p_m(\omega)]
\le
\delta_{ik}.
\]
Thus the generic consequence is only
\[
\sigma_{\delta ik}<2^{-106}.
\]

Article 4 strengthens this with an exact same-randomness/two-independent-key calculation:
\[
\mathbb E_\omega[p_m(\omega)^2]<2^{-247},
\qquad
\sigma_{\delta ik}<2^{-123.5}.
\]
This is mathematically stronger, but the variance-style QROM term obtained from it remains loose.

There is also a distinct consequence using only the mean. We use Hövelmanns–Hülsing–Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform*, published version, Lemma 4, equation (30), p. 439. Here \(q\) counts the adversary's eCO.RO queries before the final oracle evaluation; the additional final evaluation is accounted for by \(q+1\). The bound is stated in that lemma's extractable-oracle model. One fixed adversary is used for every threshold; its uniform input bits are mapped to the honest CBD1 and lifting distributions. Identifying this \(q\) with a complete KEM reduction's query budget is a separate composition obligation.

With Markov's inequality, the resulting tail bound is
\[
\Pr[F_{\rm out}\ge t]
\le
\min\!\left(1,\frac{152(q+1)^2\delta_{ik}}{t}\right).
\]
Writing
\[
a=152(q+1)^2\delta_{ik},
\]
integration of this tail for the same output variable gives, for \(0<a<1\),
\[
\mathbb E[F_{\rm out}]
\le
a\bigl(1+\ln(1/a)\bigr),
\]
where \(\ln\) is the natural logarithm.
At \(\delta_{ik}=2^{-212}\), the corresponding diagnostic values
\[
-\log_2(\text{bound})
\]
are approximately \(195.607\), \(165.836\), \(134.129\), and \(70.992\) for
\[
q=1,\quad2^{16},\quad2^{32},\quad2^{64},
\]
respectively.

These values describe one FFP-NK term only. They are not KEM security bits and do not include FFP-NG, passive security, KDF/oracle composition, or other reduction losses.

## 5. FFP-NG: updated literature status

FFP-NG asks whether a public-key-dependent adversary can choose message/randomness pairs whose failure behavior differs between the displayed key and an independent key. Passive IND-CPA security does not imply FFP-NG security.

Earlier work treated a PVW-style LWE setting with discrete-Gaussian errors. A later preprint by Christian Majenz and Fabrizio Sisinni, *Provable decryption failure security for practical lattice-based PKE*, IACR ePrint 2025/1997, states that its analysis extends to Ring-LWE and Module-LWE and considers a subgaussian family containing centered binomials.

This is directly relevant to C1-K4 and invalidates the broad statement that available FFP-NG reductions are restricted to discrete Gaussians. However, this article has not established that the newer theorem applies unchanged to all of the following C1-K4 details:

- the exact CBD1 secret and error laws;
- the module dimensions and modulus \(4096\);
- the two compression divisors \(Q=4\) and \(C=2\);
- the randomized lifting interface;
- the dependent rounding remainders in the decryption-failure event;
- the exact FFP game induced by the compact wrapper.

Therefore the correct present statement is:

\[
\boxed{\text{FFP-NG applicability to the exact C1-K4 interface remains unproved here.}}
\]

This is an open matching problem, not an impossibility result.

## 6. Compact QROM theorem interface

The Failing-Gracefully analysis decomposes the relevant failure-finding obligation into FFP-NG and FFP-NK components and provides QROM bounds for FO-style transformations under additional structural hypotheses such as spreadness.

For C1-K4, rigidity and spreadness are discharged, and Article 4 supplies improved FFP-NK bounds. A complete theorem instantiation would still need to specify and compose, in one place:

1. the exact passive-security premise and its reduction loss;
2. the exact compact wrapper and parsing rules;
3. all random-oracle/KDF domains and domain separation;
4. the FFP-NG theorem used and proof that its hypotheses match C1-K4;
5. the chosen FFP-NK bound and its query convention;
6. \(q_G,q_H,q_{H'},q_D\) and any plaintext-checking budget;
7. the nonzero correctness term;
8. explicit versus implicit rejection and the corresponding transformation;
9. the final IND-CCA advantage inequality and running-time overhead.

This article does not yet provide that complete composition. Its result is therefore a **conditional theorem interface**, not a finished QROM IND-CCA proof for the frozen profile.

## 7. QFO key-confirmation route

A corrected HHK/QFO-style route can add a 256-bit confirmation tag
\[
d=H'(m),
\]
so the transmitted ciphertext becomes
\[
(c,d)
\]
with size
\[
1760+32=1792\text{ bytes}.
\]

This format fact is exact. Generic QFO theorems provide a possible route from suitable OW-CPA/OW-PCA premises and correctness to QROM IND-CCA security, with rigidity and plaintext-checking/query terms appearing in the reduction.

For the exact C1-K4 instantiation, however, this article does not give the complete algorithms, oracle programming, all query counts, and the final composed inequality. The route is therefore recorded as **available at the theorem-interface level**, not as an already-instantiated proof. Its known square-root-style losses also make a concrete 128-bit conclusion nontrivial.

## 8. Verdict

The corrected status is:

- compact 1760-byte C1-K4 KEM: **conditional QROM route; not 128-bit certified here**;
- rigidity: **PROVED**;
- spreadness: **PROVED**, \(\gamma\ge531.247999\) bits;
- FFP-NK first moment: **PROVED** from correctness;
- FFP-NK second moment: **PROVED in Article 4** after the Cauchy–Schwarz repair;
- integrated mean-only FFP-NK bound: **PROVED in the stated search model**, but not a complete KEM bound;
- FFP-NG: **OPEN for the exact C1-K4 interface**, with newer Ring/Module-LWE/CBD-relevant literature requiring an explicit hypothesis match;
- 1792-byte QFO confirmation variant: **conditional theorem interface**, not an end-to-end instantiated QROM certificate.

The next step is not to change parameters. It is to match the exact FFP-NG theorem hypotheses and then write one complete advantage bound for the chosen QROM transformation.

## References

- Samir Bouftass and ChatGPT (OpenAI), *C1-K4-P12-CBD1: Exact Correctness, Conditional Security, and Reproducible Attack Estimates*, Article 1, consolidated V4, 13 November 2026. Sections 3–5 specify the PKE and prove its correctness bound; Sections 6–8 state the source and oracle interfaces. Companion manuscript included in this package.
- Samir Bouftass and ChatGPT (OpenAI), *Find-Failing-Plaintext Analysis of C1-K4-P12-CBD1*, Article 4, revised V4, 13 November 2026. Sections 3–5. Companion manuscript included in this package.
- Dennis Hofheinz, Kathrin Hövelmanns, and Eike Kiltz, *A Modular Analysis of the Fujisaki–Okamoto Transformation*, TCC 2017; corrected full version, Cryptology ePrint Archive 2017/604. https://eprint.iacr.org/2017/604. The classical and quantum theorem interfaces must be distinguished; this citation does not complete the QROM instantiation in Sections 6–7.
- Kathrin Hövelmanns, Andreas Hülsing, and Christian Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform*, ASIACRYPT 2022, LNCS 13794, pp. 414–443. https://doi.org/10.1007/978-3-031-22972-5_15. This article uses the published-version Lemma 4, equation (30), p. 439; preprint numbering differs.
- Christian Majenz and Fabrizio Sisinni, *Provable security against decryption failure attacks from LWE*, CRYPTO 2024, LNCS 14921, pp. 456–485. https://doi.org/10.1007/978-3-031-68379-4_14. https://eprint.iacr.org/2024/835. This is a reference for the earlier PVW-style setting, not an instantiation for C1-K4.
- Christian Majenz and Fabrizio Sisinni, *Provable decryption failure security for practical lattice-based PKE*, Cryptology ePrint Archive 2025/1997, 2025. https://eprint.iacr.org/2025/1997. The public notice and abstract motivate Section 5; the exact full theorem hypotheses have not been matched to C1-K4 here.
