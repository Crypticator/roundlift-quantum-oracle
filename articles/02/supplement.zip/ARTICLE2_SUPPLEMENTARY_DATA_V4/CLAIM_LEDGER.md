# Claim ledger — Article 2 V4.2

- PROVED HERE: rigidity, spreadness, direct FFP-CPA search bound, coherent graph
  simulation of the exact KDF and implicit rejection.
- CONDITIONAL: quantum passive reduction and Theorem 4 in the stated single-user,
  key-first, fresh-ideal-oracle model with classical decapsulation queries, under
  the exact four-row/five-row quantum Module-LWE assumptions at augmented resources.
- IMPORTED: Article 1 worst-case correctness, including positive failure probability.
- OPTIONAL IMPORT: Article 4 second moment; not needed for Theorem 4.
- OPEN REFINEMENT: exact match to a sharper FFP-NG theorem.
- NOT ESTABLISHED: quantum source lower bounds, concrete expander security,
  gate-level extraction costs, PQ-128 certification, shared prior oracle state,
  quantum decapsulation, multi-user security or a theorem for the 1792-byte variant.
- VALIDATED BY CODE: finite sampler, graph/rejection and arithmetic identities.
  The code is not a complete formal security proof.
- REVIEW: internal scoped closure, not an independent external peer review.
