# Article 2 — rapport de fermeture V4.2

**13 novembre 2026 — Samir Bouftass and ChatGPT (OpenAI)**

**Verdict : fermeture interne accordée au théorème conditionnel et au périmètre explicitement défini.** Ce verdict n'est ni une expertise externe indépendante, ni une certification de sécurité à 128 bits. La rédaction de la nouvelle preuve et sa présente relecture ont été effectuées dans la même intervention.

## Résultat concret

L'article contient maintenant une chaîne complète pour le KEM compact de 1760 octets : sécurité passive quantique sous les deux hypothèses sources exactes, borne directe de recherche d'échecs, simulation du KDF avec rejet implicite, puis inégalité d'avantage composée. Les paramètres et algorithmes sont conservés.

La fermeture porte sur le modèle **un utilisateur, clé publique donnée avant les premières requêtes, oracles idéaux neufs, requêtes de déchiffrement classiques**. Elle ne s'étend pas à un état quantique antérieur corrélé aux oracles, à un oracle de déchiffrement en superposition ou à un hash concret.

Le point décisif est de ne plus imposer FFP-NG à toute route QROM. La correction au pire cas permet une borne plus grossière, à l'aide du lemme de recherche HHM, sans utiliser le résultat du second moment de l'article 4. L'adaptation FFP-NG reste une piste pour améliorer cette borne.

## Registre des corrections

Identifiants locaux à ce rapport ; ils ne prétendent pas reproduire la numérotation d'un audit antérieur.

| Point | Correction / contrôle | Verdict |
|---|---|---|
| A2-01 — sources classiques ou quantiques | Les deux distributions Module-LWE sont écrites ; les hypothèses quantiques portent sur les simulateurs aux ressources augmentées. | CLOSED dans ce modèle |
| A2-02 — matrice issue d'une graine | Programmation cohérente de la tranche de matrice avant toute requête ; simulation des bits hauts ignorés par le parseur. Aucune transposition d'une borne de collision classique aux requêtes quantiques. | CLOSED dans le modèle clé d'abord |
| A2-03 — échecs | Borne FFP-CPA directe issue de la correction au pire cas ; ordre espérance/maximum explicite ; probabilité non nulle conservée. | CLOSED |
| A2-04 — KDF exact | Simulation par graphe de H(pk,m,c), y compris collisions entre chiffrés et adresses de repli situées sur le graphe. | CLOSED |
| A2-05 — rejet implicite | Simulation depuis le rejet explicite avec un unique secret de repli, le même H et des réponses répétées cohérentes. | CLOSED |
| A2-06 — normalisation | Le biais du KEM est distingué de l'écart d'acceptation du PKE et des sources ; facteur 2 retenu sous la racine. | CLOSED |
| A2-07 — composition | Théorème 4 : budgets Q_G, Q_H, U, terme d'échec, spreadness, perte passive et recherche du message réunis. | CLOSED conditionnellement |
| A2-08 — temps et mémoire | Coût du simulateur, extraction et oracles auxiliaires chargés aux sources ; aucune conversion en coût concret n'est prétendue. | CLOSED pour l'énoncé symbolique |
| A2-09 — FFP-NG plus serré | Littérature CBD/Module-LWE signalée ; correspondance exacte non établie. Cette branche n'est pas utilisée dans le théorème principal. | OPEN, raffinement facultatif |
| A2-10 — données reproductibles | Script, copies du manuscrit, registre des affirmations et résultats synchronisés ; exécution propre et indépendante du dossier courant. | CLOSED |

## Vérifications de preuve ciblées

- Lecture de la version intégrale HHM : définition de l'avantage CPA, lemme 5 (51), corollaire 8 (69)–(70), coût et budgets de requêtes. Les deux pages du corollaire ont également été contrôlées visuellement pour éviter une erreur d'extraction des racines ou exposants.
- Le passage de la correction à la recherche d'échecs fixe d'abord la clé, applique la borne de densité maximale, puis moyenne. Il n'échange pas maximum et espérance.
- Le graphe utilise l'adresse complète contenant le message. Deux messages donnant le même chiffré restent donc deux adresses distinctes.
- Le simulateur calcule et efface ses registres auxiliaires. Le texte ne traite pas une liste de requêtes classiques comme une simulation de requêtes quantiques.
- Le repli reste H(pk,z,c), avec le même domaine que le bon hash. Aucun nouveau bit de validité ou tag de branche n'est ajouté.
- Le théorème ne dépend pas de l'article 4. Son résultat de second moment est seulement cité comme amélioration possible, sans lui attribuer ici un tampon.

## Contrôles exécutés

Depuis une copie propre, sans ancien results.json et avec un répertoire courant étranger au script :

- 4096 positions de rounding, y compris les frontières et le retour modulo ; masse maximale retrouvée : 3/4.
- 65536 mots bruts : 16 préimages pour chaque coefficient modulo 4096 ; lois CBD1 et lift vérifiées exactement.
- 64 tables uniformes de hash dans les modèles miniatures exhaustifs ; 2048 états de base pour la simulation réversible.
- 13824 cas de déchiffrement/repli, dont 6912 avec collision de chiffrés ; chaînes malformées incluses.
- 256 grilles vérifiant l'ordre espérance/maximum et le plafonnement des probabilités.
- Normalisation du terme passif, budgets de requêtes, bornes plafonnées et quatre diagnostics FFP-NK reproduits.

Ces programmes vérifient des identités finies et des calculs. Ils ne constituent pas une formalisation automatique de la preuve QROM ou des hypothèses de difficulté. Le journal et les résultats frais sont inclus.

## Limites maintenues

La borne est volontairement conservatrice et peut devenir peu informative à grands budgets de requêtes. Il n'existe ici ni borne inférieure prouvée sur le coût des attaques quantiques, ni coût d'extraction en portes, ni certification d'un expandeur concret. Les estimations classiques MATZOV/coded-dual de l'article 1 ne sont pas utilisées comme hypothèses quantiques chiffrées.

L'article n'annonce donc pas « 128 bits post-quantiques certifiés ». La variante à 1792 octets reste une observation de format et n'est pas substituée au KEM compact.

## Périmètre de livraison

Seuls l'article 2, son supplément et les documents de suivi du paquet sont mis à jour. Les manuscrits et suppléments des articles 1, 3 et 4 sont conservés octet pour octet. La version antérieure de l'article 2 et le diff sont fournis. Les rapports V4 antérieurs sont historiques ; le présent rapport gouverne le statut de l'article 2 V4.2.

**Tampon : ARTICLE 2 — FERMETURE SCIENTIFIQUE INTERNE CONDITIONNELLE.** Prêt pour une contrelecture ciblée de la nouvelle chaîne de réduction. Aucun travail sur l'article 3 n'est lancé par cette livraison.
