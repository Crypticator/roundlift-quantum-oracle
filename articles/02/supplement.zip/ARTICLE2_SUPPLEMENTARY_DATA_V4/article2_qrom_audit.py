#!/usr/bin/env python3
"""Article 2 V4.2 finite identities and arithmetic, not a machine-checked proof.

Pure Python; output is freshly generated beside the script even from a foreign cwd.
No pre-existing JSON is read. No hardness or 128-bit certification is inferred.
"""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
import math

OUT = Path(__file__).resolve().parent / 'results.json'
N, K, P = 256, 4, 4096
RAW = [a-b for a,b in product((0,1), repeat=2)]
assert Counter(RAW) == {-1:1, 0:2, 1:1}

# All rounding positions, including wrap-around at 0 and 4095.
max_prob = max(Fraction(max(Counter(((x+e)%P)//2 for e in RAW).values()),4)
               for x in range(P))
assert max_prob == Fraction(3,4)
gamma = 1280*math.log2(4/3)
# Full raw response, not merely the parsed coefficient.
raw_counts = Counter(w % 4096 for w in range(65536))
assert len(raw_counts)==4096 and set(raw_counts.values())=={16}
cbd_counts = Counter((b&1)-((b>>1)&1) for b in range(256))
assert cbd_counts == {-1:64, 0:128, 1:64}
rho_counts = Counter(((b&15)%4, (b>>4)%4) for b in range(256))
assert len(rho_counts)==16 and set(rho_counts.values())=={16}

# Tiny graph simulation: m,c,key are bits. E(m)=m xor g(m).
# Enumerate all g, h, H0, including constant/noninjective E.
uniform_functions = 0
rejection_cases = 0
coherent_basis_cases = 0
collision_cases = 0
for g in product((0,1), repeat=2):
    enc = tuple(m ^ g[m] for m in (0,1))
    table_counts = Counter()
    for h in product((0,1), repeat=2):
        for h0 in product((0,1), repeat=4):
            def patched(m,c):
                return h[m] if c==enc[m] else h0[2*m+c]
            table = tuple(patched(m,c) for m,c in product((0,1),repeat=2))
            table_counts[table] += 1
            # Reversible compute/use/uncompute on every basis state.
            # Equality on all basis vectors implies equality on superpositions.
            for m,c,out in product((0,1),repeat=3):
                ework = hwork = h0work = 0
                ework ^= g[m]; ework ^= m
                hwork ^= h[m]; h0work ^= h0[2*m+c]
                got = out ^ (hwork if c==ework else h0work)
                h0work ^= h0[2*m+c]; hwork ^= h[m]
                ework ^= m; ework ^= g[m]
                assert (got,ework,hwork,h0work)==(out^patched(m,c),0,0,0)
                coherent_basis_cases += 1
            # Every possible raw decoder and both fallback secrets.
            # -1 denotes failure; c=2 is malformed and always rejects.
            for dec in product((-1,0,1),repeat=2):
                for z,c in product((0,1),range(3)):
                    mp = -1 if c==2 else dec[c]
                    accepted = mp!=-1 and enc[mp]==c
                    # Malformed-domain hash values remain independent, fixed here.
                    bad_hash = z ^ 1
                    target = patched(mp,c) if accepted else (bad_hash if c==2 else patched(z,c))
                    reference = h[mp] if accepted else None
                    sim = reference if reference is not None else (bad_hash if c==2 else patched(z,c))
                    assert sim==target
                    rejection_cases += 1
                    collision_cases += int(enc[0]==enc[1])
    assert len(table_counts)==16 and set(table_counts.values())=={4}
    uniform_functions += len(table_counts)

# Order of expectation and maximum: all 2-key / 2-message grids.
worst_case_grids = 0
for cells in product((Fraction(0),Fraction(1,3),Fraction(2,3),Fraction(1)),repeat=4):
    rows = (cells[:2],cells[2:])
    delta_wc = sum(max(row) for row in rows)/2
    delta_ik = max((rows[0][m]+rows[1][m])/2 for m in (0,1))
    assert delta_ik<=delta_wc
    for alpha in (Fraction(1,2),Fraction(1),Fraction(3),Fraction(152)):
        lhs = sum(min(1,alpha*max(row)) for row in rows)/2
        assert lhs<=min(1,alpha*delta_wc)
    worst_case_grids += 1
assert Fraction(1,2)<Fraction(1)  # diagonal failure table: delta_ik=1/2, delta_wc=1.

def mean_bound(a):
    if a<=0: return 0.0
    if a>=1: return 1.0
    return a*(1-math.log(a))
assert mean_bound(0)==0 and mean_bound(1)==mean_bound(2)==1
prev = 0
for i in range(1,1001):
    v=mean_bound(i/1000)
    assert prev<=v<=1
    prev=v
rows=[]
for qlog in (0,16,32,64):
    q=2**qlog; factor=152*(q+1)**2
    bound=mean_bound(factor*2.0**-212)
    rows.append({'q_log2':qlog,'D_q':str(factor),'bound':bound,'bound_bits':-math.log2(bound)})
for row,want in zip(rows,(195.607036771968,165.836237718311,134.129114291313,70.991838693076)):
    assert abs(row['bound_bits']-want)<1e-9

def components(qg,qh,qd,source_gap_sum=Decimal(0)):
    assert min(qg,qh,qd)>=0 and source_gap_sum>=0
    with localcontext() as ctx:
        ctx.prec=100
        QG=2*(qg+qh+qd); QH=2*(qh+qd); R=QG+QH; U=R+qd
        delta=Decimal(2)**-212
        passive=4*(2*Decimal(U)*source_gap_sum).sqrt()
        guess=8*Decimal(U)*(Decimal(2)**-128)
        ffp=min(Decimal(1),Decimal(152)*(U+1)**2*delta)
        failure=(qd+1)*ffp
        spread=Decimal(24)*qd*(QG+4*qd)*(Decimal(3)/4)**640
        bound=min(Decimal('0.5'),passive+guess+failure+spread)
        return {'Q_G':QG,'Q_H':QH,'R':R,'U':U,
                'passive':passive,'message_search':guess,'failure':failure,
                'spreadness':spread,'clipped_sum':bound}

# Explicit normalization check: (4 sqrt(2 U epsilon))^2 = 32 U epsilon.
for qg,qh,qd in product(range(3),repeat=3):
    with localcontext() as ctx:
        ctx.prec=100
        eps=Decimal(2)**-200
        c=components(qg,qh,qd,eps)
        assert abs(c['passive']**2-32*c['U']*eps)<Decimal('1e-140')
        assert Decimal(0)<=c['clipped_sum']<=Decimal('0.5')
assert components(2**300,2**300,2**300)['clipped_sum']==Decimal('0.5')
diagnostics=[]
for qlog in (0,16,32,64):
    q=2**qlog
    c=components(q,q,q)
    diagnostics.append({'q_G_q_H_q_D_log2':qlog,
        **{k:str(v) if isinstance(v,Decimal) else v for k,v in c.items()},
        'meaning':'Non-source additive components only; source gaps omitted, not assumed zero in security claim.'})

results={
 'revision':'V4.2',
 'profile':{'n':N,'k':K,'P':P,'Q':4,'C':2,'pk_bytes':1313,'ct_bytes':1760,'qfo_ct_bytes':1792},
 'correctness':{'delta_ik_upper':'2^-212','delta_wc_upper':'2^-212','delta_wc_lower':'2^-8192'},
 'spreadness':{'max_cell_probability':str(max_prob),'coefficients':1280,'gamma_lower_bound_bits':gamma},
 'raw_samplers':{'word_preimages_per_coefficient':16,'cbd_byte_counts':dict(cbd_counts),'rho_pair_preimages':16},
 'graph_simulation':{'uniform_oracle_tables':uniform_functions,'coherent_basis_cases':coherent_basis_cases,
                     'rejection_cases':rejection_cases,'collision_cases':collision_cases,
                     'scope':'Exhaustive toy identities; not a full quantum security proof.'},
 'worst_case_order':{'grids_checked':worst_case_grids,'result':'E[max] is not replaced by max[E]'},
 'ffp_nk':{'rows':rows,'claim_boundary':'FFP-NK diagnostic only; not KEM security bits',
           'second_moment':'Imported from Article 4, not used in Theorem 4'},
 'qrom':{'status':'Conditional Theorem 4 in single-user key-first fresh-ideal-oracle model',
         'decapsulation':'classical queries only',
         'source_normalization':'KEM bias; PKE gap <= 2*(epsilon_Q_44+epsilon_Q_45)',
         'ffp_ng_required_for_coarse_bound':False,
         'constant_query_allowances':'Q_G=2(q_G+q_H+q_D); Q_H=2(q_H+q_D); U=Q_G+Q_H+q_D',
         'diagnostics':diagnostics,'pq128_certification':False},
 'overall':'PASS: finite identities and numerical arithmetic only'
}
OUT.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
