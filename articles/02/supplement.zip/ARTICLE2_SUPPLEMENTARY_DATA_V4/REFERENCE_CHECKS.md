# Reference checks — Article 2 V4.2

Primary full text read: Hövelmanns–Hülsing–Majenz, arXiv:2203.10182v1.
Source URL: https://arxiv.org/pdf/2203.10182
Consulted PDF SHA-256: `8ae9bc66b45d58c8ce055bae6978440211c532566b395dd03f8e8e682bb09a12`.

Checked: Section 2 advantage conventions; Lemma 5, (51), p. 34;
Corollary 8, (69)–(70), pp. 37–38, including runtime and query counts.
The latter pages were also visually checked. The search lemma's published
counterpart is Lemma 4, (30), p. 439, DOI 10.1007/978-3-031-22972-5_15.
Equation (4) in Article 2 is our conservative composition, not a quoted result.

The primary ePrint notice 2023/1811 confirms the worst-case-correctness alternative
(PQCrypto 2024). Its sharper constants are not used. The primary abstract for
2025/1997 confirms Ring/Module-LWE and centered-binomial relevance; its full theorem
has not been matched to C1-K4. PDF retrieval for those newer sources returned 403
during this work. No unperformed full-text check is claimed.
