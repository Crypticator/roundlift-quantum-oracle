# Article 2 — V4.2

Read `ARTICLE2_REVISED_V4.md` and `ARTICLE2_CLOSURE_REPORT_V4_2.md`.
This revision supplies a conservative conditional QROM bound for the unchanged
1760-byte compact wrapper. Its fresh-oracle, key-first, single-user model and
classical decapsulation interface are essential. No PQ-128 certificate is claimed.

Reproduce only this article, with Python 3 and no third-party dependencies:

```bash
python run_clean_checks.py
```

The runner uses a clean temporary source copy and a foreign working directory;
no stale generated JSON is read by the scientific script. `results.json` is an
optional reference snapshot compared against the fresh output. `FRESH_CHECKS.json`
records the actual run. The tests cover finite identities and arithmetic, not a
machine-checked security theorem or source hardness.

The dependency manuscripts are byte-identical copies of Article 1 V4.1 and
Article 4 V4. The main theorem uses Article 1, not Article 4's optional second
moment. They are included for review; no new audit of those articles was run.

`provenance/` contains the preceding Article 2 and the revision diff.
`MANIFEST.sha256` covers every other file in this supplement. Fresh reruns change
the timestamped execution report; the supplied manifest describes the delivery.
