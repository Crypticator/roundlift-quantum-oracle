#!/usr/bin/env python3
"""Run only Article 2 from a clean copy, with a foreign working directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

root=Path(__file__).resolve().parent
script=root/'article2_qrom_audit.py'
expected=json.loads((root/'results.json').read_text()) if (root/'results.json').exists() else None
with tempfile.TemporaryDirectory(prefix='article2-v4-2-clean-') as tmp:
    work=Path(tmp)/'source'; work.mkdir()
    foreign=Path(tmp)/'foreign'; foreign.mkdir()
    shutil.copy2(script,work/script.name)
    target=work/'results.json'
    target.unlink(missing_ok=True)
    started=time.time_ns()
    p=subprocess.run([sys.executable,str(work/script.name)],cwd=foreign,
                     capture_output=True,text=True)
    assert p.returncode==0,p.stdout+p.stderr
    assert target.exists() and target.stat().st_mtime_ns>=started
    result=json.loads(target.read_text())
    if expected is not None:assert result==expected,'fresh result differs from reference snapshot'
    assert not (foreign/'results.json').exists()
    shutil.copy2(target,root/'results.json')
    (root/'RUN.log').write_text(p.stdout+p.stderr)
    checks={'status':'PASS','scope':'Article 2 finite identities and arithmetic only',
            'python':sys.version,'started_ns':started,'finished_ns':time.time_ns(),
            'foreign_cwd':True,'prior_generated_json_absent':True,'output_fresh':True,
            'matches_reference_snapshot':None if expected is None else True,
            'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
            'results_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
            'machine_checked_security_proof':False,'other_articles_run':False}
    (root/'FRESH_CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))
