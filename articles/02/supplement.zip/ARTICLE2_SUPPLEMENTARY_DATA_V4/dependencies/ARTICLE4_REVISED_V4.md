# Article 4 — Find-Failing-Plaintext Analysis of C1-K4-P12-CBD1

**Revision V4 — 13 November 2026 — canonical cross-reference and bibliography synchronization**

**Samir Bouftass and ChatGPT (OpenAI)**

## Abstract

This article studies the decryption-failure obligations relevant to the compact QROM route for C1-K4-P12-CBD1: FFP-NK and FFP-NG.

For the frozen construction over
\[
R=\mathbb Z_{4096}[x]/(x^{256}+1),\qquad k=4,
\]
the exact honest decryption error is
\[
\varepsilon=(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2,
\]
with the actual dependent remainders
\[
r_0=[As+e_0]_4,\qquad r_1=[A^Tr+e_1]_2,\qquad r_2=[v^Tr+e_2]_2.
\]

Article 1, Sections 4–5 and Corollary 4, establishes
\[
\delta_{wc}<2^{-212}.
\]
The main theorem here is a same-randomness, two-independent-key moment bound. For
\[
p_m(\omega)=
\Pr_K[
\operatorname{Dec}_{sk}(\operatorname{Enc}_{pk}(m;\omega))\ne m
],
\]
we prove
\[
\mathbb E_\omega[p_m(\omega)^2]<2^{-247},
\qquad
\sigma_{\delta ik}<2^{-123.5}.
\]
The proof uses Cauchy–Schwarz to handle distinct output coefficients before factorizing the diagonal two-key case; this avoids a false independence assumption between permuted uses of the common encryption tape.

We also correct the earlier mean-only analysis. A single-threshold argument gives a valid but loose diagnostic near 101 bits for one query. Integrating the Markov/QROM tail bound instead yields
\[
a(1+\ln(1/a)),\qquad a=152(q+1)^2\delta_{ik},
\]
when \(0<a<1\). With \(\delta_{ik}\le2^{-212}\), the corresponding negative base-two logarithms are approximately
\[
195.607,\ 165.836,\ 134.129,\ 70.992
\]
for \(q=1,2^{16},2^{32},2^{64}\). These are FFP-NK-term diagnostics, not KEM security bits.

For FFP-NG, the literature status is also updated. Majenz and Sisinni, IACR ePrint 2025/1997, state an analysis for Ring/Module-LWE with a subgaussian family including centered binomials. This makes the earlier “Gaussian-only” obstruction obsolete. We have not established that their theorem applies unchanged to the exact C1-K4 compression, lifting, modulus, and failure interface, so FFP-NG remains an explicit matching obligation rather than a proved impossibility.

Structured-tape experiments remain experimental. They exhibit generic bad tapes and did not show a positive FFP-NG advantage at the tested sample sizes.

The corrected status is therefore
\[
\boxed{
\text{partial FFP analysis with unresolved reduction and composition obligations}.
}
\]

---

## 1. Frozen setting

C1-K4-P12-CBD1 uses
\[
P=4096,\quad n=256,\quad k=4,\quad Q=4,\quad C=2,
\]
with coefficientwise CBD1 secrets and errors.

The message does not affect the actual remainder \(r_2\) at fixed coins because \(C\mid P/2\). Hence the same containing failure event can be used for all messages.

For an honest ciphertext,
\[
z\equiv(P/2)\mu+\varepsilon\pmod P,
\]
where
\[
\varepsilon=(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2.
\]

Every honest failure is contained in
\[
\mathcal F=\{\max_i|\varepsilon_i|\ge P/4\}.
\]

---

## 2. FFP-NK random variable

For a fixed message \(m\) and complete valid encryption tape \(\omega\), define
\[
p_m(\omega)
=
\Pr_K[
\operatorname{Dec}_{sk}(\operatorname{Enc}_{pk}(m;\omega))\ne m
].
\]

The independent-key error rate is
\[
\delta_{ik}
=
\max_m\mathbb E_\omega[p_m(\omega)].
\]

Since Article 1 proves an averaged worst-message bound,
\[
\delta_{ik}\le\delta_{wc}<2^{-212}.
\]

The variance parameter is
\[
\sigma_{\delta ik}^2
=
\max_m
\operatorname{Var}_{\omega}[p_m(\omega)].
\]

The generic inequality \(0\le p\le1\) gives
\[
\sigma_{\delta ik}^2\le\delta_{ik}<2^{-212},
\]
hence
\[
\sigma_{\delta ik}<2^{-106}.
\]

The next section improves this bound.

---

## 3. Two-independent-key second-moment theorem

Take two independently generated key pairs \(K^{(1)},K^{(2)}\), but use the same encryption tape \(\omega\). For fixed \(m\),
\[
\mathbb E_\omega[p_m(\omega)^2]
=
\Pr_{\omega,K^{(1)},K^{(2)}}[F_1\wedge F_2].
\]

A direct factorization across two arbitrary output coefficients would be unjustified because distinct negacyclic coefficients reuse the same tape under different permutations. We therefore insert a Cauchy–Schwarz step.

For an output index \(i\) and sign \(\alpha\in\{\pm1\}\), define
\[
g_{i,\alpha}(\omega)
=
\mathbb E_K
u^{\alpha\varepsilon_i(K,\omega)}.
\]
For arbitrary \(i,j,\alpha,\beta\),
\[
\mathbb E_\omega
g_{i,\alpha}(\omega)g_{j,\beta}(\omega)
\le
\sqrt{
\mathbb E_\omega g_{i,\alpha}(\omega)^2\,
\mathbb E_\omega g_{j,\beta}(\omega)^2
}.
\]
Thus it suffices to bound the diagonal case: the same output coefficient and same sign, evaluated under two independent keys but the same encryption tape.

In that diagonal case, the paired tape coordinates coincide, and the conditional order can be chosen so that all factorizations are legitimate.

### 3.1 Final-coordinate factor

The remainder \(r_2\) depends on \(e_2\), so it is **not** fixed before averaging \(e_2\). Instead use a pointwise maximum inside that expectation. For two keys and signs \(\alpha,\alpha'\), define
\[
C_2(u)
=
\max_{\alpha,\alpha'}
\mathbb E_{E_2}
\max_{t,t'\in\{0,1\}}
u^{\alpha(E_2-t)+\alpha'(E_2-t')}.
\]

### 3.2 Ciphertext-error factor

Condition on both keys, the shared \(r,\rho\), and the corresponding hidden offsets. The coefficients of \(e_1\) are independent. For independent key-secret coefficients \(S,S'\sim\mathrm{CBD1}\),
\[
B_2(u)
=
\max_{\alpha,\alpha'}
\mathbb E_{S,S'}
\max_{c,c'\in\{0,1\}}
\mathbb E_{E_1}
u^{
\alpha S([c+E_1]_2-E_1)
+
\alpha'S'([c'+E_1]_2-E_1)
}.
\]
After this maximum, the resulting factor no longer depends on the shared ephemeral tape.

### 3.3 Key-generation/lifting factor

Condition on both keys so that the two \(r_0\) values are fixed, then average the independent shared tape pairs
\[
(R,T)=(r_j,\rho_j).
\]
For two independent key-generation errors \(E,E'\sim\mathrm{CBD1}\),
\[
A_2(u)
=
\max_{\alpha,\alpha'}
\mathbb E_{E,E'}
\max_{t,t'\in\{0,1,2,3\}}
\mathbb E_{R,T}
u^{R(\alpha(E+T-t)+\alpha'(E'+T-t'))}.
\]

After these maxima remove the hidden remainders in the correct order, the key coordinates are iid and the diagonal two-key moment factorizes:
\[
\mathbb E_\omega g_{i,\alpha}(\omega)^2
\le
(A_2(u)B_2(u))^{kn}C_2(u).
\]
By Cauchy–Schwarz, the same upper bound applies to arbitrary pairs \(i,j,\alpha,\beta\).

A union bound over \(n^2\) output-index pairs and four sign pairs, followed by exponential Markov at total threshold \(P/2=2048\), gives
\[
\boxed{
\mathbb E[p_m(\omega)^2]
\le
4n^2u^{-P/2}
(A_2(u)B_2(u))^{kn}C_2(u)
}.
\]

At
\[
u=\frac65,
\]
exact finite enumeration gives
\[
A_2=
\frac{99036386572201}{83980800000000},
\qquad
B_2=
\frac{489677}{480000},
\qquad
C_2=
\frac{3721}{2500}.
\]

With \(n=256\), \(kn=1024\), and \(P/2=2048\),
\[
4\cdot256^2
(A_2B_2)^{1024}
C_2
\left(\frac65\right)^{-2048}
<2^{-247}.
\]

Therefore
\[
\boxed{
\mathbb E_\omega[p_m(\omega)^2]<2^{-247}
}
\]
and, since variance is at most the second moment,
\[
\boxed{
\sigma_{\delta ik}<2^{-123.5}.
}
\]

The exact logarithmic value of the displayed second-moment upper bound is approximately
\[
-247.024841645.
\]

---

## 4. Variance-route diagnostic

The FFP-NK variance theorem used in the previous analysis contains a leading term of order
\[
\sqrt{Cq_G\sigma_{\delta ik}},
\qquad C=304.
\]

Using only the simplified leading term
\[
3\sqrt{304\,q_G\,2^{-123.5}},
\]
the corresponding negative base-two logarithms are approximately:

| \(q_G\) | bound bits |
|---:|---:|
| \(1\) | 56.0 |
| \(2^{16}\) | 48.0 |
| \(2^{32}\) | 40.0 |
| \(2^{64}\) | 24.0 |

These values describe only that simplified leading term. They are not a complete QROM advantage bound and not a security level.

---

## 5. Mean-only bounds: single threshold and integrated tail

For fixed \(m\), Markov gives
\[
\Pr_\omega[p_m(\omega)\ge t]
\le
\frac{\delta_{ik}}{t}.
\]

A single-threshold optimization combined with the QROM large-value search theorem gives the earlier simple diagnostic
\[
\operatorname{Adv}^{FFP-NK}
\lesssim
2q_G\sqrt{304\,\delta_{ik}},
\]
with approximate negative base-two logarithms:

| \(q_G\) | single-threshold diagnostic |
|---:|---:|
| \(1\) | 100.9 |
| \(2^{16}\) | 84.9 |
| \(2^{32}\) | 68.9 |
| \(2^{64}\) | 36.9 |

This bound is valid but not optimal among consequences of the first moment.

A stronger consequence follows by applying Hövelmanns–Hülsing–Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform*, published version, Lemma 4, equation (30), p. 439, at every threshold to the **same adversary**. Here \(q\) counts the adversary's eCO.RO queries before the final oracle evaluation; the additional final evaluation is accounted for by \(q+1\). The lemma is used in its extractable-oracle model. One fixed adversary is used for every threshold, with uniform input bits mapped to the honest CBD1 and lifting distributions. Identifying this \(q\) with a complete KEM reduction's query budget remains a separate composition obligation.

Thus
\[
\Pr[F_{\rm out}\ge t]
\le
\min\!\left(
1,
\frac{152(q+1)^2\delta_{ik}}{t}
\right).
\]
Set
\[
a=152(q+1)^2\delta_{ik}.
\]
Integrating the tail of the same random variable gives
\[
\mathbb E[F_{\rm out}]
\le
\int_0^1\min(1,a/t)\,dt
=
\begin{cases}
a(1+\ln(1/a)),&0<a<1,\\
1,&a\ge1,\\
0,&a=0.
\end{cases}
\]

At \(\delta_{ik}=2^{-212}\), this yields:

| \(q\) | \(-\log_2\) integrated mean-only bound |
|---:|---:|
| \(1\) | 195.607 |
| \(2^{16}\) | 165.836 |
| \(2^{32}\) | 134.129 |
| \(2^{64}\) | 70.992 |

These numbers concern an FFP-NK term in the stated search model. They do not include FFP-NG, passive-security losses, KDF/oracle transformations, decapsulation-query accounting, or other KEM-composition terms. Therefore they cannot be quoted as post-quantum security bits of C1-K4.

The earlier sentence that the first moment could yield “at best” about 101 bits is withdrawn.

---

## 6. Generic bad tapes: experimental evidence only

Experiments found highly structured tapes for which decryption failures can become common over fresh keys. A representative family uses several all-one module components together with highly structured lift values.

The interpretation must distinguish two experimental objects:

1. a **complete fixed tape**, where every ephemeral coefficient and lift coefficient is frozen before testing keys;
2. a **family of tapes**, where a procedure resamples some coordinates between trials.

Only the first directly estimates the fixed-\(\omega\) quantity \(p_m(\omega)\).

The V4 supplementary package retains the two experimental series **separately**:

1. `original_experiments/ffp_structured_tape_experiment.py` and `original_experiments/FFP_EXPERIMENT_RESULTS.json`, reproducing the earlier family-of-tapes experiment with seed `20261113`;
2. `independent_controls/ffp_independent_fixed_tape_controls.py` and `independent_controls/INDEPENDENT_FIXED_TAPE_RESULTS.json`, using integer negacyclic convolution, zero message, explicit fixed/fresh lift modes, seed `2026111302`, and 128 trials per row.

The implementations and tape conventions differ and are not merged into one statistical sample. The first series resamples some tape coordinates and therefore probes a family; the second explicitly distinguishes fixed-zero-lift tapes from fresh-uniform-lift controls.

The experiments show that generic bad tapes exist in the tested families. They do not quantify their exact probability under honest random-oracle output and are not used as a security proof.

---

## 7. FFP-NG: corrected state of the art

FFP-NG asks whether an adversary seeing \(pk_0\) can choose a valid message/randomness pair whose failure behavior differs between the matching key pair and an independent key pair.

The earlier version of this article emphasized a PVW/discrete-Gaussian reduction and stated too broadly that the known proof technology was Gaussian-specific. That statement is outdated.

Christian Majenz and Fabrizio Sisinni, *Provable decryption failure security for practical lattice-based PKE*, IACR ePrint 2025/1997, state that they generalize FFP-NG analysis to widely used Ring-LWE and Module-LWE schemes and consider a family of subgaussian distributions including centered binomials.

This is relevant to C1-K4, but applicability is not automatic. The present work has not verified that the theorem's exact hypotheses match:

- C1-K4's coefficientwise CBD1 source laws;
- the exact module and modulus;
- its compression and lifting maps;
- the dependent remainders entering the failure predicate;
- the compact wrapper's FFP interface.

Accordingly,
\[
\boxed{
\text{FFP-NG for the exact C1-K4 interface remains open in this article.}
}
\]

CBD1 has the exact splitting identity
\[
\mathrm{CBD1}
\overset d=
B_+ + B_-,
\]
where
\[
B_+\leftarrow\{0,1\},
\qquad
B_-\leftarrow\{-1,0\}
\]
are independent and uniform. This notation is used consistently throughout this revision. The splitting identity is a distributional fact, not a new FFP-NG reduction.

---

## 8. FFP-NG attack search

The supplementary experiments tested simple public-key-dependent tape-generation rules based on coefficient thresholds, parity, midpoint signs, local differences, and sparse selections.

No positive FFP-NG advantage was observed in the reported 128-trial experiments. With that sample size, this statement is only experimental evidence; it does not “rule out” the strategy family in a cryptographic sense.

The independent hostile audit also evaluated explicitly fixed tapes and integer-convolution controls. In V4 those controls remain delivered under `independent_controls/` with their script, seed, protocol, and JSON output. They remain separate from the original experiments under `original_experiments/` because the tape conventions and implementations differ.

The correct conclusion is:

\[
\boxed{
\text{no tested elementary strategy produced an observed FFP-NG advantage at the stated sample size.}
}
\]

---

## 9. Final classification

### PROVED

1. The exact C1-K4 failure geometry is retained.
2. \(\delta_{ik}<2^{-212}\).
3. The Cauchy–Schwarz-repaired two-key proof gives
   \[
   \mathbb E[p_m(\omega)^2]<2^{-247}.
   \]
4. Consequently,
   \[
   \sigma_{\delta ik}<2^{-123.5}.
   \]
5. The integrated mean-only FFP-NK bound
   \[
   a(1+\ln(1/a))
   \]
   follows in the stated search-lemma model for \(0<a<1\).

### EXPERIMENTALLY OBSERVED

1. Structured generic bad tapes exist in the tested families.
2. No tested elementary public-key-dependent strategy produced an observed FFP-NG advantage at the stated sample size.

### OPEN

1. Exact applicability of the newer Ring/Module-LWE FFP-NG theorem to C1-K4.
2. A complete FFP-NG reduction specialized to the exact compact interface, if the published theorem does not directly instantiate.
3. A practical FFP-NG attack.
4. End-to-end composition of passive security, FFP-NG, FFP-NK, correctness, and all QROM transformation losses.
5. A concrete PQ-128 QROM certificate for the compact 1760-byte KEM.

---

## 10. Verdict

\[
\boxed{
\textbf{ARTICLE 4 — CONDITIONAL PASS / PARTIAL FFP ANALYSIS}
}
\]

The exact second-moment result survives the hostile audit after a necessary Cauchy–Schwarz repair. The earlier mean-only conclusion was too pessimistic and has been corrected by integrating the QROM tail bound. The earlier Gaussian-only literature statement has also been withdrawn.

No general impossibility theorem for FFP-NG or FFP-NK is proved. The remaining result is a partial analysis with explicit open theorem-matching and composition obligations.

## References

- Samir Bouftass and ChatGPT (OpenAI), *C1-K4-P12-CBD1: Exact Correctness, Conditional Security, and Reproducible Attack Estimates*, Article 1, consolidated V4, 13 November 2026. Sections 3–5 define the exact laws, error identity, and averaged worst-message bound. Companion manuscript included in this package.
- Kathrin Hövelmanns, Andreas Hülsing, and Christian Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform*, ASIACRYPT 2022, LNCS 13794, pp. 414–443. https://doi.org/10.1007/978-3-031-22972-5_15. This article uses the published-version Lemma 4, equation (30), p. 439; preprint numbering differs.
- Christian Majenz and Fabrizio Sisinni, *Provable decryption failure security for practical lattice-based PKE*, Cryptology ePrint Archive 2025/1997, 2025. https://eprint.iacr.org/2025/1997. Only the public notice and abstract are used for the literature update; this article does not claim that the full theorem hypotheses have been matched to C1-K4.
