# Reproducibility guide — Article 1 / consolidated v4

## 1. Pure Python chain
```bash
python -m pip install -r requirements.txt
python scripts/run_pure_python_checks.py
```
The chain regenerates current outputs before `validate_expected.py`. The integration rerun ends with `EXPECTED-VALUE VALIDATION: PASS` and `PURE-PYTHON CHECKS: PASS`.

## 2. Expanded MATZOV diagnostic
`audit_imports/extra_attack_checks.json` records the hostile-audit deterministic coordinate search. For `m=1024`, its lowest found point is `213.656698255976` bits at beta=731, p=3, k_enum=6, k_fft=114. This is a minimum found in a tested domain, not a global optimum theorem.

A standalone `scripts/k4_matzov_expanded_search.py` is included to document the same search strategy. It is deliberately separate from the legacy full modulus scan so the baseline reproduction remains fast and comparable to the archived results.

## 3. Coded-dual
Bootstrap the pinned public repository and run the Sage adapter. The rotation-aware adapter applies: (i) CBD1 `compute_p0(1)=1/2`; and (ii) an in-memory lower-bracket repair because the upstream lower bracket already exceeds the target success probability for CBD1 at the archived point.

The hostile audit independently verified `eta(137828)<0.6<=eta(137829)` and reproduced `206.210581344...` bits under Sage 10.10. Those outputs are copied under `audit_imports/`; this integration pass does not claim a new Sage execution.

## 4. Interpretation
Correctness certificates are mathematical bounds. Lattice/coded-dual costs are model-dependent estimates of specified attacks, not lower bounds on all adversaries.

## V4 rerun provenance
The delivery-level validation report records newly regenerated pure-Python outputs and the standalone expanded search. The previously executed Sage bracket/cost result is preserved without claiming a new V4 Sage execution. Code is unchanged from V3.

## Article 1 closure revision V4.1
The manuscript has undergone targeted critical review. Its classical-ROM bound now explicitly retains advantage-normalization and nonzero-correctness allowances. See `ARTICLE1_CLOSURE_REPORT_V4_1.md`; that report supersedes earlier pending-manuscript status statements. The pre-existing nine scientific scripts are unchanged. New finite closure checks appear under `closure/`. The reviewer also contributed to consolidation; this is not an external independent audit.
