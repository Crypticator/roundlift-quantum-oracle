# Reconstruction notes

## Recovered from the research archive
- `thesis2_go2_c1_attack_estimates.py`: independent lightweight port of baseline Lattice Estimator formulas.
- `k4_correctness_and_sizes.py`: exact finite-moment K4 correctness certificate, failure witness, sizes.
- GO5 and GO6 audit reports.
- legacy GO6 machine-readable results.
- A6 v1.1 TeX, retained only as provenance for the rank-symbolic dependent-remainder proof.

## Reconstructed before V4 and retained unchanged
- `k4_attack_baselines_and_projections.py`: rank-4 baseline and complete modulus projection driver.
- `k4_reduction_budget.py`: rank-4 exact NTT self-test and explicit operation accounting (63,200 counted operations, capped at 2^16).
- `k4_structure_checks.py`: rank-4 CBD1 Hamming tails and cyclic zero-run checks.
- `k4_coded_dual_reproduce.sage.py`: adapter for the pinned public CRYPTO 2026 CodedDualAttack implementation. It applies two in-memory changes required by the audited CBD1 reproduction: `compute_p0(1)=1/2` and, in the rotation-aware model, `R_min=1`. The V2 second-pass audit separately reproduced `eta(137828)<0.6<=eta(137829)` and `log2(T)=206.21058134400172` under Sage 10.10 at the reported point.
- validation and manifest machinery.

## Execution chronology
The initial reconstruction phase did not execute SageMath. A later independent second-pass audit did execute the corrected adapter under Sage 10.10 and reproduced `log2(T)=206.21058134400172` after verifying the lower-bracket condition. Both phases are retained explicitly; the later execution does not rewrite the historical reconstruction record.

## V4 consolidation
V4 supplies `ARTICLE1_CANONICAL_V4.md` and synchronizes the active documentation. The scientific scripts are byte-identical to V3. It freshly runs the pure-Python pipeline and expanded MATZOV search; it preserves, but does not rerun, the earlier independent Sage execution.
