# Supplementary Data — Article 1 (consolidated v4)

## C1-K4-P12-CBD1

This archive integrates the hostile re-audit corrections of 13 November 2026.

### Frozen profile
- Ring: `Z_4096[x]/(x^256+1)`
- Degree: 256
- Module rank: 4
- Public quotient divisor: 4
- Ciphertext divisor: 2
- Secret/error law: CBD1
- Coefficient secret dimension: 1024
- Public key: 1313 bytes
- Ciphertext: 1760 bytes

### Correctness
- `2^-8192 <= delta_K4 < 2^-212`.
- Displayed upper-bound exponent about `-212.52644748`.

### Attack estimates
These are heuristic/model-dependent attack-cost estimates, not security lower bounds.
- primal uSVP classical: about `227.18` bits.
- plain dual classical: about `235.06` bits.
- legacy MATZOV baseline search: about `220.538` bits.
- hostile-audit expanded MATZOV tested-domain diagnostic: about `213.656698` bits at beta=731, p=3, k_enum=6, k_fft=114.
- corrected rotation-aware coded-dual model: `206.210581344...` bits at `(m,nenu,nfft,kfft)=(770,17,135,14)`, after both the CBD1 `p0` adaptation and the documented lower-bracket correction.

The coded-dual estimate remains the lowest reported model-dependent attack cost in this dossier.

### Reproducibility corrections
- `k4_correctness_and_sizes.py` now writes the freshly computed JSON.
- `run_pure_python_checks.py` regenerates outputs before validation; the corrected chain passes.
- `k4_matzov_expanded_search.py` records the broader deterministic search method used to probe the 213.656... basin.
- `k4_coded_dual_reproduce.sage.py` resolves its own path before `chdir` and documents/applies the lower-bracket correction in memory.
- The independent Sage bracket result and expanded diagnostics are included under `audit_imports/`.

### Claim boundary
No attack cost proves a minimum security level. Reduction-adjusted quantities are conditional diagnostics only.

## Canonical manuscript
`ARTICLE1_CANONICAL_V4.md` is the newly consolidated rank-four manuscript. Its Sections 3–6 provide the algorithms, dependent-remainder correctness proof, failure witness, and joint CPA simulations. The companion status sheet explicitly distinguishes consolidation from independent approval of the new text.

Historical rank-three source text, GO reports, imported audit results, and legacy numerical baselines are retained as provenance. They are not the current manuscript and do not override its corrected claims. In particular, a legacy 220.538-bit MATZOV result is not the preferred estimate, and an archived 184-bit diagnostic is not a security certificate.

## Article 1 closure revision V4.1
The manuscript has undergone targeted critical review. Its classical-ROM bound now explicitly retains advantage-normalization and nonzero-correctness allowances. See `ARTICLE1_CLOSURE_REPORT_V4_1.md`; that report supersedes earlier pending-manuscript status statements. The pre-existing nine scientific scripts are unchanged. New finite closure checks appear under `closure/`. The reviewer also contributed to consolidation; this is not an external independent audit.
