#!/usr/bin/env python3
"""
Thesis II / Article 1 / GO 5
C1-K4 viability audit.

Profile:
  R = Z_4096[x]/(x^256+1)
  k = 4
  Q = 4
  C = 2
  CBD1 secrets/errors

This script certifies the rank-4 correctness bound using the exact finite
moments from the A6 proof, checks an explicit non-perfect-correctness witness,
computes serialization sizes, and imports the GO2 attack-estimator port for
a preliminary coefficient-LWE baseline.

The attack estimates are heuristic upper bounds on known attacks, not
hardness lower bounds.
"""
from fractions import Fraction
import math, json, runpy
from pathlib import Path

N = 256
K = 4
P = 4096
Q = 4
C = 2
CBD = {-1: Fraction(1,4), 0: Fraction(1,2), 1: Fraction(1,4)}

def moment_functions(u):
    a = Fraction(0)
    for E,pE in CBD.items():
        for R,pR in CBD.items():
            for T in range(Q):
                a += pE*pR*Fraction(1,Q)*(u**((abs(E)+T)*R))

    b = Fraction(0)
    for S,pS in CBD.items():
        vals = []
        for cc in range(C):
            v = Fraction(0)
            for E,pE in CBD.items():
                rem = (cc + E) % C
                v += pE*(u**(S*(rem-E)))
            vals.append(v)
        b += pS*max(vals)

    c = sum((p*(u**E) for E,p in CBD.items()), Fraction(0))
    return a,b,c

def correctness_bound(u=Fraction(4,3)):
    a,b,c = moment_functions(u)
    bound = Fraction(N) * (1 + u**(C-1)) * (a*b)**(K*N) * c * u**(-P//4)
    log2bound = math.log2(bound.numerator) - math.log2(bound.denominator)
    cert_212 = (2**212)*bound.numerator < bound.denominator
    return a,b,c,bound,log2bound,cert_212

def negacyclic(a,b):
    out=[0]*N
    for i,x in enumerate(a):
        if not x:
            continue
        for j,y in enumerate(b):
            if not y:
                continue
            d=i+j
            if d < N:
                out[d]+=x*y
            else:
                out[d-N]-=x*y
    return out

def witness():
    # s = 0, e0 = -1, rho=e1=e2=0.
    # r has three all-one module components and one all-zero component.
    coeff = [-4]*N  # e0 + rho - r0 = -1 + 0 - 3
    one=[1]*N
    zero=[0]*N
    eps=[0]*N
    for rr in (one,one,one,zero):
        p=negacyclic(coeff,rr)
        eps=[x+y for x,y in zip(eps,p)]
    # v = 4092 coefficientwise, so v^T r is even and r2=0.
    fail = (P//4) < (eps[0] % P) < (3*P//4)
    return eps[0], eps[0] % P, fail

def sizes():
    pk = 1 + 32 + (K*N*10)//8
    ct = ((K+1)*N*11)//8
    full_A = (K*K*N*12)//8
    b = (K*N*10)//8
    cbd_bytes = (2*K+1)*N
    rho_bytes = (K*N)//2
    tape = cbd_bytes + rho_bytes
    return {
        "public_key_bytes":pk,
        "ciphertext_bytes":ct,
        "full_matrix_bytes":full_A,
        "public_b_bytes":b,
        "unseeded_pk_before_metadata_bytes":full_A+b,
        "random_tape_bytes":tape,
        "random_tape_cbd_bytes":cbd_bytes,
        "random_tape_rho_bytes":rho_bytes,
    }

a,b,c,bound,log2bound,cert = correctness_bound()
eps0,eps0mod,fail = witness()

result = {
  "profile":{
    "n":N,"k":K,"P":P,"Q":Q,"C":C,
    "ring":"Z_4096[x]/(x^256+1)",
    "distribution":"CBD1"
  },
  "correctness":{
    "u":"4/3",
    "a":f"{a.numerator}/{a.denominator}",
    "b":f"{b.numerator}/{b.denominator}",
    "c":f"{c.numerator}/{c.denominator}",
    "log2_upper_bound":log2bound,
    "certified_lt_2^-212":cert,
    "explicit_failure_witness_epsilon0":eps0,
    "explicit_failure_witness_mod_P":eps0mod,
    "witness_causes_decode_failure":fail,
    "witness_probability_log2":-8192,
    "interval":"2^-8192 <= delta_K4 < 2^-212"
  },
  "sizes":sizes(),
  "sources":{
    "public_key_source":"DMLWE_(4,4)^CBD1",
    "ciphertext_source":"DMLWE_(4,5)^CBD1",
    "coefficient_secret_dimension":K*N,
    "source_equations_j4":4*N,
    "source_equations_j5":5*N
  }
}

# Optional preliminary attack baseline, using the GO2 reproducible port if present.
go2 = Path(__file__).with_name("thesis2_go2_c1_attack_estimates.py")
if go2.exists():
    mod = runpy.run_path(str(go2))
    std = math.sqrt(0.5)
    params = dict(n=K*N,q=P,xs=std,xe=std)
    result["preliminary_attacks"] = {
      "primal_usvp_classical":mod["primal_usvp"](**params,sample_count=4*N,cexp=.292),
      "primal_usvp_quantum_core_svp":mod["primal_usvp"](**params,sample_count=4*N,cexp=.265),
      "plain_dual_classical":mod["plain_dual"](K*N,P,std,4*N,.292),
      "matzov_dual_hybrid_classical":mod["matzov_opt"](**params,available_samples=4*N,cexp=.292),
      "matzov_dual_hybrid_quantum_reduction_stress":mod["matzov_opt"](**params,available_samples=4*N,cexp=.265)
    }

if __name__ == "__main__":
    out = Path(__file__).resolve().parent.parent / "results" / "k4_correctness_and_sizes.json"
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result,indent=2))
