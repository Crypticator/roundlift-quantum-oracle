#!/usr/bin/env python3
"""Reproduce the pure-Python K4 attack baselines and modulus projections.

This imports the independently ported Lattice Estimator formulas in
thesis2_go2_c1_attack_estimates.py and evaluates the rank-4 coefficient
embedding used in Article 1.

Outputs are attack-cost estimates under the stated models, not hardness
lower bounds and not a security certificate.
"""
import json, math, runpy
from pathlib import Path

HERE = Path(__file__).resolve().parent
base = runpy.run_path(str(HERE / "thesis2_go2_c1_attack_estimates.py"))
std = math.sqrt(0.5)
N = 1024
M = 1024
Q = 4096
params = dict(n=N, q=Q, xs=std, xe=std)

res = {
    "profile": {
        "n_coeff": N,
        "available_samples": M,
        "q": Q,
        "secret_error": "CBD1",
        "stddev": std,
    },
    "baseline": {
        "primal_usvp_classical": base["primal_usvp"](**params, sample_count=M, cexp=.292),
        "primal_usvp_quantum_reduction_stress": base["primal_usvp"](**params, sample_count=M, cexp=.265),
        "plain_dual_classical": base["plain_dual"](N, Q, std, M, .292),
        "matzov_dual_hybrid_classical": base["matzov_opt"](**params, available_samples=M, cexp=.292),
        "matzov_dual_hybrid_quantum_reduction_stress": base["matzov_opt"](**params, available_samples=M, cexp=.265),
    },
    "modulus_projection_scan": [],
}

for q in [4,8,16,32,64,128,256,512,1024,2048,4096]:
    p = base["primal_usvp"](n=N,q=q,xs=std,xe=std,sample_count=M,cexp=.292)
    d = base["plain_dual"](N,q,std,M,.292)
    h = base["matzov_opt"](n=N,q=q,xs=std,xe=std,available_samples=M,cexp=.292)
    res["modulus_projection_scan"].append({
        "q": q,
        "primal_bits": None if p is None else p["log2_cost"],
        "dual_bits": d["log2_cost"],
        "matzov_bits": h["log2_cost"],
    })

out = HERE.parent / "results" / "k4_attack_baselines_and_projections.json"
out.write_text(json.dumps(res, indent=2), encoding="utf-8")
print(json.dumps(res, indent=2))
