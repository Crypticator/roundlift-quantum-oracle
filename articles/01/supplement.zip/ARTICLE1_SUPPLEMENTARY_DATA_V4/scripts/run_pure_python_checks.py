#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
scripts=[
    "k4_correctness_and_sizes.py",
    "k4_attack_baselines_and_projections.py",
    "k4_structure_checks.py",
    "k4_reduction_budget.py",
    "validate_expected.py",
]
for s in scripts:
    print(f"\n=== {s} ===")
    subprocess.run([sys.executable,str(HERE/s)],check=True)
print("\nPURE-PYTHON CHECKS: PASS")
