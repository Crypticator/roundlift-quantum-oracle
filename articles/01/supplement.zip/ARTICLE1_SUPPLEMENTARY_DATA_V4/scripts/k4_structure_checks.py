#!/usr/bin/env python3
"""Distribution-only structural checks for K4 (no Sage required)."""
import json, math
from pathlib import Path
import numpy as np
from scipy.stats import binom

N=1024

def cyclic_zero_run_probability(poly_degree,zeta):
    T=np.zeros((zeta,zeta),dtype=object)
    for j in range(zeta):
        T[j,0]+=1
        if j+1<zeta: T[j,j+1]+=1
    M=np.linalg.matrix_power(T,poly_degree)
    allowed=sum(M[i,i] for i in range(zeta))
    return 1-allowed/(2**poly_degree)

res={
  "global_hamming":{
    "dimension":N,
    "mean":N/2,
    "stddev":math.sqrt(N/4),
    "tails_log2":{str(h): float(binom.logcdf(h,N,.5)/math.log(2)) for h in [64,128,192,256,320]},
  },
  "one_polynomial_cyclic_zero_run_probability":{str(z):float(cyclic_zero_run_probability(256,z)) for z in [8,12,16,20,24]},
  "mod2_error_parity":"uniform because CBD1 has P(E odd)=1/2",
}
out=Path(__file__).resolve().parent.parent/"results"/"k4_structure_checks.json"
out.write_text(json.dumps(res,indent=2),encoding="utf-8")
print(json.dumps(res,indent=2))
