#!/usr/bin/env python3
"""Reproduce the reported K4 coded-dual point using the pinned public Sage code.

Run with Sage's Python after cloning the upstream repository at the pinned
commit listed in third_party/upstream_lock.json, for example:

  sage -python scripts/k4_coded_dual_reproduce.sage.py \
      --upstream ../CodedDualAttack --mode both

No third-party source is redistributed in this supplementary package.
This adapter applies two in-memory adaptations to the pinned public code:
it admits CBD1 by setting compute_p0(1)=1/2 and, in the rotation-aware
model, replaces the lower search bracket by R_min=1. At the reported point
the original lower bracket already exceeds the target success probability.
Both adaptations are required to reproduce the reported 206.210581344...
estimate. The upstream files are not modified.
"""
import argparse, json, os, sys, types
from pathlib import Path

PARSER=argparse.ArgumentParser()
PARSER.add_argument("--upstream",required=True,help="Path to pinned CodedDualAttack checkout")
PARSER.add_argument("--mode",choices=["rot","plain","both"],default="both")
PARSER.add_argument("--local-search",action="store_true",help="Check a small integer neighborhood around the archived point")
args=PARSER.parse_args()
SCRIPT_PATH=Path(__file__).resolve()

root=Path(args.upstream).resolve()
opt=root/"OptimizeCodedDualAttack"
if not opt.exists(): raise SystemExit(f"missing {opt}")
os.chdir(opt)  # interface_polar.py expects ./polar.o
sys.path.insert(0,str(opt))

from sage.all import RR

def patch_cbd1(mod):
    original=mod.compute_p0
    def compute_p0(alpha):
        if int(alpha)==1: return RR(0.5)
        return original(alpha)
    mod.compute_p0=compute_p0
    return mod

def evaluate(mod,point):
    m,nenu,nfft,kfft=point
    n=1024; nlat=n-nenu-nfft
    red=mod.get_reduction_cost_model("C0")
    return mod.complexity(
        1,4096,m,nenu,nlat,nfft,kfft,red,RR(0.05),RR(0.6),
        option_dlsc={"experimental_Clsc":False,"ratio_GV":RR(1.0)},
        ret_dict=True,
    )

def clean(d):
    keys=["m","nlat","nenu","nfft","kfft","beta0","beta1","R","eta","epsilon"]
    out={k:(float(d[k]) if k in d and k not in ("m","nlat","nenu","nfft","kfft","beta0","beta1") else int(d[k])) for k in keys if k in d}
    out["log2_complexity"]=float(d["complexity"].log(2))
    return out

def local_search(mod,start):
    best=(float("inf"),start,None)
    m0,e0,f0,k0=start
    for m in range(m0-2,m0+3):
      for e in range(e0-3,e0+4):
       for f in range(f0-2,f0+3):
        for k in range(k0-2,k0+3):
         if min(m,e,f,k)<=0 or k>=f or e+f>=1024: continue
         try:
            d=evaluate(mod,(m,e,f,k)); cost=float(d["complexity"].log(2))
         except Exception:
            continue
         if cost<best[0]: best=(cost,(m,e,f,k),d)
    return {"point":list(best[1]),"result":clean(best[2]) if best[2] else None}

reported=(770,17,135,14)
output={"reported_point":list(reported),"warning":"attack model estimate, not a hardness lower bound"}
if args.mode in ("plain","both"):
    import utilitaries as plain
    patch_cbd1(plain)
    output["plain_at_reported_point"]=clean(evaluate(plain,reported))
    if args.local_search: output["plain_local_search"]=local_search(plain,reported)
if args.mode in ("rot","both"):
    src_path=opt/"rot_utilitaries.py"
    src=src_path.read_text(encoding="utf-8")
    old_bracket="R_min = max(RR(1), RR(2 * (p0**(-nenu))))"
    new_bracket="R_min = RR(1)"
    if src.count(old_bracket)!=1:
        raise SystemExit("unexpected upstream rot_utilitaries.py bracket")
    patched=src.replace(old_bracket,new_bracket)
    rot=types.ModuleType("k4_rot_utilitaries_patched")
    rot.__file__=str(src_path)
    exec(compile(patched, str(src_path)+" [CBD1 bracket patch]", "exec"), rot.__dict__)
    patch_cbd1(rot)
    output["rot_model_patch"]={
        "old":old_bracket,
        "new":new_bracket,
        "reason":"For CBD1 at the archived point, the upstream lower bracket already exceeds the target success probability; the independent audit verified eta(137828)<0.6<=eta(137829)."
    }
    output["rot_at_reported_point"]=clean(evaluate(rot,reported))
    if args.local_search: output["rot_local_search"]=local_search(rot,reported)

print(json.dumps(output,indent=2))
out=SCRIPT_PATH.parent.parent/"results"/"k4_coded_dual_reproduced.json"
out.write_text(json.dumps(output,indent=2),encoding="utf-8")
