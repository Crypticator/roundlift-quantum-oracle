#!/usr/bin/env python3
"""Expanded MATZOV diagnostic for C1-K4.

This is a deterministic local/coordinate search in the same heuristic cost model
used by thesis2_go2_c1_attack_estimates.py. It is not a global optimum proof and
not a security lower bound.
"""
from pathlib import Path
import json, math, runpy
ROOT=Path(__file__).resolve().parent.parent
base=runpy.run_path(str(ROOT/'scripts/thesis2_go2_c1_attack_estimates.py'))
cost=base['matzov_cost']; std=math.sqrt(.5)
rows=[]
for m in (1024,1280):
    best=None
    for beta in range(700,901):
        r=cost(1024,4096,std,std,m,beta,3,11,113,.292)
        if r and (best is None or r['log2_cost']<best['log2_cost']): best=r
    for _ in range(4):
        seed=dict(best)
        for name,lo,hi in [
            ('beta',max(40,seed['beta']-40),min(m,seed['beta']+40)),
            ('k_enum',max(0,seed['k_enum']-20),seed['k_enum']+20),
            ('k_fft',max(0,seed['k_fft']-25),seed['k_fft']+25),
            ('p',2,10)]:
            fixed=dict(best)
            for x in range(lo,hi+1):
                t=dict(fixed); t[name]=x
                r=cost(1024,4096,std,std,m,t['beta'],t['p'],t['k_enum'],t['k_fft'],.292)
                if r and r['log2_cost']<best['log2_cost']: best=r
    rows.append({'m':m,'result':best})
out={'classification':'ESTIMATED; deterministic tested-domain search, not global optimization',
     'domain':{'m':[1024,1280],'initial_beta':[700,900],'p':[2,10],'coordinate_rounds':4},
     'results':rows}
path=ROOT/'results'/'k4_matzov_expanded_search.json'
path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
