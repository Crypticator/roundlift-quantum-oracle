#!/usr/bin/env python3
"""
GO 2 reproducibility script for Thesis II / Article 1 / C1-P12-CBD1.

Purpose
-------
Reproduce coefficient-embedding baseline estimates for the two exact C1
Module-LWE source interfaces, using direct Python ports of formulas from
the public Lattice Estimator at commit:

    7d59f866655362ea8eab803dbc833710c2bc362a
    (main, 2026-11-09)

Implemented:
  * primal uSVP / GSA success condition from estimator/lwe_primal.py
  * plain dual from estimator/lwe_dual.py + estimator/prob.py
  * MATZOV-style dual hybrid formulas from estimator/lwe_dual.py
  * ADPS16 Core-SVP cost exponents 0.292 classical, 0.265 quantum

This script is an independent lightweight port. It is NOT SageMath and is
NOT a substitute for running the official estimator or the 2026 MLWE
structure-aware attack implementations.

Security estimates are heuristic attack-cost estimates, not lower bounds.
"""

import math
import json
from pathlib import Path

COMMIT = "7d59f866655362ea8eab803dbc833710c2bc362a"

def delta(beta):
    beta = float(beta)
    if beta <= 2:
        return 1.02190
    small = [
        (2, 1.02190), (5, 1.01862), (10, 1.01616), (15, 1.01485),
        (20, 1.01420), (25, 1.01342), (28, 1.01331), (40, 1.01295)
    ]
    if beta < 40:
        for i in range(1, len(small)):
            if small[i][0] > beta:
                return small[i-1][1]
    if beta == 40:
        return small[-1][1]
    return (
        beta / (2 * math.pi * math.e) * (math.pi * beta) ** (1 / beta)
    ) ** (1 / (2 * (beta - 1)))

def logadd2(a, b):
    if a == -math.inf:
        return b
    if b == -math.inf:
        return a
    M = max(a, b)
    return M + math.log2(1 + 2 ** (-abs(a-b)))

def primal_dimension(n, q, xs, xe, sample_count, beta):
    # LWEParameters.normalize() leaves equal secret/error stddev unchanged.
    xi = 1.0 if xs >= xe else xe/xs
    tau = xe
    m = sample_count + n if xs <= xe else sample_count

    ld = math.log(delta(beta))
    a = -ld
    C = 0.5 * math.log(xe*xe*(beta-1) + tau*tau)
    c = math.log(tau) + n*math.log(xi) - (n+1)*math.log(q)
    b = ld*(2*beta-1) + math.log(q) - C

    if a*n*n + b*n + c >= 0:
        d = n
    else:
        disc = b*b - 4*a*c
        if disc < 0:
            return None
        d1 = (-b + math.sqrt(disc))/(2*a)
        d2 = (-b - math.sqrt(disc))/(2*a)
        if a > 0:
            d = min(m, math.ceil(d2))
        elif n <= d1:
            d = min(m, math.ceil(d1))
        else:
            return None

    d = max(d, beta)
    if d == beta and d < m:
        d += 1

    lhs = 0.5*math.log(xe*xe*(beta-1) + tau*tau)
    rhs = (
        ld*(2*beta-d-1)
        + (math.log(tau) + n*math.log(xi) + math.log(q)*(d-n-1))/d
    )
    if lhs > rhs + 1e-12:
        return None
    return d

def primal_usvp(n, q, xs, xe, sample_count, cexp):
    mmax = sample_count + n if xs <= xe else sample_count
    best = None
    for beta in range(40, min(1754, mmax)+1):
        d = primal_dimension(n, q, xs, xe, sample_count, beta)
        if d is None:
            continue
        rec = {
            "log2_cost": cexp*beta,
            "beta": beta,
            "d": d,
            "delta": delta(beta)
        }
        if best is None or rec["log2_cost"] < best["log2_cost"]:
            best = rec
    return best

def log2_majority_trials(target, log_adv):
    # Estimator prob.amplify(..., majority=True), stable in log domain.
    adv = math.exp(log_adv) if log_adv > -745 else 0.0
    if adv > target:
        return 0.0
    if adv > 1e-100:
        denom = math.log1p(-adv*adv)
        trials = 2*math.log(2-2*target)/denom
        return math.log2(math.ceil(trials))
    return math.log2(-2*math.log(2-2*target)) - 2*log_adv/math.log(2)

def plain_dual_one(n, q, std, sample_count, beta, cexp):
    dlt = delta(beta)
    # Secret and error stddev are equal, so c=q in current estimator formula.
    c = q
    m_ = math.ceil(math.sqrt(n*math.log(c)/math.log(dlt))) - n
    m_ = max(1, min(sample_count, m_))
    d = n + m_
    rho = math.sqrt(4/3)
    log_sigma_norm = (
        math.log(rho*std)
        + d*math.log(dlt)
        - (m_/d)*math.log(c)
    )
    sig2 = math.exp(2*log_sigma_norm)
    log_adv = -2*math.pi*math.pi*sig2
    logN = log2_majority_trials(0.99, log_adv)

    log_vectors_per_sieve = 0.2075*beta
    log_batches = max(0.0, logN - log_vectors_per_sieve)
    log_red = cexp*beta + log_batches
    log_total = logadd2(log_red, logN)
    return {
        "log2_cost": log_total,
        "beta": beta,
        "m": m_,
        "d": d,
        "log2_required_dual_vectors": logN,
        "log2_reduction_cost": log_red
    }

def plain_dual(n, q, std, sample_count, cexp):
    best = None
    for beta in range(40, sample_count+1):
        rec = plain_dual_one(n, q, std, sample_count, beta, cexp)
        if best is None or rec["log2_cost"] < best["log2_cost"]:
            best = rec
    return best

def coth(x):
    if x > 20:
        return 1.0
    return math.cosh(x)/math.sinh(x)

def Hf(std):
    return (
        0.5
        + math.log(math.sqrt(2*math.pi)*std)
        + math.log(coth(math.pi*math.pi*std*std))
    ) / math.log(2)

def matzov_cost(n, q, xs, xe, m, beta, p, k_enum, k_fft, cexp):
    k_lat = n-k_fft-k_enum
    if k_lat < 0 or beta > m-k_enum-k_fft or beta < 40:
        return None

    den = m+k_lat
    log_lsigma = (
        (m/den)*math.log(xe)
        + (k_lat/den)*math.log(xs*q)
        + 0.5*math.log(4/3)
        + 0.5*math.log(beta/(2*math.pi*math.e))
        + (m+k_lat-beta)*math.log(delta(beta))
    )
    v = math.exp(log_lsigma)*math.pi/q
    logN_nat = (
        4*v*v
        + (k_fft/3)*(xs*math.pi/p)**2
    )
    H = Hf(xs)
    bracket = k_enum*H + k_fft*math.log(p) + math.log(2)
    if bracket <= 0:
        return None
    logN_nat += math.log(bracket)
    logN = logN_nat/math.log(2)

    # ADPS16 short-vector cost, same shape used by estimator.
    log_batches = max(0.0, logN - 0.2075*beta)
    log_sample = cexp*beta + log_batches

    coeff = 1/(1-math.exp(-1/(2*xs*xs)))
    alpha = math.pi*math.pi*xs*xs
    a = math.exp(8*alpha*math.exp(-2*alpha)*math.tanh(alpha))
    log_pref = (
        math.log2(coeff)
        + k_enum*math.log2(2*a/math.sqrt(math.e))
        + k_enum*H
    )
    if k_fft == 0:
        log_fft = -math.inf
    else:
        log_fft = math.log2(32**2*k_fft) + (k_fft+1)*math.log2(p)
    log_table = math.log2(4*5*32) + logN
    log_guess = log_pref + logadd2(log_fft, log_table)

    return {
        "log2_cost": logadd2(log_sample, log_guess),
        "beta": beta,
        "p": p,
        "k_enum": k_enum,
        "k_fft": k_fft,
        "k_lat": k_lat,
        "d": m+k_lat,
        "log2_N": logN,
        "log2_sample": log_sample,
        "log2_guess": log_guess
    }

def matzov_opt(n, q, xs, xe, available_samples, cexp):
    # Current estimator's MATZOV implementation defaults to m=n; extra samples
    # are not required and an attacker may ignore them.
    m = min(available_samples, n)
    best = None

    # Coarse search.
    for p in range(2, 11):
        for ke in range(0, 161, 5):
            for kf in range(0, min(161-ke, n-ke)+1, 5):
                maxb = m-ke-kf
                for beta in range(250, min(maxb, 700)+1, 5):
                    rec = matzov_cost(n,q,xs,xe,m,beta,p,ke,kf,cexp)
                    if rec is not None and (best is None or rec["log2_cost"] < best["log2_cost"]):
                        best = rec

    # Unit-step local refinement.
    seed = dict(best)
    for p in range(max(2,seed["p"]-2), min(20,seed["p"]+2)+1):
        for ke in range(max(0,seed["k_enum"]-12), min(n,seed["k_enum"]+12)+1):
            for kf in range(max(0,seed["k_fft"]-12), min(n-ke,seed["k_fft"]+12)+1):
                maxb = m-ke-kf
                for beta in range(max(40,seed["beta"]-20), min(maxb,seed["beta"]+20)+1):
                    rec = matzov_cost(n,q,xs,xe,m,beta,p,ke,kf,cexp)
                    if rec is not None and rec["log2_cost"] < best["log2_cost"]:
                        best = rec
    return best

def budget_requirement(log2_kappa):
    # Dominant source term in A6 Proposition 16:
    # 12*kappa*2^-s < 2^-128.
    return 128 + math.log2(12) + log2_kappa

def run():
    cbd1_std = math.sqrt(0.5)
    C1 = dict(n=768, q=4096, xs=cbd1_std, xe=cbd1_std)

    results = {
        "metadata": {
            "lattice_estimator_commit": COMMIT,
            "cost_models": {
                "classical_core_svp": "2^(0.292 beta)",
                "quantum_core_svp": "2^(0.265 beta)"
            },
            "warning": "Heuristic attack-cost estimates; not security lower bounds."
        },
        "c1_source_j3": {},
        "c1_source_j4": {},
        "calibration_mlkem768": {},
        "budgets": {}
    }

    for label, samples in [("c1_source_j3",768),("c1_source_j4",1024)]:
        results[label]["samples"] = samples
        results[label]["primal_usvp_classical"] = primal_usvp(**C1, sample_count=samples, cexp=.292)
        results[label]["primal_usvp_quantum_reduction"] = primal_usvp(**C1, sample_count=samples, cexp=.265)
        results[label]["plain_dual_classical"] = plain_dual(C1["n"],C1["q"],cbd1_std,samples,.292)
        results[label]["plain_dual_quantum_reduction"] = plain_dual(C1["n"],C1["q"],cbd1_std,samples,.265)
        results[label]["matzov_dual_hybrid_classical"] = matzov_opt(**C1, available_samples=samples, cexp=.292)
        results[label]["matzov_dual_hybrid_quantum_reduction"] = matzov_opt(**C1, available_samples=samples, cexp=.265)

    # Calibration on coefficient-unrolled ML-KEM-768-like LWE baseline:
    # n=768, q=3329, secret/error stddev=1, m=768.
    K = dict(n=768,q=3329,xs=1.0,xe=1.0)
    results["calibration_mlkem768"]["primal_usvp_classical"] = primal_usvp(**K,sample_count=768,cexp=.292)
    results["calibration_mlkem768"]["primal_usvp_quantum_reduction"] = primal_usvp(**K,sample_count=768,cexp=.265)
    results["calibration_mlkem768"]["matzov_dual_hybrid_classical"] = matzov_opt(**K,available_samples=768,cexp=.292)

    # Exact distribution facts for CBD1 coefficient vector of length 768.
    results["cbd1_distribution"] = {
        "dimension":768,
        "stddev":cbd1_std,
        "expected_hamming_weight":384,
        "hamming_weight_stddev":math.sqrt(192),
        "shannon_entropy_bits_per_coefficient":1.5,
        "total_shannon_entropy_bits":1152,
        "min_entropy_bits_per_coefficient":1.0,
        "total_min_entropy_bits":768,
        "probability_all_zero_log2":-768
    }

    c_attack = results["c1_source_j3"]["matzov_dual_hybrid_classical"]["log2_cost"]
    q_primal = results["c1_source_j3"]["primal_usvp_quantum_reduction"]["log2_cost"]
    q_hybrid = results["c1_source_j3"]["matzov_dual_hybrid_quantum_reduction"]["log2_cost"]

    for lk in [0,10,16,20,24]:
        req = budget_requirement(lk)
        results["budgets"][str(lk)] = {
            "log2_kappa":lk,
            "continuous_required_source_exponent":req,
            "integer_requirement_from_A6_table":math.floor(req)+1,
            "classical_hybrid_margin_bits":c_attack-req,
            "quantum_primal_margin_bits":q_primal-req,
            "quantum_reduction_hybrid_margin_bits":q_hybrid-req
        }

    results["thresholds"] = {
        "max_log2_kappa_before_classical_hybrid_source_term_reaches_128_target":
            c_attack - 128 - math.log2(12),
        "max_log2_kappa_before_quantum_primal_source_term_reaches_128_target":
            q_primal - 128 - math.log2(12),
        "max_log2_kappa_before_quantum_reduction_hybrid_source_term_reaches_128_target":
            q_hybrid - 128 - math.log2(12)
    }
    return results

if __name__ == "__main__":
    out = run()
    path = Path("THESIS_II_ARTICLE_1_GO2_RESULTS.json")
    path.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))
