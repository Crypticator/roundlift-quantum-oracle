#!/usr/bin/env python3
"""Exact arithmetic self-check and conservative word-RAM budget for K4.

The NTT is only an exact implementation device for counting the classical
ROM simulator overhead. The resulting kappa is a work-model parameter, not
a universal cryptographic loss.
"""
import json, math, random
from pathlib import Path

N=256; K=4; Q=4096
PNTT=2013265921; GEN=31
psi=pow(GEN,(PNTT-1)//(2*N),PNTT); omega=psi*psi%PNTT

def bitrev(a):
    a=list(a); n=len(a); j=0
    for i in range(1,n):
        bit=n>>1
        while j & bit:
            j ^= bit; bit >>= 1
        j ^= bit
        if i<j: a[i],a[j]=a[j],a[i]
    return a

def ntt(a,root):
    n=len(a); A=bitrev([x%PNTT for x in a]); length=2
    while length<=n:
        wlen=pow(root,n//length,PNTT); half=length//2
        for i in range(0,n,length):
            w=1
            for j in range(i,i+half):
                u=A[j]; v=A[j+half]*w%PNTT
                A[j]=(u+v)%PNTT; A[j+half]=(u-v)%PNTT
                w=w*wlen%PNTT
        length*=2
    return A

def intt(A,root):
    a=ntt(A,pow(root,-1,PNTT)); ninv=pow(len(A),-1,PNTT)
    return [x*ninv%PNTT for x in a]

def negamul_ntt(a,b):
    pinv=pow(psi,-1,PNTT)
    ta=[(a[i]%PNTT)*pow(psi,i,PNTT)%PNTT for i in range(N)]
    tb=[(b[i]%PNTT)*pow(psi,i,PNTT)%PNTT for i in range(N)]
    A=ntt(ta,omega); B=ntt(tb,omega)
    c=intt([A[i]*B[i]%PNTT for i in range(N)],omega)
    c=[c[i]*pow(pinv,i,PNTT)%PNTT for i in range(N)]
    return [x-PNTT if x>PNTT//2 else x for x in c]

def negamul_naive(a,b):
    c=[0]*N
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            d=i+j
            if d<N: c[d]+=x*y
            else: c[d-N]-=x*y
    return c

def self_test(trials=12,seed=20261113):
    rng=random.Random(seed)
    for _ in range(trials):
        a=[rng.randrange(Q) for _ in range(N)]
        b=[rng.choice((-1,0,1)) for _ in range(N)]
        if negamul_ntt(a,b)!=negamul_naive(a,b): return False
    return True

logN=int(math.log2(N))
fwd_mult=N+(N//2)*logN; fwd_add=N*logN
inv_mult=(N//2)*logN+2*N; inv_add=N*logN
num_fwd=2*K                # K r transforms + K rho transforms
num_inv=K+1                # K c1 outputs + 1 c2 output
ntt_ops=num_fwd*(fwd_mult+fwd_add)+num_inv*(inv_mult+inv_add)
pointwise=(K*K+K)*N        # A^T r plus v^T r
frequency_add=(K*(K-1)+K+(K-1))*N
postprocess=4096           # deliberately conservative rank-4 cap
random_tape=(2*K+1)*N + (K*N)//2
ciphertext_pack=((K+1)*N*11)//8
counted=ntt_ops+pointwise+frequency_add+postprocess+random_tape+ciphertext_pack
ENC_CAP=2**16; PRECOMP_CAP=2**17
assert counted < ENC_CAP
KAPPA=1+4*ENC_CAP+PRECOMP_CAP
result={
  "ntt_prime":PNTT,
  "psi_order_512":pow(psi,512,PNTT)==1 and pow(psi,256,PNTT)==PNTT-1,
  "self_test":self_test(),
  "max_four_product_coeff":4*N*4095,
  "prime_half":PNTT//2,
  "core_ntt_ops":ntt_ops,
  "pointwise_mult":pointwise,
  "frequency_add":frequency_add,
  "postprocess_cap":postprocess,
  "random_tape_bytes_charged_as_ops":random_tape,
  "ciphertext_pack_bytes_charged_as_ops":ciphertext_pack,
  "counted_reencryption_word_ops":counted,
  "reencryption_cap":ENC_CAP,
  "fixed_precomputation_cap":PRECOMP_CAP,
  "kappa_upper_bound":KAPPA,
  "log2_kappa":math.log2(KAPPA),
  "log2_12kappa":math.log2(12*KAPPA),
}
out=Path(__file__).resolve().parent.parent/"results"/"k4_reduction_budget.json"
out.write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
