#!/usr/bin/env python3
import json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
exp=json.loads((ROOT/'results/expected_k4_key_numbers.json').read_text())
corr=json.loads((ROOT/'results/k4_correctness_and_sizes.json').read_text())
att=json.loads((ROOT/'results/k4_attack_baselines_and_projections.json').read_text())
bud=json.loads((ROOT/'results/k4_reduction_budget.json').read_text())

def close(a,b,tol=1e-9):
    if not math.isclose(float(a),float(b),rel_tol=0,abs_tol=tol):
        raise AssertionError((a,b))

assert corr['correctness']['certified_lt_2^-212'] is True
close(corr['correctness']['log2_upper_bound'], exp['correctness']['log2_upper_bound'])
assert corr['correctness']['witness_probability_log2']==-8192
assert corr['sizes']['public_key_bytes']==1313
assert corr['sizes']['ciphertext_bytes']==1760
close(att['baseline']['primal_usvp_classical']['log2_cost'],exp['classical_attack_estimates']['primal_usvp'])
close(att['baseline']['plain_dual_classical']['log2_cost'],exp['classical_attack_estimates']['plain_dual'])
close(att['baseline']['matzov_dual_hybrid_classical']['log2_cost'],exp['classical_attack_estimates']['matzov_dual_hybrid'])
assert bud['self_test'] is True
assert bud['kappa_upper_bound']==393217
close(bud['log2_12kappa'],exp['reduction_model']['log2_12kappa'])
print('EXPECTED-VALUE VALIDATION: PASS')
print('NOTE: coded-dual 206.210581... requires the Sage/upstream adapter and is not validated by this pure-Python script.')
