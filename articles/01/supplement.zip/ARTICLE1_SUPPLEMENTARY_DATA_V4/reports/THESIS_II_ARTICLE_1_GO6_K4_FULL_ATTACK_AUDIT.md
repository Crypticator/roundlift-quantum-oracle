# Superseded GO6 report — corrected 13 November 2026

The original GO6 wording is superseded by the corrected canonical status below. The old numerical MATZOV line and the undocumented 1280-observation search claim must not be cited.

# Article 1 — C1-K4-P12-CBD1: Corrected Canonical Status Sheet

**Samir Bouftass and ChatGPT (OpenAI)**  
**Revision:** 13 November 2026, after independent hostile audit

## Documentary status
The audit did not identify one consolidated canonical Article 1 manuscript. This sheet records the corrected scientific status without reconstructing missing prose.

## Frozen profile
\[
R=\mathbb Z_{4096}[x]/(x^{256}+1),\quad n=256,\quad k=4,\quad P=4096,\quad Q=4,\quad C=2.
\]
Secrets and errors are iid CBD1. The exact source interfaces are \(\mathrm{DMLWE}_{4,4}^{\mathrm{CBD1}}\) and \(\mathrm{DMLWE}_{4,5}^{\mathrm{CBD1}}\).

## Correctness — PROVED
\[
\varepsilon=(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2,
\]
with the actual dependent remainders, and
\[
\boxed{2^{-8192}\le\delta_{K4}<2^{-212}}.
\]
The displayed upper-bound exponent is approximately \(-212.52644748\).

## Known-attack estimates — ESTIMATED
| Attack/model | estimated log2 work |
|---|---:|
| primal uSVP classical | 227.176 |
| plain dual classical | 235.060 |
| MATZOV-style, expanded tested domain | 213.657 |
| coded-dual, corrected rotation-aware model | 206.211 |

The corrected MATZOV point is \(\beta=731,m=1024,p=3,k_{enum}=6,k_{fft}=114\). The earlier 220.54-bit figure was produced by a narrower search and is not the preferred MATZOV estimate.

The 206.210581... coded-dual value requires both the CBD1 zero-probability adaptation and the lower-bracket correction independently checked under Sage. It is a cost-model reproduction, not an executed break and not a hardness lower bound.

## Four-row versus five-row source
The reported coded-dual point uses \(m=770\), already available from the four-row source. Thus the fifth row is not needed for that specific point. No exhaustive 1280-observation search is claimed.

## Reduction-budget interpretation
\[
\kappa\le393217,\qquad\log_2(12\kappa)\approx22.170.
\]
Subtracting this modeled overhead from an attack estimate is only a conditional diagnostic. It does not establish a lower bound on adversarial work.

## Verdict
\[
\boxed{\textbf{ARTICLE 1 — CONDITIONAL PASS / ATTACK ESTIMATES MODEL-DEPENDENT}}
\]
Correctness and size arithmetic survive. Exact source hardness and complete QROM CCA security remain open.
