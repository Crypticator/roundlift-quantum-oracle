> **Historical GO5 baseline — superseded for current attack estimates.** The 220.54-bit MATZOV value below comes from the earlier restricted search. The V3 preferred MATZOV tested-domain estimate is 213.656698255976 bits; the corrected coded-dual model gives 206.210581344002 bits. Consult `ARTICLE1_CANONICAL_STATUS_V3.md` and `REPRODUCIBILITY.md` for current claims. Neither estimate is a security lower bound.

# THESIS II — ARTICLE 1 — GO 5
## C1-K4 viability audit

**Date:** 12 November 2026  
**Candidate:** C1-K4-P12-CBD1  
**Decision:** **PASS — K4 is a viable candidate for the next MODDIV-128 audit.**

This GO does not certify 128-bit security. It asks whether increasing the module rank from 3 to 4 preserves the C1 proof architecture while creating enough hardness margin to justify a full GO 6 cryptanalysis.

---

## 1. Frozen candidate

Keep every C1 ingredient except the module rank:

\[
R=\mathbb Z_{4096}[x]/(x^{256}+1),\qquad
k=4,\qquad
Q=4,\qquad C=2,
\]

with CBD1 for every secret and explicit error.

Thus the coefficient secret dimension becomes

\[
kn=4\cdot256=oxed{1024}.
\]

There is no change to:

- the modulus;
- the polynomial degree;
- the quotient maps;
- randomized quotient lifting;
- the message encoding;
- the same-\(r\) dependency in the ciphertext;
- the implicit-rejection KEM architecture.

---

## 2. Correctness proof generalizes

The A6 joint-error theorem is already expressed for a symbolic rank \(k\):

\[
\delta
\le
n(1+u^{C-1})
(a(u)b(u))^{kn}
c(u)u^{-P/4}.
\]

The proof uses the fact that each selected output coefficient contains exactly \(kn\) paired terms. Nothing in that counting argument requires \(k=3\).

For K4, using the exact rational choice

\[
u=\frac43,
\]

the finite moments are

\[
a=\frac{744601}{663552},
\qquad
b=\frac{589}{576},
\qquad
c=\frac{49}{48}.
\]

Substitution with \(kn=1024\) gives

\[
\log_2 \delta_{upper}
\approx
-212.526447.
\]

The accompanying script verifies by exact integer arithmetic

\[
oxed{\delta_{K4}<2^{-212}}.
\]

This is weaker than the K3 \(2^{-282}\) certificate, as expected, but still vastly below the security target.

---

## 3. Correctness is still not perfect

The old K3 witness can be embedded in K4.

Choose:

- \(s=0\);
- all coefficients of \(e_0=-1\);
- \(e_1=e_2=0\);
- \(
ho=0\);
- three module components of \(r\) equal to the all-one polynomial;
- the fourth component of \(r\) equal to zero.

Then \(r_0=3\) and the first error coordinate is

\[
\epsilon_0=3048
\equiv -1048\pmod{4096},
\]

which lies in the decoding region for bit 1 although the message bit is zero.

The event has probability

\[
oxed{2^{-8192}}.
\]

Hence

\[
oxed{
2^{-8192}
\le
\delta_{K4}
<
2^{-212}.
}
\]

The KEM proof must therefore retain a nonzero correctness term.

---

## 4. New exact source problems

The first CPA transition now uses

\[
oxed{\mathrm{DMLWE}_{4,4}^{\mathrm{CBD1}}},
\]

with

\[
B\leftarrow U(R^{4\times4}),\quad
t\leftarrow\chi^4,\quad
e\leftarrow\chi^4.
\]

The second transition uses

\[
oxed{\mathrm{DMLWE}_{4,5}^{\mathrm{CBD1}}},
\]

because its first four rows encode \(A^T\) and its fifth row encodes the retained lifted vector \(V^T\), all sharing the same ephemeral secret.

Thus the CPA accounting becomes

\[
\operatorname{Adv}_{CPA}
\le
\epsilon_{4,4}+
\epsilon_{4,5},
\]

and the seeded version retains the same matrix-seed conflict form.

The classical-ROM KEM composition consequently has the rank-4 analogue

\[
\operatorname{Adv}_{CCA}
\le
3\epsilon_{4,4}
+
3\epsilon_{4,5}
+
6\epsilon_A
+
Q_{RO}\delta_{K4}
+
3Q_{RO}2^{-256}.
\]

This is a re-derived rank-4 statement; it is not claimed by automatic inheritance from K3.

---

## 5. Payload sizes

### Public key

The matrix remains seed-generated, so only the quotient vector grows:

\[
|pk|
=
1+32+
\frac{4\cdot256\cdot10}{8}
=
oxed{1313\text{ bytes}}.
\]

Increase from K3:

\[
1313-993=oxed{320	ext{ bytes}}.
\]

### Ciphertext

\[
|ct|
=
\frac{(4+1)\cdot256\cdot11}{8}
=
oxed{1760\text{ bytes}}.
\]

Increase from K3:

\[
1760-1408=oxed{352	ext{ bytes}}.
\]

### Unseeded mathematical public key

The \(4\times4\) public matrix alone would occupy

\[
6144	ext{ bytes},
\]

and the quotient vector \(b\)

\[
1280	ext{ bytes},
\]

for 7424 bytes before metadata.

The 32-byte seed therefore remains essential to compactness.

---

## 6. Deterministic encryption tape

CBD coefficients:

\[
(2k+1)n=9\cdot256=2304.
\]

These require 2304 bytes under the same one-byte-per-CBD-coefficient allocation used by C1.

The lift has

\[
kn=1024
\]

uniform residues modulo four, stored as two nibbles per byte:

\[
512	ext{ bytes}.
\]

Total deterministic tape:

\[
oxed{2816	ext{ bytes}}.
\]

---

## 7. Preliminary attack baseline

Before the full GO 6 structure-aware audit, the coefficient-embedding baseline gives:

| Attack | Estimated log2 work |
|---|---:|
| primal uSVP, classical | **227.175999999999988** |
| plain dual, classical | **235.059999999999974** |
| MATZOV dual hybrid, classical | **220.538359459446355** |
| primal, quantum Core-SVP cost | **206.170000000000016** |
| hybrid with quantum reduction cost, stress only | **209.056122078301911** |

The best preliminary classical baseline is therefore approximately

\[
oxed{2^{220.54}}.
\]

This is roughly 68 bits above the K3 GO 3 attack ceiling of about \(2^{150.6}\).

These are not final K4 security numbers. GO 6 must run the structure-aware attack families specifically on rank 4.

---

## 8. Preliminary reduction margin

If, only as a diagnostic, we reuse the GO 4 fast-reduction loss

\[
\log_2(12\kappa_{fast})
\approx
21.907,
\]

then the K4 classical baseline would leave approximately

\[
220.538
-
21.907
=
oxed{198.63	ext{ bits}}
\]

after the current classical reduction loss.

Likewise the simple quantum-primal source estimate would leave about

\[
oxed{184.26	ext{ bits}}
\]

under the same *classical-loss stress calculation*.

Neither is a security theorem. The point is that K4 restores tens of bits of headroom, rather than fractions of a bit.

The weaker correctness bound \(2^{-212}\) remains negligible compared with a 128-bit target:

\[
10\cdot2^{-212}\approx2^{-208.68}.
\]

---

## 9. What must be attacked in GO 6

K4 is viable enough to justify a full adversarial audit. GO 6 must now test:

1. coded dual-hybrid attacks with rank-4 module structure;
2. rotational/isometry primal hybrids with exact iid CBD1 law;
3. 2-adic / ramified quotient attacks at \(q=4096\);
4. Boolean / algebraic / MILP attacks on the 1024 CBD1 secret coordinates;
5. whether the 5-row source materially lowers the cost relative to the 4-row source;
6. the exact fast-reduction overhead for \(k=4\), rather than reusing the K3 value;
7. classical and quantum/QROM security as separate claims.

---

## 10. GO 5 verdict

\[
oxed{	ext{PASS — C1-K4 is a serious MODDIV-128 candidate.}}
\]

The cost of increasing rank is moderate:

\[
993	o1313	ext{ bytes public key},
\]

\[
1408	o1760	ext{ bytes ciphertext}.
\]

In exchange:

- dimension rises from 768 to 1024;
- correctness remains rigorously tiny, \(\delta<2^{-212}\);
- the preliminary best classical attack rises from roughly 150.6 bits for K3 to roughly 220.5 bits for K4;
- the preliminary quantum-primal baseline rises above 200 bits.

This is exactly the margin increase that K3 lacked.

**No 128-bit certification is declared at GO 5.**
