# Article 1 claim ledger — consolidated v4

## PROVED
- pk = 1313 bytes; ct = 1760 bytes.
- `delta_K4 < 2^-212`.
- explicit legal event gives `delta_K4 >= 2^-8192`.

## ASSUMED
- hardness of exact `DMLWE_(4,4)^CBD1` and `DMLWE_(4,5)^CBD1` source distributions.

## ESTIMATED
- primal / dual / MATZOV / coded-dual attack costs.
- expanded MATZOV tested-domain diagnostic: `213.656698255976` bits.
- corrected coded-dual model reproduction: `206.210581344...` bits.
- any reduction-adjusted margin remains a conditional diagnostic.

## OPEN
- stronger structure-aware, 2-adic, Boolean, algebraic, or hybrid attacks;
- a worst-case theorem for the exact practical source tuple;
- complete QROM CCA certification;
- any global optimum claim for attack searches.

## DOCUMENTARY STATUS
The consolidated manuscript is now supplied as `ARTICLE1_CANONICAL_V4.md`, with exact source definitions, proofs and corrected estimates. This resolves the missing-document component of reservation A1-07. Concordance checks are supplied; external independent acceptance is not asserted by its editor; the scoped V4.1 critical-review verdict is recorded in the closure report.

## Article 1 closure revision V4.1
The manuscript has undergone targeted critical review. Its classical-ROM bound now explicitly retains advantage-normalization and nonzero-correctness allowances. See `ARTICLE1_CLOSURE_REPORT_V4_1.md`; that report supersedes earlier pending-manuscript status statements. The pre-existing nine scientific scripts are unchanged. New finite closure checks appear under `closure/`. The reviewer also contributed to consolidation; this is not an external independent audit.
