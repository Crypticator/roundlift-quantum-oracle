"""Independent finite checks supporting the Article 1 closure review.
Run: python check_article1_closure.py
Proofs and reduction hypotheses remain in the manuscript, not in this script.
"""
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,math,random
import numpy as np

HERE=Path(__file__).resolve().parent
chi={-1:F(1,4),0:F(1,2),1:F(1,4)}
u=F(4,3)
a=sum(pe*pr*F(1,4)*u**((abs(e)+t)*r) for e,pe in chi.items() for r,pr in chi.items() for t in range(4))
b=sum(ps*max(sum(pe*u**(s*((c+e)%2-e)) for e,pe in chi.items()) for c in range(2)) for s,ps in chi.items())
c=sum(pe*u**e for e,pe in chi.items())
assert (a,b,c)==(F(744601,663552),F(589,576),F(49,48))
bound=256*(1+u)*(a*b)**1024*c*u**-1024
assert (bound.numerator<<212)<bound.denominator
hidden=0
for v in [F(4,3),F(3,2),F(2)]:
 for e in range(-5,6):
  for t in range(4):
   for sign in [-1,1]:
    lhs=sum(pr*F(1,4)*v**(sign*(e+T-t)*r) for r,pr in chi.items() for T in range(4))
    rhs=sum(pr*F(1,4)*v**((abs(e)+T)*r) for r,pr in chi.items() for T in range(4))
    assert lhs<=rhs
    hidden+=1

# Negacyclic arithmetic via integer convolution, independently of the NTT budget code.
n=256;k=4;P=4096
def mul(a,b):
    t=np.convolve(a,b);out=t[:n].copy();out[:n-1]-=t[n:];return out
def mv(A,v,transpose=False):
    return np.array([sum((mul(A[j,i] if transpose else A[i,j],v[j]) for j in range(k)),start=np.zeros(n,dtype=np.int64)) for i in range(k)])
def dot(a,b):return sum((mul(a[i],b[i]) for i in range(k)),start=np.zeros(n,dtype=np.int64))
rng=np.random.default_rng(20261113)
def cbd(shape):return rng.integers(0,2,shape,dtype=np.int64)-rng.integers(0,2,shape,dtype=np.int64)
def execution(A,s,e0,r,e1,e2,rho,mu):
    As=mv(A,s);b=((As+e0)%P)//4;v=4*b+rho
    Ar=mv(A,r,True);c1=((Ar+e1)%P)//2;c2=((dot(v,r)+e2+2048*mu)%P)//2
    z=(2*c2-dot(2*c1,s))%P
    r0=(As+e0)%4;r1=(Ar+e1)%2;r2=(dot(v,r)+e2)%2
    err=dot(e0+rho-r0,r)+dot(r1-e1,s)+e2-r2
    assert np.array_equal(z,(2048*mu+err)%P)
    return z,err,r2
arithmetic=0
for _ in range(12):
    A=rng.integers(0,P,(k,k,n),dtype=np.int64)
    s,e0,r,e1=cbd((k,n)),cbd((k,n)),cbd((k,n)),cbd((k,n))
    e2=cbd(n);rho=rng.integers(0,4,(k,n),dtype=np.int64)
    eprev=None
    for mu in [np.zeros(n,dtype=np.int64),np.ones(n,dtype=np.int64),rng.integers(0,2,n,dtype=np.int64)]:
        z,e,r2=execution(A,s,e0,r,e1,e2,rho,mu)
        if eprev is not None:assert np.array_equal(e,eprev)
        eprev=e;arithmetic+=1
zero=np.zeros((k,n),dtype=np.int64);zpoly=np.zeros(n,dtype=np.int64)
r=zero.copy();r[:3]=1
z,e,r2=execution(A,zero,-np.ones((k,n),dtype=np.int64),r,zero,zpoly,zero,zpoly)
assert int(z[0])==int(e[0])==3048 and 1024<int(z[0])<3072 and np.all(r2==0)
margin=0
for mu in (0,1):
 for e in range(-1023,1024):
    z=(2048*mu+e)%4096
    assert int(1024<z<3072)==mu
    margin+=1

# Toy scalar version of the full-view lift identity, with adaptive message choice.
def toy_real():
    h=defaultdict(F)
    for A in range(8):
     for b in range(4):
      m=(A+b)%2
      for rho in range(2):
       for r,pr in chi.items():
        for e1,p1 in chi.items():
         for e2,p2 in chi.items():
          c1=((A*r+e1)%8)//2;c2=(((2*b+rho)*r+e2+4*m)%8)//2
          h[(A,b,m,c1,c2)]+=F(1,64)*pr*p1*p2
    return dict(h)
def toy_sim():
    h=defaultdict(F)
    for A in range(8):
     for V in range(8):
      b=V//2;m=(A+b)%2
      for r,pr in chi.items():
       for e1,p1 in chi.items():
        for e2,p2 in chi.items():
         y1=(A*r+e1)%8;y2=(V*r+e2)%8
         h[(A,b,m,y1//2,((y2+4*m)%8)//2)]+=F(1,64)*pr*p1*p2
    return dict(h)
t1,t2=toy_real(),toy_sim();assert t1==t2 and sum(t1.values())==1

# Check the explicitly derived normalization on all deterministic channels/maps
# over three messages: correct-plaintext recovery versus decryption-value guessing.
normal=0;M=3
for enc in product(range(M),repeat=M):
 for dec in product(range(M),repeat=M):
  delta=F(sum(dec[enc[m]]!=m for m in range(M)),M)
  for inv in product(range(M),repeat=M):
   rec=F(sum(inv[enc[m]]==m for m in range(M)),M)
   decguess=F(sum(inv[enc[m]]==dec[enc[m]] for m in range(M)),M)
   wins=sum((int(inv[enc[m0]]==m0)+int(inv[enc[m1]]!=m0)) for m0 in range(M) for m1 in range(M))
   beta=abs(F(wins,2*M*M)-F(1,2))
   assert rec<=2*beta+F(1,M)
   assert decguess<=2*beta+F(1,M)+delta
   normal+=1
budget=0
for qg,qh,qd in product([0,1,2,8,256],repeat=3):
 QG=qg+qd+1;QH=qh+2*qd+1;Q=QG+QH
 for L in (0,Q):
  assert L+2<=2*Q
  assert 2*L+QH+1<=3*Q+1
  budget+=1

report={'status':'PASS','seed':20261113,
 'first_moment_fractions':[str(a),str(b),str(c)],'exact_upper_lt_2_to_minus_212':True,
 'hidden_remainder_finite_cases':hidden,'rank4_error_identity_cases':arithmetic,
 'same_coins_message_independence_cases':12,'failure_witness_coefficient_zero':3048,
 'strict_decoding_margin_cases':margin,'toy_joint_lift_histogram_equal':True,
 'toy_histogram_outcomes':len(t1),'normalization_channel_cases':normal,
 'budget_envelope_cases':budget,
 'limits':'Finite checks support the manuscript proofs; they do not certify source hardness or QROM security.'}
(HERE/'ARTICLE1_CLOSURE_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
