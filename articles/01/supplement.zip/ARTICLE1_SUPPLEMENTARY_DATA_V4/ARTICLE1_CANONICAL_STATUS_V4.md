# Article 1 — statut canonique V4.1

**13 novembre 2026 — Samir Bouftass and ChatGPT (OpenAI)**

**TAMPON ACCORDÉ POUR LES RÉSULTATS ET RÉDUCTIONS CONDITIONNELLES ANNONCÉS.**

`ARTICLE1_CANONICAL_V4.md` contient désormais la révision V4.1. La preuve de correction, les lois exactes, la réduction CPA et une borne ROM classique conservatrice sont exposées. `ARTICLE1_CLOSURE_REPORT_V4_1.md` définit la portée du tampon et trace les derniers changements.

La réserve A1-07 est levée dans cette relecture : le manuscrit K4 absent est fourni et sa concordance est contrôlée. Cette relecture par l'assistant ayant participé à la rédaction n'est pas un audit indépendant externe.

Les sources exactes restent des hypothèses ; l'expandeur concret n'est pas certifié ; le théorème QROM complet et FFP-NG pour l'interface exacte restent ouverts. Le tampon de l'article ne transforme ni les estimations d'attaques en bornes inférieures, ni les résultats conditionnels en certification 128 bits.
