# Article 1 — rapport de fermeture V4.1

**13 novembre 2026 — relecture critique ciblée de Boum / ChatGPT**

## Verdict

**TAMPON ACCORDÉ POUR LE PÉRIMÈTRE SCIENTIFIQUE ANNONCÉ DE L'ARTICLE 1.**

Le manuscrit fournit ses algorithmes, lois exactes, preuve de correction, simulations CPA et borne classique conditionnelle. Les estimations d'attaques sont étiquetées comme estimations. Les hypothèses et limites sont explicites. La réserve documentaire « manuscrit K4 consolidé absent » est levée.

Le tampon atteste la cohérence de ces résultats sous les hypothèses énoncées. Il ne démontre pas la difficulté des sources, ne certifie pas 128 bits, et ne ferme pas la preuve QROM. Ces objectifs ne sont pas revendiqués comme résultats de l'article 1.

Cette relecture est effectuée par l'assistant qui a contribué à la consolidation : elle n'est donc pas présentée comme un nouvel audit indépendant ni comme une évaluation externe par les pairs. Le manuscrit et les contrôles sont livrés pour permettre une contre-vérification.

## Corrections effectuées avant le tampon

| Point | Correction V4.1 | État |
|---|---|---|
| A1-07 : texte canonique manquant | Manuscrit complet fourni en V4, relu en V4.1 et relié aux résultats K4. | CLOSED dans cette relecture |
| Justification de la borne KEM | Remplacement du raccourci V4 par une borne conservatrice explicitement dérivée avec des avantages définis comme biais. | CLOSED |
| Requêtes de vérification de plaintext | Conservation du terme corrigé de comptage des requêtes ; Q_G, Q_H, Q_RO et L explicités. | CLOSED |
| Corrections non nulles | Allocations explicites lors des conversions entre message original et résultat déchiffré, et pour le challenge honnête. | CLOSED |
| Terminologie du théorème 3 | « second moment inequality » remplacé par « inequality for the negative exponential ». Il s'agit de deux exponentielles, pas d'un deuxième moment de probabilité. | CLOSED |
| Budget de coût | Hypothèse de constantes NTT précalculées explicitée ; le compteur théorique n'est pas présenté comme un compteur d'instructions Python. | CLOSED |
| Source HHK | Version corrigée du 2 novembre 2021 identifiée ; portée classique et convention d'avantage précisées. | CLOSED |

## Borne classique retenue

Les avantages CPA et CCA sont des biais \(|\Pr[\widehat\beta=\beta]-1/2|\). Les avantages source sont des écarts de probabilités d'acceptation. Avec
\[
Q_G=q_G+q_D+1,\quad Q_H=q_H+2q_D+1,\quad Q_{RO}=Q_G+Q_H,
\]
la version V4.1 retient
\[
\operatorname{Adv}_{CCA}\le
4\epsilon_{4,4}+4\epsilon_{4,5}+8\epsilon_A
+2Q_{RO}2^{-212}+(3Q_{RO}+1)2^{-256}.
\]

Cette borne est volontairement plus faible que l'affichage abrégé V4. La preuve ne consiste pas à recopier un coefficient d'un théorème externe : elle détaille la conversion des biais, l'événement de requête du message challenge, le succès de récupération et les allowances de correction. L'allocation séparée pour des décapsulations avant challenge est conservée. Aucun paramètre du schéma n'a changé.

La valeur historique `log2(12*kappa)` reste disponible comme valeur de bookkeeping dans le code inchangé ; elle ne vaut pas perte certifiée de la nouvelle borne. Aucune ancienne marge « 184 bits » n'est réintroduite comme conclusion de sécurité.

## Relecture mathématique

- Les signes de l'identité d'erreur et la multiplication négacyclique ont été vérifiés directement.
- L'ordre d'intégration conserve les dépendances des restes ; il n'assigne pas une loi uniforme indépendante aux restes réels.
- Le maximum sur les messages est compatible avec l'événement contenant les échecs, indépendant du message à aléas fixés.
- Le témoin de probabilité `2^-8192` force le coefficient zéro à 3048 et donne un échec réel.
- La première simulation CPA produit le bon couple public. La seconde conserve un même secret sur cinq lignes et le lift conditionnel sur toute la vue publique.
- Le modèle de matrice semée et les bits hauts ignorés par le parseur sont explicitement simulés.
- Les 1313/1760 octets, les deux adaptations coded-dual et le domaine MATZOV restent inchangés.
- Les hypothèses de source, l'instanciation d'un expandeur concret et QROM restent des limites explicites, non des conclusions obtenues par les tests.

## Contrôles exécutés pendant cette fermeture

Le script autonome `closure/check_article1_closure.py` a été exécuté et a produit `closure/ARTICLE1_CLOSURE_CHECKS.json` avec statut PASS :

| Contrôle | Résultat |
|---|---|
| Fractions du certificat | 744601/663552 ; 589/576 ; 49/48 |
| Comparaison rationnelle exacte | borne strictement inférieure à 2^-212 |
| Domination du reste caché, cas finis | 264 cas |
| Identité d'erreur au rang 4 par convolution entière | 36 exécutions |
| Indépendance en message à aléas fixés | 12 triplets de messages |
| Témoin d'échec | coefficient zéro : 3048 |
| Marge stricte du décodeur | 4094 cas |
| Simulation du lift avec message choisi depuis la vue publique | histogrammes joints exacts égaux, sur un modèle scalaire réduit |
| Normalisation récupération / résultat déchiffré | 19683 canaux et applications finis |
| Enveloppe de comptage | 250 cas |

Ces tests appuient les preuves ; ils ne les remplacent pas. Les neuf scripts scientifiques antérieurs de l'article 1 sont byte-identiques. Les calculs d'attaques et la chaîne complète avaient déjà été fraîchement exécutés en V4 ; ils ne sont pas annoncés comme relancés en V4.1. Le résultat Sage demeure celui du second passage antérieur.

## Sources et traçabilité

- HHK, page ePrint primaire : https://eprint.iacr.org/2017/604. L'historique confirme la révision du 2 novembre 2021.
- Les errata indexés du PDF corrigé précisent le comptage en `q_G+q_P` : https://eprint.iacr.org/2017/604.pdf. Le téléchargement direct de cette copie renvoyait HTTP 403 ; les passages décisifs ont été contrôlés dans l'index public. La copie auteur 2017 disponible localement a servi à relire les jeux, sans la faire passer pour la version corrigée.
- La borne conservatrice du présent manuscrit est justifiée explicitement ; elle n'est pas attribuée mot pour mot à HHK.
- Le diff V4 vers V4.1, les empreintes du manuscrit et le code des contrôles sont inclus.

## Séquence des articles

Ce dossier ferme **l'article 1 seulement** dans son périmètre déclaré. Les articles 2, 3 et 4 ainsi que leurs suppléments sont conservés byte pour byte dans le dossier global. Leur travail séquentiel n'a pas été lancé pendant cette fermeture.
