# THÈSE II — Contre-vérification finale V2

**Opération SECOND PASS — 13 novembre 2026**  
**Examinateur :** Boum Boum — ChatGPT Work  
**Corpus candidat :** `THESIS_II_CORRECTED_ARTICLES_V2_2026-11-13.zip`  
**SHA-256 :** `dc423158ec2389f85dc036322945c315fd4542295c2c16b61757f31c9130eb4e`

## 1. Verdict exécutif

**Non, toutes les objections ne sont pas encore fermées. Les principales réparations mathématiques V2 sont correctes et les calculs ciblés résistent à une nouvelle exécution. Aucune nouvelle erreur scientifique centrale n’a été identifiée dans les corrections examinées.** Il reste des réserves de livraison, de cohérence documentaire et d’identification du manuscrit canonique.

Sur les **18 réserves** demandées : **14 CLOSED, 3 PARTIALLY CLOSED, 1 OPEN, 0 REGRESSION scientifique identifiée**. Ce décompte ne transforme pas les problèmes de recherche explicitement laissés ouverts en résultats démontrés.

| Article | Verdict | Peut-il être gelé ? |
|---|---|---|
| 1 | 🟡 **TAMPON CONDITIONNEL** | Les calculs vérifiés et la fiche de statut peuvent être stabilisés. Le manuscrit canonique K4 reste absent ; le dossier auxiliaire demande encore une harmonisation. |
| 2 | 🟡 **TAMPON CONDITIONNEL** | Le texte peut être stabilisé comme **interface conditionnelle**. Le dossier reproductible ne peut être fermé tant que le script corrigé n’est pas livré. |
| 3 | 🟢 **TAMPON SCIENTIFIQUE** | Oui, pour le manuscrit V2 examiné. Les deux réserves sont fermées et les cinq notices bibliographiques contrôlées. |
| 4 | 🟡 **TAMPON CONDITIONNEL** | Les réparations des preuves et les facteurs peuvent être gelés. La traçabilité des expériences doit être réparée ; FFP-NG et la composition KEM restent ouverts. |

**Tampon global de fermeture : suspendu pour le package actuel.** Cela ne signifie pas que le théorème du deuxième moment a échoué. Il tient après réparation. Cela ne signifie pas non plus que C1-K4 serait certifié PQ-128 : aucune telle certification n’est établie.

## 2. Périmètre, méthode et pièces

L’ordre de mission complet a été lu dans le texte joint. Les six pièces V2 et leur manifeste ont été examinés ; les anciennes versions ont servi uniquement à identifier les changements et les réserves persistantes. Aucun fichier candidat n’a été corrigé silencieusement.

Les six empreintes du manifeste externe et les empreintes listées dans le manifeste du supplément Article 1 sont valides. L’archive candidate originale est incluse, byte-identique, dans le ZIP de cette contre-vérification. Les autres fichiers du ZIP sont les résultats de l’audit, pas une nouvelle édition des articles.

Contrôles effectivement exécutés pendant ce second passage :

- extraction neuve du supplément Article 1 ; suppression de ses résultats calculés et de ses imports d’audit avant le test Python ; conservation séparée du fichier de référence attendu ;
- exécution de `python scripts/run_pure_python_checks.py` et contrôle des fichiers créés pendant cette exécution ;
- contrôle négatif : altération volontaire d’un résultat dans une copie de travail, rejet par le validateur, puis restauration ;
- exécution séparée du nouveau programme de recherche MATZOV ;
- exécution de l’adaptateur **V2 inchangé**, appelé par chemin relatif, sous Sage 10.10 ;
- nouveau contrôle indépendant du bracket coded-dual ; énumérations rationnelles des facteurs, de la spreadness et de CBD1 ; calcul décimal de précision 70 pour les logarithmes ;
- lecture des modifications théoriques, comparaison des versions, recherche des expressions à risque et contrôle bibliographique primaire.

Les expériences anciennes de l’article 4 n’ont pas été rejouées comme si elles constituaient une livraison V2. Aucun supplément V2 Article 2 ou Article 4 ne figure dans l’archive candidate.

## 3. Matrice des 18 réserves

« Ancien statut OPEN » signifie ici réserve encore à traiter à l’entrée de ce second passage, même lorsqu’un article avait reçu un avis global favorable. Une fermeture de surpromesse n’est pas une preuve du programme de recherche restant.

| ID | Ancien statut | Correction V2 | Vérification indépendante | Statut final |
|---|---|---|---|---|
| A1-01 | OPEN — estimation MATZOV trop restrictive | Fiche et README préfèrent 213,657 ; nouveau programme joint | 213,65669825597615 reproduit. L’ancien 220,54 subsiste dans le GO5 préliminaire et la baseline, identifiée comme historique par le README | **CLOSED** — bandeau historique supplémentaire recommandé |
| A1-02 | OPEN — JSON périmé possible | Le calcul de correction écrit son JSON ; le pipeline appelle le validateur | Quatre JSON régénérés après suppression ; référence attendue inchangée ; contrôle négatif rejeté ; pipeline PASS | **CLOSED** |
| A1-03 | OPEN — recherche 1280 non étayée | Revendication limitée à m=770 | 770<1024 ; aucune recherche exhaustive annoncée dans la fiche ; GO6 remplacé | **CLOSED** |
| A1-04 | OPEN — coût d’attaque assimilé à sécurité | Catégories ESTIMATED/CONDITIONAL explicites | Les coûts et les soustractions de pertes ne sont plus présentés comme bornes inférieures dans la fiche et le GO6 corrigé | **CLOSED** |
| A1-05 | OPEN — deuxième adaptation coded-dual omise | Patch CBD1 et bracket intégrés au code et à la fiche | Résultat 206,21058134400172 reproduit ; bracket vérifié. Docstring et RECONSTRUCTION_NOTES disent encore « only » pour CBD1 | **PARTIALLY CLOSED** — calcul fermé, contradiction documentaire restante |
| A1-06 | OPEN — chemin relatif Sage | Résolution de `__file__` avant `chdir` | Appel relatif réussi et JSON neuf écrit dans le supplément de travail | **CLOSED** |
| A1-07 | OPEN — manuscrit canonique et unités | Fiche reconnaissant honnêtement l’absence du manuscrit | Pas de manuscrit consolidé ; métadonnées RECONSTRUCTED conservées ; statut et modèle de coût à harmoniser | **PARTIALLY CLOSED** |
| A2-01 | OPEN — sortie absolue du programme | Aucune version corrigée du script livrée dans ce corpus | Inventaire : aucun supplément Article 2 V2 ; impossible de valider le correctif de chemin demandé | **OPEN** |
| A2-02 | OPEN — preuve QROM non instanciée suraffirmée | Revendication réduite à une interface conditionnelle | Résumé, §§6–8 et route 1792 octets cohérents ; obligations restantes énumérées | **CLOSED** pour la correction de portée ; composition toujours ouverte |
| A2-03 | OPEN — littérature FFP-NG incomplète | Majenz–Sisinni 2025/1997 cité ; application exacte non affirmée | Notice primaire confirmée ; abandon de l’assertion générale « Gaussian-only ». Théorèmes intégraux non accessibles : aucun MATCH déclaré | **CLOSED** pour la rectification bibliographique ; matching ouvert |
| A3-01 | OPEN — prémisse marginale ambiguë | Prémisse vectorielle jointe et contre-exemple diagonal | Post-traitement correct ; Y=(Z,Z) ne donne pas un vecteur uniforme indépendant | **CLOSED** |
| A3-02 | OPEN — D>M et bibliographie | Quotient constant distingué ; cinq notices complètes | Cas limite correct ; auteurs, titres, conférences, pages, DOI et ePrint vérifiés | **CLOSED** |
| A4-01 | OPEN — factorisation croisée injustifiée | Cauchy–Schwarz puis cas diagonal ; maximum intérieur pour r₂ | Ordre des conditionnements reconstruit ; trois facteurs retrouvés exactement ; inégalité stricte certifiée en rationnels | **CLOSED** |
| A4-02 | OPEN — fausse limite « at best 101 » | Intégration de la queue ; ancien tableau déclaré non optimal | Facteur 152 et convention vérifiés dans le lemme publié ; quatre nombres recalculés ; pas de certification KEM déduite | **CLOSED** |
| A4-03 | OPEN — obstacle gaussien dépassé | État de l’art actualisé et portée limitée | Même contrôle que A2-03 ; aucune réduction précise C1-K4 revendiquée | **CLOSED** pour la correction de portée ; matching ouvert |
| A4-04 | OPEN — problème ouvert présenté comme impossibilité | Classification en analyse partielle | Résumé et conclusion retirent le théorème d’obstruction ; aucune impossibilité générale maintenue | **CLOSED** |
| A4-05 | OPEN — signe de la décomposition CBD1 | Somme de deux variables sur les supports annoncés | Loi exacte (1/4,1/2,1/4) ; aucun reste de la différence avec ces mêmes supports | **CLOSED** |
| A4-06 | OPEN — rubans, contrôles et conclusions statistiques | Distinction ruban/famille et langage prudent | Texte amélioré, mais §6 affirme que le supplément contient les contrôles indépendants sans les joindre ni les référencer de façon immuable | **PARTIALLY CLOSED** |

## 4. Article 1 : résultats frais et limites

### 4.1 MATZOV

Le programme V2 retrouve :

\[
\log_2 T=213.65669825597615,
\quad (\beta,m,p,k_{\rm enum},k_{\rm fft})=(731,1024,3,6,114),
\]

avec \(k_{\rm lat}=904\) et \(d=1928\).

Le domaine doit être décrit par **l’algorithme réellement exécuté** : deux valeurs fixées de m, 1024 et 1280 ; balayage initial de β=700 à 900 à p=3, k_enum=11, k_fft=113 ; quatre passes de recherche par coordonnées. À chaque passe, fenêtres β±40, k_enum±20, k_fft±25 autour du point de départ de la passe, et p de 2 à 10. Les coordonnées sont optimisées successivement, pas par parcours exhaustif de leur produit cartésien.

Le point trouvé à m=1280 vaut 221,97082862527327 dans cette recherche locale. Cela ne signifie pas que disposer de plus d’observations rend l’instance plus sûre : un attaquant peut ignorer les observations supplémentaires. Cela ne prouve aucun optimum global.

**Classification : ESTIMATED — minimum trouvé parmi les points effectivement testés.** Le chiffre 220,53835945944635 demeure une référence historique du programme de baseline ; le validateur de baseline contrôle ce chiffre historique et ne valide pas le nouveau résultat à lui seul. Le nouveau programme a été exécuté séparément ici.

Point éditorial résiduel : `reports/THESIS_II_ARTICLE_1_GO5_C1_K4_VIABILITY.md`, §§7–8 et 10, est byte-identique à V1 et conserve le meilleur coût préliminaire de 220,54. Son contexte « avant GO6 » et le README, qui identifie cette baseline comme historique, permettent de ne pas le confondre avec le résultat V2 préféré. Un bandeau explicite de remplacement serait néanmoins utile pour une lecture isolée ; il n’est pas nécessaire d’effacer l’historique.

### 4.2 Coded-dual

Commit public utilisé : `7cce6a5572420004da31be58f26954cedfc885d0`.

SHA-256 de `rot_utilitaries.py`, inchangé avant/après exécution :
`44c897c7a4d2ac9c430ddd362cbd93a68167890e7b30066f56bf9b0d43f5ec6f`.

| Quantité | Valeur nouvellement calculée |
|---|---:|
| η(137828) | 0,5999982023513986 |
| η(137829) | 0,6000005551007765 |
| η(262144), ancienne borne basse | 0,7958040544375616 |
| R retenu après correction | 137829 |
| β₀=β₁ | 701 |
| log₂ T, modèle avec rotations | 206,21058134400172 |
| log₂ T, modèle sans rotations au même point | 206,79580617811772 |

Le point est \((m,n_{\rm enum},n_{\rm fft},k_{\rm fft})=(770,17,135,14)\), \(n_{\rm lat}=872\). Il satisfait bien l’encadrement demandé autour de 0,6. Il s’agit d’une reproduction numérique du **modèle modifié**, pas d’une attaque effectivement exécutée sur C1-K4.

Les deux adaptations sont présentes dans le programme : \(p_0(1)=1/2\) et remplacement en mémoire de la borne basse par `R_min = RR(1)`. La borne basse originale n’encadrait pas la cible pour ce point. Le contrôle ne prouve pas une optimisation globale en R pour toutes les distributions ou tous les paramètres.

L’appel relatif fonctionne après activation correcte de l’environnement Sage. Un premier lancement sans activation a échoué sur l’exécutable système `gap` ; son journal est conservé. Ce défaut de lancement de l’audit n’est pas imputé au candidat. L’exécution dans l’environnement activé réussit sans modifier le script V2.

### 4.3 Pipeline et interprétation

Les JSON de correction, d’attaques baseline, de structure et de budget sont neufs. `expected_k4_key_numbers.json` reste un fichier de référence distinct, dont l’empreinte ne change pas. Le validateur lit les nouveaux résultats. Le test négatif provoque une erreur lorsqu’un exposant de correction est remplacé par zéro.

Le pipeline principal ne prétend pas exécuter Sage ; il le dit explicitement. Il ne lance pas non plus la recherche MATZOV élargie. **PASS du pipeline ne signifie donc pas à lui seul reproduction de toutes les attaques** ; les deux étapes supplémentaires ont été exécutées dans cet audit.

Les 206,21 et 213,66 bits sont des coûts de méthodes données dans des modèles donnés. Aucun n’exclut une meilleure attaque. La soustraction de \(\log_2(12\kappa)\) ne crée pas une borne inférieure de sécurité. Cette distinction est correcte dans la fiche V2 et le GO6 remplacé.

## 5. Articles 2 et 3

### 5.1 Rigidité, spreadness et synchronisation

La rigidité résulte directement du test de ré-encryption sur **tous les octets de l’encodage canonique**. Si la décryption déterministe accepte m, elle a vérifié c=Enc₁(pk,m). L’injectivité de la fonction de pièces n’est pas nécessaire.

Pour chacune des 4096 valeurs de x, l’énumération de quatre couples de bits CBD1 donne une masse maximale exactement 3/4 sous \(e\mapsto\lfloor[x+e]_{4096}/2\rfloor\). Après conditionnement sur r,ρ, les 1024 erreurs de c₁ et 256 de c₂ sont indépendantes :

\[
\Pr[\operatorname{Enc}(pk,m)=c\mid r,\rho]\le(3/4)^{1280}.
\]

Ainsi \(\gamma\ge1280\log_2(4/3)=531.247999076920\ldots\). **531,248 est un arrondi**, pas une nouvelle borne inférieure exacte obtenue en arrondissant vers le haut.

Les articles 2 et 4 emploient de façon cohérente δ_ik<2⁻²¹², le deuxième moment <2⁻²⁴⁷ et σ<2⁻¹²³·⁵. Le texte distingue bien borne par variance, borne intégrée mean-only, jeu FFP-NK et sécurité du KEM. Le format de confirmation vaut exactement 1760+32=1792 octets ; sa preuve QROM exacte reste une interface conditionnelle.

### 5.2 Majenz–Sisinni : verdict **NO MATCH ESTABLISHED**

La notice primaire de [l’ePrint 2025/1997](https://eprint.iacr.org/2025/1997) confirme titre, auteurs et annonce Ring/Module-LWE avec des lois incluant les binomiales centrées. **Cela suffit à retirer l’affirmation générale « seulement gaussien » ; cela ne suffit pas à instancier un théorème.**

Le PDF ePrint renvoie HTTP 403, par le lecteur web et par téléchargement direct. La piste institutionnelle vers la thèse de Fabrizio Sisinni a aussi été suivie ; son lien intégral renvoie 403. Les recherches complémentaires n’ont pas fourni le corps du théorème. Aucun théorème, numéro, hypothèse numérique ou adaptation ne sera inventé à partir du résumé.

| Élément C1-K4 | Ce qui est effectivement contrôlé | Statut d’application du théorème |
|---|---|---|
| Module-LWE | Champ annoncé dans le résumé primaire | Hypothèses exactes non vérifiées |
| Secrets CBD1 | L’inclusion générale de binomiales centrées ne précise pas tous les rôles des distributions | Non établi |
| Erreurs CBD1 | Même limite ; CBD1 est bien une binomiale centrée, mais les conditions du théorème manquent | Non établi |
| Modulus 4096 | Aucune condition vérifiée sur ce modulus | Non établi |
| Compression Q=4 | Aucun transfert vérifié | Non établi |
| Compression C=2 | Aucun transfert vérifié | Non établi |
| Lifting aléatoire | Aucun transfert vérifié | Non établi |
| Prédicat exact de défaillance et interface FFP-NG | Aucun simulateur ou matching de jeu vérifié | Non établi |

**NO MATCH ESTABLISHED n’est pas NO MATCH : l’absence de vérification ne prouve pas l’inapplicabilité.** Une adaptation ne peut pas davantage être déclarée démontrable sans connaître et vérifier ses hypothèses. La réserve de surpromesse bibliographique est fermée par la V2 ; la tâche scientifique de correspondance exacte reste ouverte.

### 5.3 Article 3

La prémisse \((A,Y)\approx_c(A,U_M^d)\) est maintenant jointe. Le contre-exemple Y=(Z,Z), Z uniforme modulo 4, est correct : les quotients divisés par 2 ne prennent que (0,0) et (1,1), contrairement à deux bits uniformes indépendants.

Le cas D>M est bien isolé : quotient nul, donc indépendant du reste. Ce qui disparaît hors du cadre divisible est la structure de fibres égales et le produit des uniformes sur les alphabets prévus, pas nécessairement toute indépendance.

Les cinq notices de §15 concordent avec les fiches éditeur et, pour les deux identifiants cités, ePrint : Banerjee–Peikert–Rosen ; Alwen–Krenn–Pietrzak–Wichs ; Bai et al. ; Liu–Wang ; Wang–Jin–Liu–Yu. Pour cette dernière, **ASIACRYPT 2025** désigne correctement la conférence ; la fiche Springer affiche une publication en ligne le 8 décembre 2025 et une année bibliographique/copyright 2026. Il ne faut pas confondre ces deux dates. Aucune régression de la notice n’est relevée.

## 6. Article 4 : vérification des réparations centrales

### 6.1 Conditionnements du deuxième moment

Pour deux clés indépendantes et un ruban partagé, le produit des moyennes conditionnelles sur les clés est correct. L’application

\[
\mathbb E_\omega[g_{i,\alpha}g_{j,\beta}]
\le \sqrt{\mathbb E_\omega[g_{i,\alpha}^2]\,\mathbb E_\omega[g_{j,\beta}^2]}
\]

retire le besoin de factoriser deux permutations distinctes du ruban. On traite ensuite le même coefficient et le même signe pour deux clés indépendantes.

L’ordre valable est le suivant :

1. **r₂ :** fixer les clés et le reste des pièces, intégrer le coefficient commun E₂ en utilisant le maximum sur t,t′ **dans** l’espérance. On ne déclare jamais r₂ indépendant de E₂. C₂ borne ce facteur uniformément.
2. **r₁ :** fixer les deux clés ainsi que r,ρ. Les décalages c,c′ sont alors fixés avant l’intégration des coefficients de e₁. Le maximum sur ces décalages supprime la dépendance à r. On conserve à ce stade les facteurs comme fonctions des deux coefficients secrets ; leur moyenne B₂ est prise au dernier stade.
3. **r₀ :** les deux clés étant fixées, les deux restes de génération sont fixés avant l’intégration des paires partagées indépendantes (R,T)=(r_j,ρ_j). Les maxima sur t,t′ retirent la dépendance globale des restes aux clés. On conserve les fonctions des deux erreurs de génération jusqu’à leur moyenne finale A₂.
4. Après ces majorations, les paires de coefficients des erreurs de génération et des secrets sont indépendantes entre elles et iid en coordonnées. Les signes négacycliques sont couverts par les maxima. La factorisation diagonale donne \((A_2B_2)^{1024}C_2\).

L’union sur 4n² paires et Markov exponentiel au seuil total 2048 donnent la borne affichée. La rédaction V2 permet cet ordre et ne réintroduit pas la fausse indépendance de V1.

### 6.2 Arithmétique exacte

Énumération indépendante, sans import des programmes candidats, à u=6/5 :

\[
A_2=\frac{99036386572201}{83980800000000},\qquad
B_2=\frac{489677}{480000},\qquad
C_2=\frac{3721}{2500}.
\]

La comparaison rationnelle certifie strictement

\[
4\cdot256^2(A_2B_2)^{1024}C_2(6/5)^{-2048}<2^{-247}.
\]

Le logarithme calculé à haute précision vaut **−247,024841644768347…**. Le nombre −247,024841644758 de V2 diffère d’environ 10⁻¹¹, ce qui s’explique par l’évaluation flottante de logarithmes de grands entiers ; les fractions et l’inégalité stricte sont inchangées. Un arrondi à −247,024841645 évite une précision d’affichage excessive.

Puisque Var(p)≤E[p²], la conséquence σ<2⁻¹²³·⁵ est correcte. Le calcul séparé de la borne du premier moment retrouve −212,526447480511091… et une comparaison rationnelle stricte avec 2⁻²¹².

### 6.3 Borne mean-only

La source contrôlée est Hövelmanns–Hülsing–Majenz, *Failing Gracefully*, version publiée, **lemme 4, équation (30), p. 439**. Le coefficient est 152(q+1)². q compte les requêtes à eCO.RO de l’algorithme avant l’évaluation finale ; le +1 couvre cette évaluation. Le lemme permet aussi l’accès extractible indiqué par son modèle. Il ne faut pas remplacer q par un budget de KEM sans comptabiliser la réduction. [Source primaire](https://pure.tue.nl/ws/portalfiles/portal/365318897/978-3-031-22972-5_15.pdf).

Pour un même adversaire fixé, représenter les pièces honnêtes par une chaîne de bits uniformes, puis appliquer leur échantillonneur CBD1/lifting. Poser F(m,y)=p_m(Samp(y)). La majoration moyenne est uniforme en m ; Markov borne la densité de chaque relation F≥t par δ_ik/t. Le lemme s’applique à chaque relation, sans changer d’adversaire. On obtient donc des bornes de queue pour **une même variable de sortie** F_out.

Pour a=152(q+1)²δ_ik et 0<a<1 :

\[
\int_0^1\min(1,a/t)\,dt
=\int_0^a1\,dt+\int_a^1 a/t\,dt
=a+a\ln(1/a).
\]

Le logarithme de cette intégrale est naturel. Seul le diagnostic final prend −log₂. Les cas a=0 et a≥1 sont correctement traités en V2.

| q | −log₂ de la borne intégrée à δ_ik=2⁻²¹² |
|---:|---:|
| 1 | 195,607036771968 |
| 2¹⁶ | 165,836237718311 |
| 2³² | 134,129114291313 |
| 2⁶⁴ | 70,991838693076 |

Ce sont **des diagnostics d’une borne FFP-NK**, pas des bits de sécurité du KEM. La V2 retire correctement la limitation « au mieux 101 ». L’ancien tableau peut subsister comme diagnostic plus lâche dans sa convention annoncée ; il ne remplace pas le calcul à convention de requêtes explicite ci-dessus.

Une précision éditoriale demeure utile : citer directement le numéro du lemme et définir q dans les articles, au lieu de renvoyer seulement à « that lemma’s convention ». Elle ne change ni la preuve ni les nombres vérifiés.

### 6.4 CBD1, expériences et FFP-NG

La somme indépendante de B₊ uniforme sur {0,1} et B₋ uniforme sur {−1,0} a exactement les masses 1/4,1/2,1/4. Aucun reste contradictoire B₊−B₋ avec ces supports n’a été trouvé.

Les §§6 et 8 distinguent désormais ruban fixé et famille rééchantillonnée, et limitent la conclusion à l’absence d’avantage observé à 128 essais. C’est correct comme prudence statistique. La pièce manquante reste le **dossier expérimental effectivement livré** : les trois fichiers `audit_imports/` du seul supplément inclus concernent les attaques de l’article 1, pas les contrôles de convolution entière et de rubans fixés de l’article 4.

La phrase de §6 affirmant que le supplément contient ces contrôles n’est donc pas étayée par ce package. Il faut joindre les séries identifiées et leurs protocoles, ou donner une référence immuable au dossier antérieur. Les contrôles antérieurs ne doivent pas être requalifiés en nouvelles expériences V2.

## 7. Contrôle anti-surpromesse et cohérence

La recherche exhaustive demandée sur les quatre textes V2, avec lecture des occurrences, ne révèle aucune assertion affirmative de certification PQ-128, de preuve QROM exacte entièrement composée, d’optimum global ou d’impossibilité générale. Les occurrences de « Gaussian-only », « impossibility », « at best » et « 128-bit certified » sont des retraits explicites ou des négations. Le journal de recherche est joint.

Le dossier auxiliaire Article 1 conserve toutefois les contradictions documentaires A1-05/A1-07 et le rapport historique visé par A1-01. Le mot « reproduction » est légitime pour les exécutions effectivement documentées ; les imports du premier audit restent des imports historiques, et sont distingués de nos nouveaux résultats.

| Grandeur | Valeur et sens contrôlés |
|---|---|
| n,k,P,Q,C du profil | 256,4,4096,4,2 ; pas de changement des paramètres |
| pk | 1+32+4·256·10/8=1313 octets |
| ciphertext compact | 5·256·11/8=1760 octets |
| confirmation | 1760+32=1792 octets |
| δ_ik et δ_wc | δ_ik≤δ_wc<2⁻²¹² ; pas un taux conditionnel uniforme pour chaque clé |
| spreadness γ | ≥1280 log₂(4/3), environ 531,248 |
| E[p_m²] | <2⁻²⁴⁷ pour le même ruban et deux clés indépendantes |
| σ_δik | écart-type <2⁻¹²³·⁵, pas variance de cette taille |

L’article 3 travaille avec M,D,L généraux ; il n’a pas à les fixer aux paramètres C1-K4. Le C=304 des diagnostics de recherche est une constante locale du théorème, distincte du diviseur C=2 du schéma.

## 8. Sources et traçabilité

Sources primaires consultées le 13 novembre 2026 :

- [Failing Gracefully — version publiée](https://pure.tue.nl/ws/portalfiles/portal/365318897/978-3-031-22972-5_15.pdf), lemme 4, équation (30), p. 439 ; définitions de δ_ik et σ ; la numérotation diffère de celle du texte arXiv.
- [Majenz–Sisinni, ePrint 2025/1997](https://eprint.iacr.org/2025/1997), notice et résumé seulement. **Texte intégral non obtenu.**
- [Banerjee–Peikert–Rosen, EUROCRYPT 2012](https://link.springer.com/chapter/10.1007/978-3-642-29011-4_42).
- [Alwen–Krenn–Pietrzak–Wichs, CRYPTO 2013](https://link.springer.com/chapter/10.1007/978-3-642-40041-4_4), [ePrint 2013/098](https://eprint.iacr.org/2013/098).
- [Bai et al., ASIACRYPT 2019](https://link.springer.com/chapter/10.1007/978-3-030-34578-5_3), [ePrint 2019/1001](https://eprint.iacr.org/2019/1001).
- [Liu–Wang, CRYPTO 2020](https://link.springer.com/chapter/10.1007/978-3-030-56880-1_11).
- [Wang–Jin–Liu–Yu, ASIACRYPT 2025](https://link.springer.com/chapter/10.1007/978-981-95-5099-9_6), publication en ligne 2025, notice bibliographique Springer 2026.
- [Code public CodedDualAttack au commit épinglé](https://github.com/identitymapping/CodedDualAttack/tree/7cce6a5572420004da31be58f26954cedfc885d0).

Les pages éditeur ont servi au contrôle des notices, pas à certifier de nouveaux théorèmes cryptographiques. Les résultats exacts, commandes, versions, logs, inventaire et différences V1→V2 sont fournis dans le ZIP ; les gros environnements logiciels et les articles tiers ne sont pas redistribués.

## 9. Réponse finale au commandement

**Les corrections V2 ferment-elles effectivement toutes les objections du premier audit sans introduire de nouvelle erreur scientifique ?**

**Non pour la fermeture de toutes les objections ; oui pour la validité des réparations mathématiques centrales examinées.** Aucun nouveau défaut scientifique central n’a été trouvé. Quatre réserves restent non entièrement fermées, dont une ouverte faute du script corrigé. La correspondance précise à 2025/1997 n’a pas été démontrée ; l’accès au texte intégral a échoué et aucune conclusion positive n’en est tirée.

**Quels articles peuvent être gelés ?** Article 3 V2 peut être gelé. Les résultats mathématiques réparés de l’article 4 peuvent l’être aussi, mais son dossier expérimental doit être complété et sa portée reste conditionnelle. L’article 2 doit conserver son statut d’interface conditionnelle et livrer son script. Pour l’article 1, on peut stabiliser les calculs et la fiche de statut ; on ne peut pas déclarer final un manuscrit canonique qui n’est pas fourni.

Les corrections résiduelles sont décrites exactement dans `THESIS_II_V2_FINAL_CORRECTIONS.md`. Aucune nouvelle expansion, aucun changement de paramètres et aucune nouvelle construction ne sont requis pour ces corrections documentaires.
