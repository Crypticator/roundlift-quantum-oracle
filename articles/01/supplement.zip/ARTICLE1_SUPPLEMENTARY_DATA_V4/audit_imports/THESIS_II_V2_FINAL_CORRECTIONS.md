# THÈSE II V2 — Dernières corrections proposées

13 novembre 2026. Propositions seulement : **aucune modification silencieuse du corpus candidat**. Les paramètres et les résultats scientifiques réparés sont conservés. Les corrections 1–4 lèvent les réserves résiduelles du package ; les points 5–7 améliorent la précision éditoriale.

## 1. A1-05 — Supprimer les deux mentions « CBD1 seulement »

**Gravité :** majeure pour la traçabilité du résultat coded-dual ; le calcul corrigé est validé.

**Fichier :** `ARTICLE1_SUPPLEMENTARY_DATA_V2/scripts/k4_coded_dual_reproduce.sage.py`  
**Section :** docstring initiale, lignes 11–12.

**Texte actuel :**

> This adapter only monkey-patches the public code's CBD zero-probability helper so that centered binomial eta=1 (CBD1, p0=1/2) is admitted.

**Remplacement exact proposé :**

> This adapter applies two in-memory adaptations to the pinned public code: it admits CBD1 by setting compute_p0(1)=1/2, and, in the rotation-aware model, it replaces the lower search bracket by R_min=1. At the reported point the original lower bracket already exceeds the target success probability. Both adaptations are required to reproduce the reported 206.210581344... estimate. The upstream files are not modified.

**Fichier :** `ARTICLE1_SUPPLEMENTARY_DATA_V2/RECONSTRUCTION_NOTES.md`  
**Section :** « Newly reconstructed in this package », entrée de l’adaptateur.

**Texte actuel :**

> modified at runtime only to admit CBD1 (eta=1, p0=1/2).

**Remplacement exact proposé :**

> modified in memory to admit CBD1 (eta=1, p0=1/2) and to correct the rotation-aware model's lower search bracket to R_min=1. The V2 second-pass audit separately reproduced eta(137828)<0.6<=eta(137829) and log2(T)=206.21058134400172 under Sage 10.10 at the reported point.

Le code de calcul ne doit pas changer. Garder distincts l’exécution initiale de reconstruction, qui n’utilisait pas Sage, et le second passage, qui l’a effectivement exécuté.

## 2. A1-07 — Identifier ce qui est réellement canonique

**Fichiers :** `ARTICLE1_CANONICAL_STATUS_V2.md`, `PACKAGE_SUMMARY.json`, `RECONSTRUCTION_NOTES.md`.  
**Sections :** Documentary status ; métadonnées du package ; statut d’exécution.  
**Gravité :** documentaire majeure pour déclarer un article final, sans erreur dans les calculs reproduits.

**Texte actuel :**

> The audit did not identify one consolidated canonical Article 1 manuscript. This sheet records the corrected scientific status without reconstructing missing prose.

Cette phrase est honnête et doit être conservée. Elle ne satisfait pas à elle seule la demande antérieure de manuscrit canonique consolidé.

**Ajout exact proposé :**

> This file is a canonical status sheet for the audited reproducibility dossier, not the final Article 1 manuscript. A final-manuscript publication stamp is deferred until one consolidated K4 manuscript is identified, supplied and checked against this status sheet. The two source interfaces are DMLWE(4,4,CBD1) and DMLWE(4,5,CBD1). Attack-model costs and simulator word-RAM operation counts use different units; no security lower bound follows by subtracting their displayed logarithms without an explicit work/advantage assumption and the stated matrix-expander model.

**Action documentaire précise :** si le manuscrit existe, le joindre sous un nom canonique, avec son SHA-256 et sa date ; ne pas le reconstruire dans cette mission. Sinon, conserver explicitement le tampon conditionnel du dossier et l’absence de tampon de publication du manuscrit.

**Métadonnée actuelle :**

```json
"package": "ARTICLE1_SUPPLEMENTARY_DATA_RECONSTRUCTED"
```

**Remplacement proposé :**

```json
"package": "ARTICLE1_SUPPLEMENTARY_DATA_V2"
```

Conserver le fait historique que la reconstruction n’avait pas exécuté Sage, mais le qualifier par sa phase, puis ajouter séparément le résultat du second passage :

```json
"initial_reconstruction_sage_status": "NOT_EXECUTED",
"v2_second_pass_sage_status": "PASS",
"v2_second_pass_report": "THESIS_II_V2_FINAL_COUNTERAUDIT.md",
"v2_second_pass_rot_log2_cost": 206.21058134400172,
"canonical_manuscript_status": "NOT_SUPPLIED"
```

Ajouter le programme `scripts/k4_matzov_expanded_search.py` à l’inventaire des fichiers principaux. Relier le rapport de second passage à une livraison identifiée et à son manifeste ; ne pas annoncer qu’une pièce a été incluse si elle n’a pas été copiée.

## 3. A2-01 — Livrer réellement le script portable

**Fichier visé :** `article2_qrom_audit.py`.  
**Section :** dernière écriture de fichier.  
**Gravité :** mineure de code, bloquante pour fermer la réserve de reproductibilité.  
**État V2 :** le fichier n’est pas livré. La ligne suivante appartient à la V1 examinée ; elle n’est pas présentée comme un fichier V2 retrouvé :

```python
with open('/mnt/data/ARTICLE2_SUPPLEMENTARY_DATA_RECONSTRUCTED/results.json','w') as f:
    json.dump(results,f,indent=2)
```

**Remplacement exact proposé pour la livraison corrigée :**

```python
from pathlib import Path

output = Path(__file__).resolve().parent / 'results.json'
output.write_text(json.dumps(results, indent=2), encoding='utf-8')
```

Joindre le script corrigé, sa sortie fraîche et son journal dans un supplément Article 2 V2 identifié, puis l’exécuter depuis un autre répertoire de travail, sans ancienne sortie.

Attention : le script V1 produit aussi des commentaires de statut sur l’ancienne analyse mean-only et la littérature gaussienne. Le republier avec seulement le chemin corrigé créerait une incohérence avec le texte V2. Soit le qualifier explicitement comme **diagnostic historique de la seule route par variance**, sans conclusions actuelles sur FFP-NG ; soit synchroniser ces champs textuels avec les §§4–8 V2, en conservant la séparation entre calculs et interprétations. Les calculs V2 de spreadness et de la borne intégrée sont déjà fournis indépendamment dans le présent audit.

## 4. A4-06 — Rendre vérifiable le dossier expérimental annoncé

**Fichier :** `ARTICLE4_REVISED_V2.md`.  
**Sections :** §6, puis renvois de §8.  
**Gravité :** majeure de reproductibilité documentaire ; aucune invalidation du théorème du deuxième moment.

**Texte actuel :**

> The supplementary record contains both the original experiments and independent controls from the hostile audit. The controls should not be silently merged: their implementations and tape conventions differ.

**Problème :** l’archive candidate n’inclut aucun supplément Article 4 V2. Les imports d’audit du supplément Article 1 concernent les coûts d’attaque et ne constituent pas ces expériences.

**Remplacement exact proposé tant que les pièces ne sont pas jointes :**

> The experiments discussed here originate from the earlier Article 4 supplementary material and the separate first counter-audit. The present V2 package does not bundle those experimental files. Original experiments and independent fixed-tape controls must therefore remain separately identified, and the experimental reproducibility reservation remains open until the scripts, outputs and protocols are included or referenced by an immutable release and SHA-256 manifest. No new experimental run is claimed in this revision.

**Pour fermer réellement la réserve :** joindre, en deux séries séparées, les scripts originaux et les contrôles indépendants ; fournir pour chaque série le message, la graine, les nombres de clés et d’essais, les coordonnées fixées/rééchantillonnées, la convention d’avantage, l’implémentation de convolution et les sorties. Les résultats du premier audit doivent porter leur provenance et leur date, sans être renommés comme nouvelles mesures V2. Après cette inclusion, remplacer le paragraphe provisoire ci-dessus par des chemins et empreintes réels.

## 5. A1-01 — Bandeau historique recommandé pour le GO5

**Fichier :** `reports/THESIS_II_ARTICLE_1_GO5_C1_K4_VIABILITY.md`.  
**Sections :** début du document ; §§7–8 et 10.  
**Gravité :** éditoriale ; A1-01 est fermé quant au résultat V2 préféré.

**Texte historique conservé :**

> The best preliminary classical baseline is therefore approximately

suivi de \(2^{220.54}\).

Le contexte est déjà préliminaire et le README identifie cette baseline comme historique. Pour éviter une citation isolée trompeuse, **ajouter en tête**, sans changer les anciennes données :

> Historical GO5 baseline — superseded for current attack estimates. The 220.54-bit MATZOV value below comes from the earlier restricted search. The V2 preferred MATZOV tested-domain estimate is 213.656698255976 bits; the corrected coded-dual model gives 206.210581344002 bits. Consult ARTICLE1_CANONICAL_STATUS_V2.md and REPRODUCIBILITY.md for current claims. Neither estimate is a security lower bound.

## 6. A4-02 — Épingler le lemme et la convention de requêtes

**Fichiers :** `ARTICLE4_REVISED_V2.md` §5 et `ARTICLE2_REVISED_V2.md` §4.  
**Gravité :** éditoriale de précision ; le calcul mathématique est fermé.

**Texte actuel Article 4 :**

> With q quantum queries in that lemma's convention,

**Remplacement exact proposé, en notation mathématique :**

> We use Hövelmanns–Hülsing–Majenz, Failing Gracefully, published version, Lemma 4, equation (30), p. 439. Here q counts the adversary's eCO.RO queries before the final oracle evaluation; the additional final evaluation is accounted for by q+1. The bound holds in the lemma's extractable-oracle model. One fixed adversary is used for every threshold, and its input coins are uniform bits mapped to the honest CBD1 and lifting distributions. Identifying q with a complete KEM reduction's query budget remains a separate composition obligation.

Ajouter la référence complète : Kathrin Hövelmanns, Andreas Hülsing and Christian Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki-Okamoto Transform*, ASIACRYPT 2022, LNCS 13794, pp. 414–443, DOI `10.1007/978-3-031-22972-5_15` ; version éditeur publiée en ligne en 2023. Le lemme correspondant porte le numéro 5 dans la version arXiv : ne pas mélanger les numérotations.

## 7. Affichage numérique et métadonnées bibliographiques

**Fichier :** `ARTICLE4_REVISED_V2.md`, fin §3.  
**Gravité :** éditoriale, sans incidence sur l’inégalité exacte.

**Actuel :** −247.024841644758.  
**Proposition :** « approximately −247.024841645 ». Le recalcul à haute précision donne −247.024841644768347… ; les facteurs rationnels demeurent identiques.

**Fichier :** `ARTICLE3_REVISED_V2.md`, notice Wang–Jin–Liu–Yu, §15.  
**Gravité :** précision bibliographique facultative ; notice existante valide pour la conférence.

**Actuel :** ASIACRYPT 2025, Part III, pp. 167–199.  
**Complément proposé :** « ASIACRYPT 2025, Part III, LNCS 16247, pp. 167–199; first online 8 December 2025, Springer citation year 2026. » Conserver les auteurs et le DOI actuels, vérifiés.

Après toute modification effectivement acceptée, régénérer les manifestes du supplément puis du package externe. Ne pas publier les anciennes empreintes comme celles des nouveaux fichiers.
