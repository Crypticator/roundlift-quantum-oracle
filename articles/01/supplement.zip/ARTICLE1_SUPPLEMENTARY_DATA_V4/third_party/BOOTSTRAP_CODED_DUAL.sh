#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-CodedDualAttack}"
git clone https://github.com/identitymapping/CodedDualAttack "$DEST"
cd "$DEST"
git checkout 7cce6a5572420004da31be58f26954cedfc885d0
printf '\nPinned CodedDualAttack checkout ready at %s\n' "$(pwd)"
printf 'Then run from the supplementary package:\n'
printf '  sage -python scripts/k4_coded_dual_reproduce.sage.py --upstream %s --mode both\n' "$(pwd)"
