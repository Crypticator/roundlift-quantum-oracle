# Corrections apportées à l’article 1

**Édition reçue v1.0 → édition corrigée v1.1, 18 novembre 2026.** Les fichiers de la candidate reçue ont été conservés. Le diff intégral du Markdown est livré dans le dossier des vérifications. Le PDF et le LaTeX ont été régénérés à partir du nouveau manuscrit.

## Corrections indispensables à la levée des réserves

| Nº | Emplacement précis dans la v1.0 | Correction appliquée en v1.1 | Critère de levée |
|---|---|---|---|
| C01 | §5.1, théorème 3, première phrase, p. 4 | Énoncer le résultat pour toute matrice fixée ou indépendante du tirage conjoint des secrets, erreurs et pièces de chiffrement. §7.1 précise aussi l’état public fixé pour la correction à graine. | Les moyennes sur les coefficients éphémères conservent leur loi après fixation de la matrice. |
| C02 | §8, paragraphes qui définissent $Q_{RO}$ puis le test à deux messages, pp. 7–8 | Définir le jeu réel/aléatoire, le refus de décapsuler $c^*$, le domaine de l’oracle de vérification de clair et une liste observable distincte du tirage privé du défi. Écrire le couplage, le facteur $L\delta$, les deux conversions vers des biais CPA et le traitement du rejet implicite. | Une réduction CPA peut construire la liste et enregistrer les vérifications sans connaître le message défi. Les facteurs 4, 4 et 8 et les termes de correction se déduisent des étapes écrites. |
| C03 | §9, tableau, puis fin des §9.2 et 9.3, pp. 8–9 | Identifier le JSON Sage corrigé, le journal à ancienne borne, les probabilités recalculées et le statut historique du coût complet. Restreindre la conclusion sur la cinquième ligne au budget d’observations du modèle. | Le lecteur distingue 206,210581 de 206,558065 et peut identifier ce que $m=770$ établit. |

## Améliorations complémentaires intégrées

| Nº | Emplacement | Modification |
|---|---|---|
| C04 | §5.1, preuve du lemme 2, et §5.2 | Écrire explicitement la fonction paire centrée en zéro. Séparer les deux fractions par un point de multiplication dans le certificat. |
| C05 | §7.1–7.2 | Préciser l’avortement commun des deux branches et l’ordre des polynômes, coefficients et bits. |
| C06 | §9.2, références 3, 4 et 9 | Identifier la correction déjà présente dans le fork, le commit exact, la full version (a) et le papier coded-dual de CRYPTO 2025. |
| C07 | §11 et déclaration finale | Documenter l’exécution avec six sorties absentes au départ et l’origine de la v1.1. |
| C08 | Fins des preuves et métadonnées PDF | Composer les cinq carrés avec la police mathématique et mettre à jour version et métadonnées. |

Pour une nouvelle exécution complète de Sage, le supplément indique le dépôt, le commit et l’adaptateur. Le fichier `interface_polar.py` du commit charge le composant natif `./polar.o` depuis son répertoire. Le Sage compatible et les dépendances du dépôt amont font partie de cet environnement. Une telle exécution enrichirait la provenance du chiffre de coût. Elle reste facultative pour les revendications publiées de la v1.1.

Les limites sur la difficulté DMLWE, SHAKE256 concret, le QROM, le multi-utilisateur et les canaux auxiliaires figurent au verdict. Les lever demanderait de nouveaux résultats ou une étude d’implémentation.
