# TAMPON FINAL — Article 1, thèse II

**18 novembre 2026 · Décision de publication pour le préprint v1.1**

**Article.** *C1-K4-P12-CBD1: Exact Correctness, Conditional Security, and Reproducible Attack Estimates*, Samir Bouftass.

| Édition | Décision | Identification SHA-256 du PDF |
|---|---|---|
| Candidate reçue v1.0, 11 pages | TAMPON CONDITIONNEL au premier examen | `da892b931873be863d3b74158038785f8a8ebf15949f2b69feba2b60ae313bfa` |
| Édition corrigée v1.1, 12 pages | **TAMPON FINAL** | `c87aeee508a30089326b4eb79bc505c05e3dcedb743a399abf6b4c384d586e74` |

Le manuscrit Markdown accepté porte le SHA-256 `005654184c364751e53b1a778f6dc06639163d5845ec4c863f373b093adcedb6`. Le rapport complet identifie les quatre pièces reçues et le LaTeX final.

1. **Correction.** L’identité exacte, les deux queues exponentielles et les deux bornes de $2^{-8192}\leq\delta_{wc}<2^{-212}$ résistent à la contradiction. Le maximum sur les messages est pris à clé fixée avant la moyenne sur les clés honnêtes. Le témoin fait décoder le coefficient zéro à 1 pour le message zéro.
2. **Réductions.** Les quatre et cinq lignes des deux défis DMLWE préservent les distributions conjointes requises. La clé compacte suppose un oracle idéal de matrice. L’argument CCA est défendable dans le ROM classique mono-utilisateur à défi initial, aux budgets augmentés de la réduction. La version acceptée rend sa liste de requêtes et ses normalisations explicites.
3. **Reproduction.** Les six JSON Python ont été régénérés et les tailles de 1313 et 1760 octets vérifiées. La recherche MATZOV redonne 213,656698. Pour le coded-dual, le franchissement de 0,6 à $R=137829$ a été personnellement recalculé. Le coût de 206,210581 reste celui de l’exécution Sage archivée.
4. **Édition.** Contrôle des 11 pages reçues et des 12 pages finales. Le Markdown final correspond au corps LaTeX et le PDF a été reproduit page par page. La v1.1 lève les réserves C01 à C03.

**Portée.** Feu vert pour diffuser la v1.1 comme prépublication de recherche. La difficulté des sources et la sécurité d’une implémentation concrète restent ouvertes. Aucun niveau minimal de sécurité classique ou postquantique, en particulier 128 bits, n’est certifié.

Audit contradictoire et corrections réalisés dans la même mission avec assistance IA. Le présent verdict accompagne la soumission éventuelle à l’évaluation scientifique externe.
