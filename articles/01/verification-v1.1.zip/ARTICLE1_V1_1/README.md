# C1-K4-P12-CBD1 — revised preprint v1.1

**Samir Bouftass · 18 November 2026**

`ARTICLE1_C1K4_V1_1.pdf` is the 12-page article. The adjacent Markdown and LaTeX files are the editable manuscript and its typesetting source. To rebuild from the LaTeX source with a full TeX Live installation and the fonts named in the preamble, run XeLaTeX twice.

```sh
xelatex -halt-on-error ARTICLE1_C1K4_V1_1.tex
xelatex -halt-on-error ARTICLE1_C1K4_V1_1.tex
```

The V4 supplementary archive is preserved at its original SHA-256. It includes historical versions and review records. Section 11 of the v1.1 article states the provenance of the current numbers. The French audit, exact certificate, clean-run logs and complete text diff accompany this edition in the parent directory. The recorded Sage cost is historical. The corrected success-probability bracket was separately checked in Python.
