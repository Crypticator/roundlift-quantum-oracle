# Article 1 — Rapport de corrections et de vérification

**18 novembre 2026 — candidat de prépublication v1.0 (provenance : manuscrit scientifique V4.1 du 13 novembre, préparation éditoriale V0.1 du 17 novembre).**

## Corrections réalisées

1. Auteur académique identifié comme **Samir Bouftass** ; assistance de ChatGPT (OpenAI) déclarée séparément, y compris dans les références aux articles compagnons.
2. Portée des affirmations de cryptographie précisée : preuve de correction, réduction CPA sous hypothèses exactes, KEM classique conditionnel et QROM hors du périmètre du présent papier.
3. Hypothèses d'oracle, analyse du budget de requêtes, encodage, parsing et limitations d'implémentation rendus explicites sans modification du cryptosystème.
4. Bibliographie enrichie avec Majenz–Sisinni, ePrint 2025/1997 ; **aucune application automatique de FFP-NG à C1-K4 n'est prétendue**.
5. Référence coded-dual abrégée dans le texte pour éviter une ligne débordante ; l'identifiant de commit complet et son verrouillage restent dans le supplément original.
6. Reproductibilité et chronologie explicitées. PDF de 11 pages A4 produit à partir de la source Markdown, avec formules typeset et métadonnées cohérentes.

## Contrôles relancés dans cette correction

- `closure/check_article1_closure.py` : PASS ; borne rationnelle exacte, 264 cas de restes cachés, 36 cas d'identité, témoin epsilon0=3048.
- `scripts/run_pure_python_checks.py` : `EXPECTED-VALUE VALIDATION: PASS` et `PURE-PYTHON CHECKS: PASS`.
- `scripts/k4_matzov_expanded_search.py` : m=1024 donne 213.656698255976 bits dans le domaine testé, m=1280 donne 221.970828625273 bits pour son essai local.
- Les 236 expressions mathématiques de la préparation éditoriale initiale sont préservées dans le même ordre ; paramètres et lois inchangés.
- Le calcul Sage coded-dual 206.210581344 reste **archivé** ; aucune exécution Sage nouvelle n'est revendiquée dans cette révision.

## Frontière de validation

Les tests numériques ne valident pas l'hypothèse de difficulté DMLWE, n'établissent pas de borne inférieure de sécurité, et ne constituent pas une preuve QROM. Le calcul de KEM classique doit être interprété sous son modèle d'oracles et son expérience limitée explicitement. Le présent dossier **n'est ni un audit scientifique indépendant ni un tampon externe**, et ne certifie pas PQ-128.

Le supplément V4 est conservé byte pour byte ; les sorties fraîches sont livrées séparément. Aucun dépôt GitHub, DOI ni publication Zenodo n'est réalisé.
