# Audit scientifique de l’article 1 de la thèse II

**18 novembre 2026 · C1-K4-P12-CBD1 · Samir Bouftass**

**Décision. TAMPON FINAL pour le préprint v1.1 identifié ci-dessous.** La v1.0 reçue justifiait un tampon conditionnel. Les deux réserves de démonstration concernaient le domaine de quantification du théorème 3 et la liste de messages utilisée dans la réduction classique. Elles sont levées dans le texte corrigé. Le coût Sage complet reste un résultat historique explicitement qualifié. La décision porte sur la publication des affirmations délimitées de l’article.

## 1. Corpus, méthode et identités

| Pièce reçue | SHA-256 |
|---|---|
| ARTICLE1_C1K4_CORRIGE.pdf | `da892b931873be863d3b74158038785f8a8ebf15949f2b69feba2b60ae313bfa` |
| ARTICLE1_C1K4_CORRIGE.md | `836a8868c6088c50f148cc21db9ff46bcdd5b1a0aaae8a8996882e2c9b5b81ec` |
| ARTICLE1_THESE_II_CORRIGE_2026-11-18.zip | `45b865602a618b1cf514c59631543ae2f8c2fb1824d8e49d43b10b2f543cabbe` |
| RAPPORT_CORRECTIONS_ARTICLE1.md | `88b624121697d3f3fe1b18f90eb98e2a80930749374a284a9b57f6bc42a197e0` |
| Supplément V4 inclus | `d7190b6fbb7569c0bd688d6ee09edb8fe7cbf27327156e2a64ae68f082d4ce39` |

| Édition acceptée | SHA-256 |
|---|---|
| ARTICLE1_C1K4_V1_1.md | `005654184c364751e53b1a778f6dc06639163d5845ec4c863f373b093adcedb6` |
| ARTICLE1_C1K4_V1_1.tex | `b6f8342fe64b8964a4311bc4329c0b83599916abc3af306deca9ba090dff7ef2` |
| ARTICLE1_C1K4_V1_1.pdf | `c87aeee508a30089326b4eb79bc505c05e3dcedb743a399abf6b4c384d586e74` |

**Observation 01 · intégrité vérifiée · ZIP extérieur et supplément.** Les trois pièces reçues séparément sont identiques octet par octet à leurs homologues dans le ZIP. Les 11 empreintes extérieures et les 42 empreintes du supplément couvrent tous les membres hors manifestes et concordent. Le rapport de corrections sert à identifier les affirmations à examiner. Les preuves ci-dessous utilisent l’algèbre, les lois spécifiées, les publications primaires et les recalculs. L’examinateur a également apporté les corrections demandées. Le contrôle final a donc été effectué par le même intervenant, avec des programmes nouveaux et une comparaison explicite des éditions.

## 2. GO 1 — Algèbre et probabilités

**Observation 02 · validée · §2, §3 et lemme 1, v1.0 pp. 1–3.** Les applications de quotient portent sur des résidus canoniques. Comme 2 et 4 divisent 4096, retirer un multiple de 4096 conserve les restes correspondants, y compris pour un coefficient entier négatif. Et 2048 est pair, si bien que le message n’affecte pas le dernier reste à tirages fixés. Dans l’anneau commutatif, les deux termes principaux sont la même somme double, quel que soit le rang de la matrice. En substituant les trois divisions euclidiennes on trouve

$$
2c_2-(2c_1)^Ts \equiv
2048\mu+(e_0+\rho-r_0)^Tr+(r_1-e_1)^Ts+e_2-r_2\pmod {4096}.
$$

La soustraction de la partie repliée de la convolution provient de $x^{256}=-1$. Vérification indépendante de tous les 65 536 produits de monômes et de 10 752 coefficients d’exécution du profil, comprenant les matrices nulle, pleine de 4095 et aléatoires. Un contrôle calcule la multiplication par blocs signés sur un côté et par convolution suivie d’un repliement sur l’autre. Contre-épreuve simple au signe de repliement, $x^{255}x=-1$. Contre-épreuve à une indépendance tentante, si $v^Tr$ est pair alors $r_{2,i}=[e_{2,i}]_2$ sur la coordonnée considérée.

**Observation 03 · validée · §4, p. 3.** Pour les mêmes tirages, le relèvement entier de l’erreur est commun à tous les messages. Sur le cercle, une erreur de module strictement inférieur à 1024 conserve les deux bits. À la frontière, le résidu d’erreur 1024 fait échouer le bit 1 et conserve le bit 0. Une erreur entière 4096 aurait distance circulaire nulle. La preuve utilise bien une inclusion d’événements. En fait, pour chaque tirage et coordonnée, les bits 0 et 1 réussissent ou échouent ensemble hors des deux égalités de distance. Aux égalités, seul le bit 1 échoue. Le message tout-à-un réalise donc aussi un maximum pour cette règle spécifique. Cette observation indépendante a été vérifiée sur les 4096 résidus. La preuve publiée n’en a pas besoin.

Si $K$ désigne la paire de clés et $F$ l’événement de dépassement sur au moins une coordonnée, $d(K)\leq\Pr(F\mid K)$ pour chaque clé générée. L’espérance donne la borne annoncée. Conditionner sur $K$ marginalise les éventuels tirages latents de génération. Pour le modèle à graine, on retient la matrice développée dans l’état public ou on fixe l’oracle public avant la moyenne. Markov donne une borne de fraction de clés pour tout $\theta>0$. Pour $h$ chiffrements honnêtes, des pièces fraîches à chaque requête donnent une borne $h\,\mathbb E d(K)$, même avec choix adaptatifs. Aucune de ces opérations ne permet de prendre un supremum sur les clés.

**Observation 04 · validée · lemme 2, §5.1, p. 3.** Pour $u>1$, $f(y)=\mathbb E u^{yR}$ est paire par symétrie et convexe. La fonction $g(x)=\frac14\sum_{h=0}^3 f(x+h-3/2)$ est encore paire et convexe. Le terme à majorer est $g(e+3/2-t)$. La valeur absolue de son argument est maximale à $t=0$ pour $e\ge0$, à $t=3$ pour $e\le0$. Une réflexion des quatre valeurs de $h$ donne dans les deux cas l’expression de droite. Le même argument traite le signe inverse. Recherche de contre-exemple sur 1 000 combinaisons exactes, incluant cinq valeurs de $u$, les deux signes et des valeurs de $e$ hors du support CBD1. L’argument de convexité couvre également les valeurs non testées.

**Observation 05 · réserve de portée levée · théorème 3, §5.1, v1.0 et v1.1 p. 4.** L’énoncé isolé de v1.0 n’explicitait que l’indépendance de la matrice vis-à-vis des secrets et erreurs de clé. La phrase doit se lire avec les lois de §2–3. Par exemple, une matrice révélant $r[0,0]$, première coordonnée du vecteur éphémère $r$, peut rester indépendante de $s,e_0$ et des bruits. Fixer cette matrice modifie alors la loi conditionnelle de cette coordonnée de $r$. C’est un contre-exemple à une étape de conditionnement dans une généralisation de l’énoncé. Les clés honnêtes de l’article sont générées avant les pièces de chiffrement. La v1.1 spécifie une matrice fixée, ou indépendante du tirage conjoint.

Pour un coefficient et chacun des signes de la transformée exponentielle, l’ordre valide est le suivant.

1. Remplacer le facteur issu de $-r_{2,i}$ par 1 dans le sens positif et par $u$ dans le sens négatif. L’indépendance de $e_{2,i}$ vis-à-vis des termes restants fournit $c(u)$.
2. Fixer $A,s,e_0,r,\rho$. Dans le produit relatif à $e_1$, chaque bruit apparaît une seule fois avec son décalage de parité fixé. Intégrer les bruits indépendants, puis prendre le maximum des deux parités pour chaque valeur signée de $s$. Les facteurs obtenus ne dépendent plus de $r$.
3. Fixer $A,s,e_0$. Le reste $r_0$ est déterminé. Pour un coefficient de sortie les appariements signés sont des permutations dans chaque bloc. Les paires formées d’une coordonnée de $r$ et d’une coordonnée de $\rho$ sont indépendantes. Le lemme 2 domine chaque facteur par une fonction de $|e_{0,j}|$. Il reste valide si le reste dépend de tous les secrets.
4. Les variables $s$ et $e_0$ ont des coordonnées indépendantes. Leurs moyennes donnent $a^{1024}b^{1024}$. Le symétrique de CBD1 absorbe les signes fixes. Markov appliqué à chaque queue puis l’union sur les 256 sorties donnent $256(1+u)c(ab/u)^{1024}$.

Le déplacement du maximum hors de l’espérance serait numériquement faux. À $u=4/3$, pour $S=1$, le meilleur décalage est 0, avec $43/36$ contre $19/16$. Pour $S=-1$, le meilleur est 1, avec $43/48$ contre $57/64$. Le vrai facteur est $589/576$ alors que le maximum des deux moyennes vaut seulement $2353/2304$. Ce contrôle discrimine deux preuves qui pourraient autrement passer les mêmes tests de déchiffrement. Le programme indépendant a aussi vérifié les deux moments conjoints sur toute la loi d’un modèle scalaire de module 8, pour les huit matrices possibles.

**Observation 06 · certificat exact · corollaire 4, §5.2, p. 4.** L’énumération des quatre paires de bits équiprobables de CBD1 donne

$$
(a,b,c)=\left(\frac{744601}{663552},\frac{589}{576},\frac{49}{48}\right),\qquad
B=256(1+4/3)c\left(\frac{ab}{4/3}\right)^{1024}.
$$

En fraction irréductible, le numérateur $N$ a 29 406 bits et le dénominateur $D$ a 29 619 bits. Le test entier donne $2^{212}N<D<2^{213}N$. Le calcul décimal à haute précision donne $\log_2 B=-212.52644748051109146\ldots$. Les grands entiers complets figurent en hexadécimal dans `independent.json`. La deuxième inégalité localise le majorant $B$ et ne minore pas la probabilité d’échec.

**Observation 07 · témoin validé · proposition 5, §5.3, pp. 4–5.** Prendre $s=e_1=e_2=\rho=0$, tous les coefficients de $e_0$ égaux à $-1$, trois polynômes de $r$ pleins de 1 et le quatrième nul. Le message est zéro. Pour tout $A$, les coefficients de $v$ valent 4092. Le dernier reste est nul et $s=0$ annule tout le second produit, sans hypothèse sur $r_1$. Le terme constant est $3(-4)(1-255)=3048$, strictement entre 1024 et 3072. La sortie vaut donc 1 à cet endroit. Les quatre groupes de coefficients CBD1 forcés à zéro contribuent $1024+1024+256+256$ bits à l’exposant. Les groupes $e_0,\rho,r_{1:3}$ forcés à une valeur de probabilité $1/4$ contribuent $2(1024+1024+768)$. Le total est 8192. L’événement porte sur la génération complète puis le chiffrement. La probabilité du message zéro minore la moyenne des maxima. L’intervalle $2^{-8192}\le\delta_{wc}<2^{-212}$ est démontré.

## 3. GO 2 — Sécurité conditionnelle

**Observation 08 · réductions exactes · §6, v1.0 pp. 5–6.** Dans le premier hybride, le simulateur fournit $(A,F_4(y))$ puis chiffre publiquement. La branche structurée reproduit toute la clé publique. Dans la branche uniforme, les cellules sont équiprobables et le quotient est indépendant de $A$. Le second échantillon est une matrice de cinq lignes de quatre éléments d’anneau. Ses quatre premières lignes donnent $A^T$, la dernière $V^T$. Le simulateur publie $F_4(V)$ puis conserve $V$ pour le défi. Conditionnellement au quotient, à $A$, aux choix de messages et aux pièces publiques précédentes, le reste de $V$ est encore uniforme grâce à la bijection quotient–reste et à l’indépendance initiale. Les cinq lignes réutilisent le même secret éphémère. En branche uniforme, la translation du cinquième élément préserve l’uniformité jointe et $F_2$ a des cellules de même taille. Le jeu final réussit avec probabilité $1/2$. Les deux différences de probabilités de succès sont majorées par les deux écarts sources, avec coefficient un.

Deux falsifications de raisonnements voisins ont été examinées. Un reste uniforme marginalement et indépendant du quotient peut être déterminé par $A$ si on pose artificiellement $\rho=[A]_4$. De même, remplacer deux occurrences du même secret par deux secrets indépendants change la loi jointe, même si chaque marginale coïncide. L’article évite ces deux erreurs. Des histogrammes complets vérifient les hybrides sur un petit modèle avec choix de message en fonction du quotient et de la matrice. L’hypothèse de difficulté reste celle des sources exactes à quatre et cinq lignes, à petit secret et petit bruit.

**Observation 09 · modèle idéal vérifié · §7.1, p. 6.** Chaque réponse brute comprend 256 mots uniformes de 16 bits. Pour chaque valeur de 12 bits il existe exactement 16 préimages. La programmation utilise quatre bits hauts frais par mot. Sans ce tirage, un observateur de la réponse brute verrait des bits hauts anormalement nuls. Pour une graine fraîche uniforme, l’ensemble des graines déjà exposées a taille au plus $q_A^{pre}$. Sa probabilité de collision est au plus $\epsilon_A=\min(1,q_A^{pre}/2^{256})$. Dans chaque hybride, l’événement est commun aux deux branches avant la révélation de la clé. Une réponse d’avortement identique perd au plus sa probabilité dans la différence signée entre les deux branches. Deux hybrides donnent $2\epsilon_A$. Fixer SHAKE256 crée une fonction concrète pour laquelle cette programmation n’est pas disponible. Aucun théorème pour cette instanciation n’a été déduit.

**Observation 10 · réserve de preuve levée · §8, v1.0 pp. 7–8, v1.1 pp. 7–9.** La v1.0 comptait le défi dans les budgets conservateurs et parlait de tous les messages sur lesquels $G$ est évalué. La liste de l’adversaire CPA qui compare deux messages ne peut contenir l’entrée privée du challenger par simple définition. Sinon elle toucherait toujours le message caché, même sans requête de l’adversaire. La v1.1 distingue liste et budget, donne le test d’appartenance, définit l’oracle de vérification de clair et exclut le défi des requêtes de décapsulation. Ces précisions permettent de reconstruire les constantes.

Dans le jeu simulé, $c^*$ utilise une bande indépendante. Chaque vérification de clair utilise la table publique de $G$ et le rechiffrement. Avant le premier accès au message caché, les jeux coïncident sauf échec de déchiffrement d’une entrée testée. Pour une clé fixée et une entrée fraîche choisie adaptativement, ce risque est au plus $d(K)$. L’union sur $L$ entrées puis la moyenne coûtent $L\delta$. Sur un message neuf, « frais » qualifie la bande aléatoire, même si le message dépend de la transcription. Les réutilisations sont mises en cache.

Soient $p$ la probabilité que la liste touche le message chiffré et $q$ celle qu’elle contienne l’autre candidat. Si un seul candidat est présent, deviner son indice. Si les deux ou aucun y figurent, tirer au sort. Le biais signé est $(p-q)/2$ et $q\le L/M$ pour $M=2^{256}$. Ainsi $p\le2\beta_D+L/M$. Pour une sortie de récupération, tester l’égalité avec le premier candidat donne $p_{rec}\le2\beta_E+1/M$. Une collision des deux messages est déjà comprise dans ces calculs. Remplacer le clair initial par le résultat du déchiffrement du défi coûte au plus $\delta$. La v1.1 conserve le terme un peu plus large $2L/M$ du manuscrit.

Pour le rejet implicite $U^{\not\perp}$, HHK utilise $H(m,c)$, une valeur de repli secrète uniforme et un oracle de vérification de clair. Le préfixe $pk$ isole un domaine d’oracle pour l’unique clé visée. La simulation mémorise la première vérification lors de la requête de hachage. Elle peut relire sa décision pour l’extraction. Le terme de devinette du repli est au plus $Q_H/M$. Une marge supplémentaire $\delta$ couvre le défi incorrect lorsqu’on identifie une requête sur le clair d’encapsulation par l’oracle qui teste le clair déchiffré. Les chaînes mal formées prennent le rejet cohérent, une même chaîne recevra toujours la même clé de repli.

Avec $Q_H=q_H+2q_D+1$, $Q_G=q_G+q_D+1$, $Q=Q_H+Q_G\ge2$, on a $L+2\le2Q$ et $2L+Q_H+1\le3Q+1$. Chaque biais CPA est au plus $\epsilon_{4,4}+\epsilon_{4,5}+2\epsilon_A$. Les coefficients des deux biais sont 2 et 2. L’enveloppe de l’article s’ensuit avec coefficients **4, 4 et 8**, puis $2Q\,2^{-212}+(3Q+1)2^{-256}$. Les écarts sources doivent s’appliquer aux budgets augmentés des simulateurs. La correction de comptage de HHK inclut les requêtes de vérification de clair dans le terme d’échec. La branche OW-PCA n’utilise aucun oracle séparé de validité. La définition de correction de HHK est bien une moyenne sur les clés d’un maximum sur les messages. Référence primaire, §§2.1, 3.1–3.2, figures 6 et 12–14, théorèmes 3.2 et 3.4 et errata. [HHK, version du 2 novembre 2021](https://eprint.iacr.org/2017/604)

**Observation 11 · limites vérifiées · fin de §8.** Dans l’extension discutée, une fois les oracles et la clé fixés, $d_{pre}$ textes antérieurs admettent au plus $d_{pre}$ messages dont le chiffrement redonne un de ces textes et dont le déchiffrement est correct. Un défi uniforme indépendant atteint cet ensemble avec probabilité au plus $d_{pre}/M$. La fraction des messages fautifs a espérance au plus $\delta$ sous l’oracle et la génération honnêtes. L’addition fournit l’allocation de collision indiquée. Le cadre de l’encadré est classique, mono-utilisateur, défi d’abord. Le travail récent de Majenz–Sisinni traite des familles incluant les binomiales centrées. Son application à la compression et au relèvement de ce profil reste ouverte. [Majenz–Sisinni, ePrint 2025/1997](https://eprint.iacr.org/2025/1997)

## 4. GO 3 — Reproduction et unités

**Observation 12 · reproduction complète des sorties Python · §9–11 et supplément.** Une extraction sélective neuve a installé exclusivement les programmes et le fichier d’attentes utilisé pour comparaison. Les six sorties étaient absentes au lancement. La clôture a recréé son JSON, la chaîne principale en a recréé quatre, puis la recherche élargie a recréé le sixième. Les six fichiers recalculés sont identiques octet par octet à ceux du supplément. Les journaux de cette exécution et les six comparaisons SHA-256 figurent dans `BOOM_INDEPENDENT_CHECKS/replay/`. Environnement observé, Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0. Le script d’origine fixe littéralement l’exposant −8192 dans sa sortie. D’où l’intérêt de recalculer séparément la masse de l’événement à partir des lois, comme en observation 07.

| Valeur | Vérification indépendante ou relance | Portée |
|---|---|---|
| Clé publique 1313 octets | $1+32+1024\times10/8$ | Profil à graine, identifiant inclus |
| Chiffré 1760 octets | $1280\times11/8$ | Charge canonique |
| Matrice 6144 octets | $16\times256\times12/8$ | Matrice pleine seule |
| Bande de chiffrement 2816 octets | $2304+512$ | Deux bits utiles par octet CBD1, puis deux restes par octet |
| Primal 227,176 et dual simple 235,060 | Chaîne Python, respectivement $\beta=778,805$ | Modèles classiques |
| MATZOV 213,656698255976 | $m=1024$, $(\beta,p,k_{enum},k_{fft})=(731,3,6,114)$ ; $k_{lat}=904$, $d=1928$ | Meilleur point de la procédure documentée |
| MATZOV 221,970828625273 | $m=1280$ fixé, $(760,3,10,113)$ | Sonde locale distincte |
| Coded-dual 206,210581344002 | Coût complet issu du JSON Sage corrigé ; probabilités de seuil recalculées séparément | Estimation à un point |
| Ré-encryption 63 200 | $44544+5120+4864+4096+2816+1760$ | Barème d’opérations du simulateur |

**Observation 13 · validée avec limite de modèle · §9.1 et §10, v1.0 pp. 8–10.** La recherche commence par 201 valeurs de $\beta$ à coordonnées fixées. Lors de chacun des quatre tours, les fenêtres viennent du meilleur point en début de tour. Dans chaque balayage, les coordonnées restantes prennent les valeurs du meilleur point au début de ce balayage. C’est bien ce qu’implémente le programme. La valeur historique 220,538359 appartient à une recherche plus étroite. L’essai imposant $m=1280$ est plus coûteux que celui imposant 1024 dans ces exécutions. Un adversaire qui dispose de cinq lignes conserve la faculté d’ignorer des données. Ces résultats n’établissent ni un optimum global ni une monotonie de la difficulté. La publication MATZOV situe le modèle dont s’inspire le port. [MATZOV, v2](https://zenodo.org/records/6493704)

Pour le modèle de calcul, le nombre premier auxiliaire NTT vaut 2013265921 et la magnitude des quatre produits accumulés est bornée par $4\times256\times4095=4\,193\,280$, bien en dessous du demi-module auxiliaire. La sortie du test de convolution est conforme. Le barème suppose des constantes de transformée précalculées et compte les octets de bande et d’empaquetage suivant ses propres conventions. $1+4\,2^{16}+2^{17}=393217$, d’où $\log_2(12\kappa)=22.1699286704\ldots$. Le symbole $\kappa$ désigne ici l’enveloppe de calcul affichée. Il n’existe dans ces données aucune conversion justifiée des coûts estimés de crible en opérations du simulateur et avantage d’un adversaire. En particulier, la soustraction des deux logarithmes ne fournit aucune sécurité minimale.

**Observation 14 · provenance rectifiée et seuil confirmé · §9.2–9.3, v1.0 p. 9, v1.1 pp. 9–10.** Les quatre identifiants de blobs publiés ont été retrouvés au commit `7cce6a5572420004da31be58f26954cedfc885d0`. Le SHA-256 des octets publics de `rot_utilitaries.py` est `44c897c7a4d2ac9c430ddd362cbd93a68167890e7b30066f56bf9b0d43f5ec6f`, également inscrit dans le JSON corrigé. Le fork contient déjà une correction du paramètre $\beta_1$ de l’intégrale de seuil. L’adaptateur de l’article intervient ensuite sur deux éléments distincts, $\Pr(X=0)=1/2$ pour CBD1 et l’initialisation $R_{min}=1$. La cible est 0,6. L’autre borne de départ de la version amont correspondait à $2(1/2)^{-17}=262144$.

Pour tester le seuil sans Sage, j’ai réécrit la probabilité du modèle comme mélange binomial. Avec $Z\sim\mathrm{Bin}(1024,1/2)$ et $h_z=\binom{z}{17}/\binom{1024}{17}$, prendre $h_z=0$ pour $z<17$. Alors $\eta(R)=\mathbb E[1-(1-h_Z)^R]$, croissante, et strictement croissante pour les valeurs considérées. Le calcul décimal à 52 chiffres donne

| $R$ | $\eta(R)$ recalculé |
|---:|---:|
| 137828 | 0,59999820235139856224 |
| 137829 | 0,60000055510077648072 |
| 262144 | 0,79580405443756165831 |

Les valeurs adjacentes encadrent le franchissement. La monotonie justifie le premier entier convenable. L’archive contient deux traces de nature différente. `coded_dual_sage_absolute.log` donne 206,558064614 avec l’ancienne borne et $R=262145$. `coded_dual_bracket_check.json` donne 206,210581344 avec $R=137829$. Le programme Python de validation courante ne recalcule aucun de ces deux coûts. Sage et son module Python étaient absents. Le contrôle de la provenance, du seuil et du code source n’est donc pas compté comme une exécution complète de Sage. Le modèle reçoit $m=770$, un nombre inférieur à 1024. La v1.1 précise la portée de ce constat de dimensionnement. [Source verrouillée](https://github.com/identitymapping/CodedDualAttack/tree/7cce6a5572420004da31be58f26954cedfc885d0)

## 5. GO 4 — Édition et références

**Observation 15 · concordance et composition · ensemble des pages.** Le corps LaTeX régénéré à partir du Markdown correspond caractère par caractère au corps livré dans chaque édition, après suppression des seuls blancs extérieurs. Après deux passages XeLaTeX, le texte extrait et tous les pixels à 72 dpi concordent page par page avec chaque PDF de référence dans cet environnement. Les comparaisons portent sur les 11 pages de la v1.0 et les 12 pages de la v1.1. La différence entre les SHA-256 de deux compilations d’un PDF ne constitue donc pas ici un écart de contenu. Le programme conserve les empreintes des rendus individuels et les avertissements de composition.

| Pages v1.0 | Examen visuel effectué |
|---|---|
| 1 | Titre, auteur, date, résumé, exposants de sécurité et paramètres |
| 2 | Anneau, multiplication, génération, chiffrement, seuils de décodage |
| 3 | Congruence, grandeurs conditionnelles et restes |
| 4 | Deux moments, fractions du certificat, début du témoin |
| 5 | Fin du témoin, encadré, lois sources, hypothèse de relèvement |
| 6 | Empilement de la matrice, jeu uniforme, oracle et tailles |
| 7 | Bande aléatoire, règle du rejet, budgets, début de la composition classique |
| 8 | Encadré CCA, commentaire de portée et tableau des estimations |
| 9 | Coordonnées, seuil coded-dual et unités du simulateur |
| 10 | Instructions de reproduction, conclusion et premières références |
| 11 | Suite des références et déclaration d’assistance IA |

La compilation v1.0 signale cinq glyphes de fin de preuve absents en police de texte. En v1.1, les carrés sont composés en mode mathématique. Les signes de congruence et de transposition, fractions, indices, bornes strictes et encadrés ont été revus. La dernière compilation ne signale ni glyphe manquant ni ligne trop large. L’ordre de sérialisation est désormais explicite au §7.2. Les pages finales sont numérotées 1 à 12. Les sous-sections de la version publique utilisent le vocabulaire de la cryptographie ; les noms historiques d’audits demeurent cantonnés aux pièces d’archive.

**Observation 16 · références et attribution · §1, §8, §9, références 1 à 9 et déclaration finale.** La référence HHK renvoie à la version corrigée du 2 novembre 2021. Le DOI MATZOV correspond à la v2 d’avril 2022. L’article de Hou–Jiang–Ogilvie est bien paru dans CRYPTO 2026, pp. 462–497. L’ePrint 2026/279 explique la jonction avec le papier publié et la mention *full version (a)*. La référence ajoutée à Carrier–Meyer-Hilfiger–Shen–Tillich identifie l’origine coded-dual en CRYPTO 2025. Ces travaux donnent le contexte des estimations. Ils ne mesurent pas le coût sur C1-K4 dans leurs tables. Les références 5–7 sont honnêtement indiquées comme manuscrits compagnons. Aucun résultat indispensable de correction ou de CPA n’en dépend. Majenz–Sisinni est cité à la bonne portée. Le PDF, ses métadonnées et le manuscrit attribuent l’article à Samir Bouftass, avec assistance de ChatGPT déclarée. Aucune revue de destination n’étant désignée, cet audit se prononce sur la transparence de l’attribution, pas sur une règle éditoriale propre à un éditeur. [Hou–Jiang–Ogilvie](https://doi.org/10.1007/978-3-032-35377-1_15) · [Full version (a)](https://eprint.iacr.org/2026/279) · [Carrier et al.](https://doi.org/10.1007/978-3-032-01855-7_15)

## 6. Portée du tampon

| Statut | Revendications de la v1.1 |
|---|---|
| Démontré | Identité du résidu, événement de panne strictement positif, intervalle de correction, distributions des hybrides, tailles sous l’encodage décrit |
| Conditionnel | IND-CPA sous les deux sources exactes. Clé à graine sous oracle de matrice idéal. Enveloppe IND-CCA classique sous les interfaces, hypothèses et ressources indiquées |
| Estimé | Coûts des modèles primal, dual, MATZOV et coded-dual. Comptabilité de ré-encryption dans une unité séparée |
| Ouvert | Difficulté quantitative des sources, preuve pour un expanseur concret, transfert QROM pour cette édition, sécurité multi-utilisateur, adéquation des hypothèses FFP-NG, évaluation d’une implantation et sécurité à 128 bits |

Les réserves de publication constatées sur la version reçue ont été corrigées dans l’édition identifiée. La reproduction intégrale de Sage est une limite déclarée de cet audit. Le dossier ne contient aucune attestation de niveau PQ-128.
