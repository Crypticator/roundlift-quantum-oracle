"""Run only the fixed public checks on an empty output tree, with a supplied release ZIP."""
import argparse, hashlib, io, json, platform, subprocess, sys, tempfile, zipfile
from pathlib import Path
import numpy, scipy

p=argparse.ArgumentParser()
p.add_argument('candidate',type=Path)
p.add_argument('output',type=Path)
args=p.parse_args()
out=args.output.resolve()
out.mkdir(parents=True,exist_ok=True)
outputs=['k4_correctness_and_sizes.json','k4_attack_baselines_and_projections.json','k4_structure_checks.json','k4_reduction_budget.json','k4_matzov_expanded_search.json']
sha=lambda data:hashlib.sha256(data).hexdigest()
data=args.candidate.read_bytes()
assert sha(data)=='45b865602a618b1cf514c59631543ae2f8c2fb1824d8e49d43b10b2f543cabbe'
with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(io.BytesIO(data)) as release:
    with zipfile.ZipFile(io.BytesIO(release.read('ARTICLE1_SUPPLEMENTARY_DATA_V4.zip'))) as bundle:
        # Only scripts and reference inputs. No archived output is installed.
        root=Path(tmp)
        for name in bundle.namelist():
            short=Path(*Path(name).parts[1:])
            if short.suffix=='.py' or short.as_posix()=='results/expected_k4_key_numbers.json':
                (root/short).parent.mkdir(parents=True,exist_ok=True)
                (root/short).write_bytes(bundle.read(name))
        paths=['closure/ARTICLE1_CLOSURE_CHECKS.json']+['results/'+n for n in outputs]
        assert all(not (root/path).exists() for path in paths)
        script_names=['closure/check_article1_closure.py','scripts/run_pure_python_checks.py','scripts/k4_matzov_expanded_search.py']
        comparisons={}
        for order,script in enumerate(script_names):
            cmd=[sys.executable,script]
            run=subprocess.run(cmd,cwd=root,capture_output=True,check=True)
            (out/(Path(script).stem+'.log')).write_bytes(run.stdout+run.stderr)
            expected=[[paths[0]],paths[1:-1],[paths[-1]]][order]
            for path in expected:
                current=(root/path).read_bytes()
                assert current
                archived=bundle.read('ARTICLE1_SUPPLEMENTARY_DATA_V4/'+path)
                comparisons[path]={'sha256':sha(current),'archived_sha256':sha(archived),'byte_equal_to_archive':current==archived}
                (out/Path(path).name).write_bytes(current)
        baseline=json.loads((out/outputs[1]).read_text())['baseline']
        actual=json.loads((out/outputs[-1]).read_text())['results']
        assert round(baseline['primal_usvp_classical']['log2_cost'],3)==227.176
        assert round(baseline['plain_dual_classical']['log2_cost'],3)==235.060
        assert [round(x['result']['log2_cost'],9) for x in actual]==[213.656698256,221.970828625]
        assert json.loads(release.read('VERIFY_MATZOV_2026-11-18.json'))['results']==actual
        assert 'PURE-PYTHON CHECKS: PASS' in (out/'run_pure_python_checks.log').read_text()
        report=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,platform=platform.platform(),all_six_outputs_absent_before_execution=True,outputs=comparisons,script_order=script_names,archive_sha256=sha(data))
        (out/'replay.json').write_text(json.dumps(report,indent=2)+'\n')
