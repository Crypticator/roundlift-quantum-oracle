"""Independent correctness checks and numerical checks of published model observables.
Run with Python 3.11+ and NumPy. Writes JSON to stdout.
"""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
from math import comb
import hashlib
import json
import numpy as np

# Two fair bits: enumerate equiprobable outcomes, retaining multiplicities.
atoms = (-1, 0, 0, 1)
def mean(items):
    items = list(items)
    return sum(items, F()) / len(items)

def moments(u):
    f = lambda j: (2 + u**j + u**(-j))/4
    a = mean(f(abs(e)+h) for e,h in product(atoms,range(4)))
    by_s = {s:[mean(u**(s*((d+e)%2-e)) for e in atoms) for d in (0,1)] for s in set(atoms)}
    b = mean(max(by_s[s]) for s in atoms)
    return a,b,f(1),by_s

u=F(4,3)
a,b,c,by_s = moments(u)
assert (a,b,c)==(F(744601,663552),F(589,576),F(49,48))
B=256*(1+u)*c*(a*b/u)**1024
N,D=B.as_integer_ratio()
assert (N<<212)<D<(N<<213)
with localcontext() as ctx:
    ctx.prec=55
    logB=(Decimal(N)/Decimal(D)).ln()/Decimal(2).ln()
hidden=0
for v in (F(33,32),u,F(3,2),F(2),F(5,2)):
    def phi(y):
        return mean(v**(y*r) for r in atoms)
    for e,t,sign in product(range(-12,13),range(4),(-1,1)):
        assert mean(phi(sign*(e+h-t)) for h in range(4))<=mean(phi(abs(e)+h) for h in range(4))
        hidden+=1

# Enumerate the full joint law for each fixed matrix in a one-coordinate model.
# No independence is imposed on the remainders.
toy_mgf=0
for A in range(8):
    dist=Counter()
    for s,e0,r,e1,e2,h in product(atoms,atoms,atoms,atoms,atoms,range(4)):
        bpk=((A*s+e0)%8)//4
        v=4*bpk+h
        err=(e0+h-(A*s+e0)%4)*r+((A*r+e1)%2-e1)*s+e2-(v*r+e2)%2
        z=(2*(((v*r+e2)%8)//2)-2*(((A*r+e1)%8)//2)*s)%8
        assert z==err%8
        dist[err]+=1
    for sign,factor in [(1,1),(-1,u)]:
        assert sum(n*u**(sign*e) for e,n in dist.items())/sum(dist.values())<=factor*a*b*c
        toy_mgf+=1

# Independent implementations of the two sides of the identity.
n=256
index=np.arange(n)
raw=index[:,None]-index[None,:]
def block(a):
    return a[raw % n]*np.where(raw<0,-1,1)
def mat_apply(matrix, vector):
    return np.array([sum(block(p)@v for p,v in zip(row,vector)) for row in matrix])
def dot_block(v,w):
    return sum(block(p)@s for p,s in zip(v,w))
def dot_fold(v,w):
    out=np.zeros(n,dtype=np.int64)
    for p,s in zip(v,w):
        z=np.convolve(p,s)
        out+=z[:n]
        out[:-1]-=z[n:]
    return out
rng=np.random.default_rng(1873421)
def cbd(shape):
    return rng.integers(0,2,shape)-rng.integers(0,2,shape)
def run(A,s,e0,r,e1,e2,h,mu):
    l=mat_apply(A,s)+e0
    v=(l%4096)//4*4+h
    p=mat_apply(A.swapaxes(0,1),r)+e1
    t=dot_block(v,r)+e2
    c1=(p%4096)//2
    c2=((t+2048*mu)%4096)//2
    z=(2*c2-dot_block(2*c1,s))%4096
    err=dot_fold(e0+h-l%4,r)+dot_fold(p%2-e1,s)+e2-t%2
    assert np.array_equal(z,(2048*mu+err)%4096)
    return z,err
identities=0
for kcase in range(14):
    A=rng.integers(0,4096,(4,4,n))
    if kcase<2:
        A.fill((0,4095)[kcase])
    s,e0,r,e1=(cbd((4,n)) for j in range(4))
    e2=cbd(n)
    h=rng.integers(0,4,(4,n))
    for mu in [np.zeros(n,dtype=int),np.ones(n,dtype=int),rng.integers(0,2,n)]:
        z,err=run(A,s,e0,r,e1,e2,h,mu)
        identities+=n
for j in range(n):
    monomial=np.zeros(n,dtype=int)
    monomial[j]=1
    T=block(monomial)
    assert np.all(T[(j+index)%n,index]==np.where(j+index>=n,-1,1))
    assert np.count_nonzero(T)==n
Z=np.zeros((4,n),dtype=int)
vec=Z.copy()
vec[:3]=1
z,err=run(A,Z,Z-1,vec,Z,Z[0],Z,Z[0])
assert int(z[0])==int(err[0])==3048
event_probability=F(1,2)**(1024+1024+256+256)*F(1,4)**(1024+1024+768)
assert event_probability==F(1,2**8192)
decode=lambda x: int(1024<x%4096<3072)
for j in range(4096):
    fail0=decode(j)!=0
    fail1=decode(j+2048)!=1
    assert not fail0 or fail1
    assert (fail0!=fail1)==(j in (1024,3072))

# Adaptive choice based on A and b; compare both source laws using integer masses.
def histogram(simulated,uniform):
    hist=Counter()
    for A,V in product(range(8),repeat=2):
        bpk,h=divmod(V,4)
        mu=(A^bpk)&1
        if not uniform:
            for r,e1,e2 in product(atoms,repeat=3):
                if simulated:
                    y=(A*r+e1,V*r+e2)
                else:
                    y=(A*r+e1,(4*bpk+h)*r+e2)
                hist[A,bpk,mu,(y[0]%8)//2,((y[1]+4*mu)%8)//2]+=1
        else:
            for y1,y2 in product(range(8),repeat=2):
                hist[A,bpk,mu,y1//2,((y2+4*mu)%8)//2]+=1
    return hist
real=histogram(False,False)
assert real==histogram(True,False)
final=histogram(True,True)
assert len(final)==8*2*4*4 and len(set(final.values()))==1
assert Counter(x%4096 for x in range(65536))=={x:16 for x in range(4096)}
# An exact counterexample to independence from the whole view given only b-independence.
# A and b independent, remainder A % 4: uniform given b, determined by A.
assert len({(A%4) for A in range(8)})==4

# Published rotation-success probability, recomputed as a binomial mixture at
# the three stated integer inputs. No Sage, lattice search or full cost evaluation.
def eta(repetitions):
    with localcontext() as ctx:
        ctx.prec=52
        norm=Decimal(2)**1024
        denom=Decimal(comb(1024,17))
        total=Decimal(0)
        for z in range(17,1025):
            hit=Decimal(comb(z,17))/denom
            total+=Decimal(comb(1024,z))/norm*(1-(1-hit)**repetitions)
        return total
etas={r:eta(r) for r in [137828,137829,262144]}
assert etas[137828]<Decimal('0.6')<=etas[137829]<etas[262144]
public_sizes=[1+32+1024*10//8,1280*11//8,16*256*12//8,2304+512]
assert public_sizes==[1313,1760,6144,2816]
print(json.dumps(dict(
    a=str(a),b=str(b),c=str(c), conditional_parity_moments={s:list(map(str,v)) for s,v in by_s.items()},
    N_hex=hex(N), D_hex=hex(D), N_bits=N.bit_length(),D_bits=D.bit_length(),
    exact_comparison='2^212*N < D < 2^213*N', log2_B=str(logB),
    hidden_checks=hidden,fixed_matrix_toy_tail_moments=toy_mgf,
    negacyclic_monomial_pairs=n*n,rank4_identity_coefficients=identities,
    seed=1873421,witness_coefficient=int(z[0]),event_probability='2^-8192',
    all_residue_tie_checks=4096,real_lift_histogram_cells=len(real),
    terminal_uniform_histogram_cells=len(final),raw_word_preimages=16,
    size_pk_ct_A_tape=public_sizes,eta={k:str(v) for k,v in etas.items()},
    sage_cost_recomputed=False),indent=2))
