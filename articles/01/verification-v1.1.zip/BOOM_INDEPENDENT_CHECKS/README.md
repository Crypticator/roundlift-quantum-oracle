# Vérifications reproductibles

Les chemins ci-dessous sont relatifs à la racine du dossier complet décompressé. Utiliser un Python avec NumPy et SciPy. PyMuPDF, Pandoc, XeLaTeX, les fontes DejaVu et Latin Modern et les paquets du préambule LaTeX sont nécessaires au contrôle documentaire. Le recalcul de la borne et des probabilités coded-dual utilise les entiers, fractions et décimaux de la bibliothèque standard. Aucune graine aléatoire provenant du système n’intervient dans les tests numériques indépendants.

```bash
mkdir -p mes-resultats
python BOOM_INDEPENDENT_CHECKS/independent.py > mes-resultats/independent.json
python BOOM_INDEPENDENT_CHECKS/game_checks.py > mes-resultats/game_checks.json
python BOOM_INDEPENDENT_CHECKS/replay.py CANDIDATE_V1_0/ARTICLE1_THESE_II_CORRIGE_2026-11-18.zip mes-resultats/replay
python BOOM_INDEPENDENT_CHECKS/document_checks.py CANDIDATE_V1_0 ARTICLE1_V1_1 > mes-resultats/documents.json
```

- `independent.py` reconstruit les moments, le certificat entier (numérateur et dénominateur hexadécimaux), le témoin pondéré, le décodage, l’algèbre à deux implémentations, des histogrammes de relèvement et le seuil numérique de succès. Les formules pour les probabilités coded-dual évaluent uniquement trois entrées fixées du modèle.
- `game_checks.py` vérifie séparément des identités de conversion d’avantage, les facteurs budgétaires et une simulation sur un petit espace fini. La preuve générale figure dans le manuscrit et le rapport.
- `replay.py` n’accepte que le ZIP reçu identifié par SHA-256. Il crée un répertoire temporaire et y installe les scripts et le JSON de valeurs attendues. Aucun des six JSON cibles ni aucun journal archivé n’y est copié. La validation des résultats compare ensuite les octets au supplément d’origine. Le fichier d’attentes historique utilise encore la valeur MATZOV du balayage étroit. Le contrôle distinct de la recherche élargie lit sa propre sortie et la compare au résultat daté.
- `document_checks.py` compare les deux manifestes, les trois fichiers hors archive et leurs copies, la transformation du corps Markdown en LaTeX puis le texte et les rendus des deux PDF après recompilation. Les empreintes des pixels supposent le même moteur, les mêmes polices et le même moteur de rendu. Un changement de fonte ou de distribution TeX peut modifier la pagination. L’audit a utilisé Pandoc 3.1.11.1 et XeTeX 0.999996. Les six sorties scientifiques sont distinctes du contrôle de mise en page.
- `upstream_lock_checked.json` donne les quatre blobs lus au commit d’origine et l’empreinte SHA-256 du fichier qui porte la formule de seuil. Le guide du supplément V4 décrit l’adaptateur Sage. Le coût global coded-dual demeure documenté par la trace archivée.
- `article_v1_0_vers_v1_1.diff` contient toutes les modifications textuelles de l’édition acceptée.

Les sorties de référence de cette mission figurent à côté des programmes, les six JSON et les journaux de relance dans `replay/`. Pour une vérification rapide d’intégrité, exécuter `sha256sum -c SHA256SUMS.txt` depuis la racine.
