"""Check the manuscript chain and preprint build. Requires Pandoc, XeLaTeX and PyMuPDF.
Usage: python document_checks.py original_corpus_dir revised_dir
"""
import hashlib,io,json,subprocess,sys,tempfile,zipfile
from pathlib import Path
import fitz
def digest(b):
    return hashlib.sha256(b).hexdigest()
def manifest(z,name):
    entries={}
    for l in z.read(name).decode().splitlines():
        expected,path=l.split(None,1)
        target=str(Path(name).parent/path.strip().lstrip('*'))
        assert digest(z.read(target))==expected
        entries[target]=expected
    assert set(entries)=={i.filename for i in z.infolist() if not i.is_dir() and i.filename!=name}
    return len(entries)
root,updated=[Path(s).resolve() for s in sys.argv[1:]]
paper='ARTICLE1_C1K4_CORRIGE'
archive=root/'ARTICLE1_THESE_II_CORRIGE_2026-11-18.zip'
with zipfile.ZipFile(archive) as z:
    checksum_count=manifest(z,'SHA256SUMS.txt')
    with zipfile.ZipFile(io.BytesIO(z.read('ARTICLE1_SUPPLEMENTARY_DATA_V4.zip'))) as zz:
        internal_count=manifest(zz,'ARTICLE1_SUPPLEMENTARY_DATA_V4/MANIFEST.sha256')
    for ext in ['md','pdf']:
        assert (root/(paper+'.'+ext)).read_bytes()==z.read('ARTICLE1_C1K4_CORRECTED_V1_0.'+ext)
    assert (root/'RAPPORT_CORRECTIONS_ARTICLE1.md').read_bytes()==z.read('RAPPORT_CORRECTIONS_ARTICLE1_2026-11-18.md')
    old_tex=z.read('ARTICLE1_C1K4_CORRECTED_V1_0.tex')
def verify(md,tex,pdf):
    body=subprocess.check_output(['pandoc','-f','markdown+tex_math_single_backslash','-t','latex',str(md)],text=True)
    assert body.strip()==tex.decode().split(r'\setstretch{1.045}',1)[1].split(r'\end{document}')[0].strip()
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)
        (path/'paper.tex').write_bytes(tex)
        for _ in range(2):
            subprocess.run(['xelatex','-no-shell-escape','-interaction=batchmode','-halt-on-error','paper.tex'],cwd=tmp,check=True,stdout=subprocess.PIPE)
        log=(path/'paper.log').read_text()
        with fitz.open(pdf) as orig,fitz.open(path/'paper.pdf') as rebuilt:
            assert len(orig)==len(rebuilt)
            pages=[]
            for a,b in zip(orig,rebuilt):
                va=a.get_pixmap(alpha=False); vb=b.get_pixmap(alpha=False)
                assert (va.width,va.height,va.samples)==(vb.width,vb.height,vb.samples)
                assert a.get_text()==b.get_text()
                pages.append(digest(va.samples))
    return dict(pages=len(pages),raster_72dpi_sha256=pages,text_identical_per_page=True,md_to_tex_body_exact=True,overfull_paragraphs=log.count('Overfull \\hbox'),missing_glyphs=log.count('Missing character:'))
new=updated/'ARTICLE1_C1K4_V1_1'
ans={'input_sha256':{p.name:digest(p.read_bytes()) for p in [root/(paper+'.md'),root/(paper+'.pdf'),archive,root/'RAPPORT_CORRECTIONS_ARTICLE1.md']},
     'checked_manifest_entries':[checksum_count,internal_count],
     'v1.0':verify(root/(paper+'.md'),old_tex,root/(paper+'.pdf')),
     'v1.1':verify(new.with_suffix('.md'),new.with_suffix('.tex').read_bytes(),new.with_suffix('.pdf'))}
assert ans['v1.1']['missing_glyphs']==ans['v1.1']['overfull_paragraphs']==0
print(json.dumps(ans,indent=2))
