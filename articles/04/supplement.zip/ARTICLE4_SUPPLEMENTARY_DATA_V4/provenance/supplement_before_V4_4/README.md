# Article 4 supplementary data V4

V4 synchronizes the canonical Article 1 reference, current package references, and bibliography. The scientific statements, certificate, original experiments, and independent controls are unchanged from V3.

Original experiments and independent controls remain separate, with their own scripts, seeds, protocols, and outputs. Fresh V4 executions reproduced both series, the exact second-moment certificate, and the integrated mean-only FFP-NK budget. The new execution logs are in the complete delivery's `verification/results/` directory; earlier local logs keep their original provenance.

No experiment is a proof of FFP-NG security. No complete QROM KEM certificate is asserted.
