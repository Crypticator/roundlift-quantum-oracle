# References pinned in V3

1. Kathrin Hövelmanns, Andreas Hülsing, Christian Majenz, *Failing Gracefully: Decryption Failures and the Fujisaki–Okamoto Transform*, ASIACRYPT 2022, LNCS 13794, pp. 414–443, DOI 10.1007/978-3-031-22972-5_15. V3 uses published Lemma 4, equation (30), p. 439.
2. Christian Majenz, Fabrizio Sisinni, *Provable decryption failure security for practical lattice-based PKE*, IACR ePrint 2025/1997. Only the public notice/abstract is used for the literature-status statement; exact theorem matching remains open.
