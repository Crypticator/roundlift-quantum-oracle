# Claim ledger — Article 4 V3

- PROVED: second moment < 2^-247; sigma < 2^-123.5 after the Cauchy-Schwarz repair.
- PROVED in the cited search-lemma model: integrated mean-only FFP-NK diagnostic.
- EXPERIMENTAL: structured-tape and matching/independent-key observations.
- OPEN: exact FFP-NG theorem matching; complete KEM/QROM composition; PQ-128 certification.
