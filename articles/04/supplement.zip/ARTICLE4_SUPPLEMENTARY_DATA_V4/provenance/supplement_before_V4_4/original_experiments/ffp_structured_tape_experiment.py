#!/usr/bin/env python3
"""
Heuristic full-dimension experiments for Article 4.

These experiments are NOT proofs and are not security estimates.
They probe structured encryption tapes and simple pk-dependent strategies.
Requires numpy.
"""
import numpy as np, json

n=256; k=4; P=4096; Q=4; C=2
rng=np.random.default_rng(20261113)

def negamul(a,b):
    fa=np.fft.rfft(a,2*n)
    fb=np.fft.rfft(b,2*n)
    conv=np.rint(np.fft.irfft(fa*fb,2*n)).astype(np.int64)
    return conv[:n]-conv[n:2*n]

def cbd(shape):
    return (rng.integers(0,2,size=shape)-rng.integers(0,2,size=shape)).astype(np.int64)

def keygen():
    A=rng.integers(0,P,size=(k,k,n),dtype=np.int64)
    s=cbd((k,n)); e0=cbd((k,n))
    As=np.zeros((k,n),dtype=np.int64)
    for i in range(k):
        for j in range(k):
            As[i]+=negamul(A[i,j],s[j])
    y=np.mod(As+e0,P)
    r0=np.mod(y,Q)
    b=(y-r0)//Q
    return A,s,e0,r0,b

def failure(key,tape):
    A,s,e0,r0,b=key
    r,e1,e2,rho=tape
    Atr=np.zeros((k,n),dtype=np.int64)
    for j in range(k):
        for i in range(k):
            Atr[j]+=negamul(A[i,j],r[i])
    r1=np.mod(Atr+e1,C)
    v=Q*b+rho
    vr=np.zeros(n,dtype=np.int64)
    for j in range(k):
        vr+=negamul(v[j],r[j])
    r2=np.mod(vr+e2,C)
    eps=np.zeros(n,dtype=np.int64)
    for j in range(k):
        eps+=negamul(e0[j]+rho[j]-r0[j],r[j])
        eps+=negamul(r1[j]-e1[j],s[j])
    eps+=e2-r2
    z=np.mod(eps,P)
    return bool(np.any((z>P//4)&(z<3*P//4)))

def generic_tape(active=4,rho_value=0):
    r=np.zeros((k,n),dtype=np.int64)
    r[:active]=1
    e1=cbd((k,n)); e2=cbd(n)
    rho=rng.integers(0,4,size=(k,n),dtype=np.int64)
    rho[:active]=rho_value
    return r,e1,e2,rho

def pk_tape(key,kind):
    b=key[4]
    if kind=="signb":
        r=np.where(b<512,1,-1).astype(np.int64)
    elif kind=="parityb":
        r=np.where((b%2)==0,1,-1).astype(np.int64)
    elif kind=="threshold":
        r=np.where(b<256,1,np.where(b>767,-1,0)).astype(np.int64)
    elif kind=="difference":
        r=np.sign(np.roll(b,1,axis=1)-b).astype(np.int64)
    else:
        raise ValueError(kind)
    return r,np.zeros((k,n),dtype=np.int64),np.zeros(n,dtype=np.int64),np.zeros((k,n),dtype=np.int64)

out={"warning":"heuristic Monte Carlo only"}

# Generic bad tapes: fresh random keys, one fresh tape per key.
for active in [2,3,4]:
    count=0; trials=128
    for _ in range(trials):
        if failure(keygen(),generic_tape(active,0)):
            count+=1
    out[f"generic_active_{active}_rho0"]={"failures":count,"trials":trials}

# FFP-NG-like matching-key vs independent-key experiment.
for kind in ["signb","parityb","threshold","difference"]:
    f0=f1=0; trials=128
    for _ in range(trials):
        k0=keygen(); k1=keygen()
        tape=pk_tape(k0,kind)
        f0+=failure(k0,tape)
        f1+=failure(k1,tape)
    out[f"ffp_ng_{kind}"]={
        "matching_failures":f0,
        "independent_failures":f1,
        "trials":trials,
        "empirical_advantage":abs(f0-f1)/(2*trials)
    }

print(json.dumps(out,indent=2))
with open("FFP_EXPERIMENT_RESULTS.json","w") as f:
    json.dump(out,f,indent=2)
