#!/usr/bin/env python3
import math, json
from pathlib import Path
DELTA=2.0**(-212); C=304
rows=[]
for qlog in (0,16,32,64):
    q=2**qlog
    single_bits=-(1+qlog+0.5*(math.log2(C)-212))
    var_bits=-(math.log2(3)+0.5*(math.log2(C)+qlog-123.5))
    Dq=152*(q+1)**2
    a=Dq*DELTA
    bound=1.0 if a>=1 else a*(1+math.log(1/a))
    rows.append({"q_log2":qlog,"single_threshold_bits":single_bits,"variance_leading_bits":var_bits,"D_q":str(Dq),"integrated_mean_bound":bound,"integrated_mean_bound_bits":-math.log2(bound)})
out={"delta_upper":"2^-212","published_lemma":"Hovelmanns-Hulsing-Majenz, published Lemma 4, eq. (30), p. 439","query_convention":"q eCO.RO queries before final evaluation; q+1 includes final evaluation","integrated_formula":"a*(1+ln(1/a)), a=152*(q+1)^2*delta","rows":rows,"claim_boundary":"FFP-NK diagnostics only; not KEM security bits"}
print(json.dumps(out,indent=2))
(Path(__file__).resolve().parent/'FFP_NK_BUDGET_V3.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
