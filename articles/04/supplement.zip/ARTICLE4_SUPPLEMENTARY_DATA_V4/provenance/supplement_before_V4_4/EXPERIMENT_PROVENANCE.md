# Experiment provenance — Article 4 V3

## Series A — original family-of-tapes experiment
- files: `original_experiments/ffp_structured_tape_experiment.py`, `FFP_EXPERIMENT_RESULTS.json`;
- seed 20261113; 128 trials per strategy; FFT-based negacyclic convolution;
- `generic_tape` resamples e1, e2 and non-active rho coordinates, so the generic rows probe a family of tapes rather than one complete fixed tape.

## Series B — independent controls
- files: `independent_controls/ffp_independent_fixed_tape_controls.py`, `INDEPENDENT_FIXED_TAPE_RESULTS.json`;
- seed 2026111302; all-zero message; e1=e2=0;
- r has first 2, 3 or 4 module polynomials equal to all-one, rest zero;
- `fixed_zero_rho`: complete zero lift is fixed; `fresh_uniform_rho`: lift is resampled per trial;
- 128 matching-key and 128 independent-key evaluations per row;
- exact integer negacyclic convolution via `numpy.convolve`.

The two series are not pooled. No zero empirical gap is interpreted as a security proof.
