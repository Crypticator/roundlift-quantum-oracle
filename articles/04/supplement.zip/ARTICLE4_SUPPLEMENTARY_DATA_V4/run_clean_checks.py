#!/usr/bin/env python3
"""Recompute Article 4 only from source in a clean temporary tree."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

root=Path(__file__).resolve().parent
tasks=[('certificates/ffp_second_moment_certificate.py','certificates/SECOND_MOMENT_RESULTS.json'),
       ('certificates/verify_article4_exact.py','certificates/ARTICLE4_EXACT_CHECKS.json'),
       ('certificates/verify_full_geometry.py','certificates/FULL_GEOMETRY_CHECKS.json'),
       ('original_experiments/ffp_structured_tape_experiment.py','original_experiments/FFP_EXPERIMENT_RESULTS.json'),
       ('independent_controls/ffp_independent_fixed_tape_controls.py','independent_controls/INDEPENDENT_FIXED_TAPE_RESULTS.json'),
       ('certificates/ffp_nk_budget_v3.py','certificates/FFP_NK_BUDGET_V3.json')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={}; records=[]
start=time.time_ns()
with tempfile.TemporaryDirectory(prefix='article4-v4-4-clean-') as d:
    tmp=Path(d); work=tmp/'source'; foreign=tmp/'foreign'; foreign.mkdir()
    for source,_ in tasks:
        p=work/source;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/source,p)
    assert not list(work.rglob('*.json'))
    for source,output in tasks:
        target=work/output
        assert not target.exists()
        before=time.time_ns()
        p=subprocess.run([sys.executable,str(work/source)],cwd=foreign,capture_output=True,text=True)
        assert p.returncode==0,p.stdout+p.stderr
        assert target.exists() and target.stat().st_mtime_ns>=before
        actual=json.loads(target.read_text()); results[output]=actual
        snapshot=root/output
        if snapshot.exists():
            expected=json.loads(snapshot.read_text())
            # Original experimental metadata was added without altering counts.
            if output.endswith('FFP_EXPERIMENT_RESULTS.json'):
                assert {k:v for k,v in actual.items() if k!='protocol'}=={k:v for k,v in expected.items() if k!='protocol'}
            elif output.endswith('FFP_NK_BUDGET_V3.json'):
                for old,new in zip(expected['rows'],actual['rows']):
                    assert abs(old['integrated_mean_bound_bits']-new['integrated_mean_bound_bits'])<1e-9
            else:assert expected==actual,output
        shutil.copy2(target,snapshot)
        logs=root/'logs';logs.mkdir(exist_ok=True)
        (logs/(Path(source).stem+'.log')).write_text(p.stdout+p.stderr)
        records.append({'script':source,'script_sha256':sha(work/source),'output':output,
                        'output_sha256':sha(target),'fresh':True,'returncode':p.returncode})
        print('PASS',source,flush=True)
    assert not list(foreign.iterdir()),'a script wrote output into the caller cwd'

a=results['certificates/SECOND_MOMENT_RESULTS.json'];b=results['certificates/ARTICLE4_EXACT_CHECKS.json']
assert a['certified_less_than_2^-247'] and b['strict_integer_certificate_below_2^-247']
for key in ('A2','B2','C2'):assert a[key]==b[key]
assert abs(a['log2_second_moment_upper']-b['second_moment_log2'])<1e-9
budgets=results['certificates/FFP_NK_BUDGET_V3.json']['rows']
for direct,precise in zip(budgets,b['query_budget_rows']):
    assert direct['q_log2']==precise['q_log2'] and direct['D_q']==precise['D_q']
    for first,second in [('single_threshold_bits','single_threshold_bits'),
                         ('integrated_mean_bound_bits','integrated_mean_bits'),
                         ('direct_delta_wc_bound_bits','direct_delta_wc_bits'),
                         ('variance_leading_bits','variance_leading_summand_bits')]:
        assert abs(direct[first]-precise[second])<1e-9,(first,direct,precise)
o=results['original_experiments/FFP_EXPERIMENT_RESULTS.json']
assert [o[f'generic_active_{n}_rho0']['failures'] for n in (2,3,4)]==[0,128,128]
for n in ('signb','parityb','threshold','difference'):
    row=o['ffp_ng_'+n];assert row['matching_failures']==row['independent_failures']==0
assert o['protocol']['fft_products_checked_against_integer']>0
controls=results['independent_controls/INDEPENDENT_FIXED_TAPE_RESULTS.json']
for row in controls['rows']:
    expected=128 if row['active']>=3 and row['mode']=='fixed_zero_rho' else 0
    assert row['matching_failures']==row['independent_failures']==expected
import numpy as np
report={'status':'PASS','scope':'Article 4 only','python':sys.version,'numpy':np.__version__,
        'started_ns':start,'finished_ns':time.time_ns(),'foreign_cwd':True,
        'clean_source_copy_had_no_json':True,'all_outputs_generated_during_current_run':True,
        'other_article_scripts_run':False,'machine_checked_security_proof':False,
        'records':records,'fft_integer_products_checked':o['protocol']['fft_products_checked_against_integer']}
(root/'FRESH_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
