#!/usr/bin/env python3
"""Independent fixed-tape controls for Article 4 V3.
Uses integer negacyclic convolution. EXPERIMENTAL only; no security claim.
"""
from pathlib import Path
import numpy as np, json
P=4096; N=256; K=4
rng=np.random.default_rng(2026111302)
def cbd(shape): return rng.integers(0,2,shape,dtype=np.int64)-rng.integers(0,2,shape,dtype=np.int64)
def mul(a,b):
    c=np.convolve(np.asarray(a,dtype=np.int64),np.asarray(b,dtype=np.int64)); v=c[:N].copy(); v[:N-1]-=c[N:]; return v
def keygen():
    A=rng.integers(0,P,(K,K,N),dtype=np.int64); s=cbd((K,N)); e=cbd((K,N))
    y=np.stack([sum((mul(A[i,j],s[j]) for j in range(K)),start=np.zeros(N,dtype=np.int64)) for i in range(K)])+e
    return A,s,e,y%4,(y%P)//4
def failure(key,tape,mu):
    A,s,e,r0,b=key; r,e1,e2,rho=tape
    Ar=np.stack([sum((mul(A[i,j],r[i]) for i in range(K)),start=np.zeros(N,dtype=np.int64)) for j in range(K)])
    c1=((Ar+e1)%P)//2; r1=(Ar+e1)%2; v=4*b+rho
    y=sum((mul(v[j],r[j]) for j in range(K)),start=np.zeros(N,dtype=np.int64))+e2+2048*mu
    c2=(y%P)//2; r2=y%2
    z=(2*c2-sum((mul(2*c1[j],s[j]) for j in range(K)),start=np.zeros(N,dtype=np.int64)))%P
    eps=sum((mul(e[j]+rho[j]-r0[j],r[j])+mul(r1[j]-e1[j],s[j]) for j in range(K)),start=np.zeros(N,dtype=np.int64))+e2-r2
    assert np.array_equal(z,(2048*mu+eps)%P)
    decoded=((z>1024)&(z<3072)).astype(np.int64)
    return bool(np.any(decoded!=mu))
zero=np.zeros(N,dtype=np.int64); zero4=np.zeros((K,N),dtype=np.int64); rows=[]
for active in (2,3,4):
    r=zero4.copy(); r[:active]=1
    for mode in ('fixed_zero_rho','fresh_uniform_rho'):
        counts=[0,0]; trials=128
        for _ in range(trials):
            k0=keygen(); k1=keygen(); rho=zero4.copy() if mode=='fixed_zero_rho' else rng.integers(0,4,(K,N),dtype=np.int64)
            tape=(r,zero4,zero,rho); counts[0]+=failure(k0,tape,zero); counts[1]+=failure(k1,tape,zero)
        rows.append({'active':active,'mode':mode,'trials':trials,'matching_failures':counts[0],'independent_failures':counts[1],'empirical_probability_gap':abs(counts[0]-counts[1])/trials})
out={'seed':2026111302,'message':'all-zero 256-coefficient vector','e1':'all zero','e2':'all zero','r':'first active module polynomials all-one; remaining module polynomials zero','rho_modes':{'fixed_zero_rho':'all lift coefficients fixed zero','fresh_uniform_rho':'all lift coefficients resampled uniformly in {0,1,2,3} per trial'},'convolution':'exact integer negacyclic convolution via numpy.convolve','rows':rows,'classification':'EXPERIMENTAL; no security claim'}
print(json.dumps(out,indent=2))
(Path(__file__).resolve().parent/'INDEPENDENT_FIXED_TAPE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
