# Article 4 — scoped closure V4.4

Read `ARTICLE4_REVISED_V4.md` and `ARTICLE4_CLOSURE_REPORT_V4_4.md`.
This is a probabilistic analysis and partial FFP study. The specialized FFP-NG
reduction and PQ-128 certification remain open. Article 2 V4.2 already gives a
separate conservative conditional QROM composition; it does not use the second
moment or require an FFP-NG reduction. Its model restrictions remain essential.

With Python 3 and NumPy:

```bash
python run_clean_checks.py
```

The delivered run used Python 3.12.14 and NumPy 2.3.5. Six current scripts are
copied to a clean temporary source tree, with no old result JSON. Every output
is generated during the run, from a foreign working directory, and written next
to its script. Reference snapshots are compared explicitly after computation.
The two independently enumerated rational certificates and all budget columns
are cross-checked. Logs and `FRESH_CHECKS.json` describe the actual fresh run.

The script `certificates/ffp_nk_budget_v3.py` and its JSON retain legacy filenames
for compatibility with the earlier aggregate verifier; their content is V4.4
and uses the corrected finite-query threshold. Use this standalone runner for
the current Article 4 checks. Older aggregate reports retain historical scope.

Original experiments and independent controls remain separate. The original FFT
implementation is now checked product by product against integer convolution.
The controls use integer products and actual encryption/decryption. Structured
tapes are selected examples, not samples from the honest encryption distribution.
No zero count or empirical marginal gap is interpreted as a security bound.

`dependencies/` contains exact unchanged Article 1 V4.1 and Article 2 V4.2 texts.
`provenance/` contains the entire preceding Article 4 supplement and text diff.
Historical scripts/results there are never used by the current runner. The old
scripts retain their old output-path behavior and old budget diagnostics.

The manifest describes delivery bytes, excluding itself. A later run updates
timestamped execution reports, so its hashes need not match the delivery manifest.
The finite checks do not machine-verify the full mathematical or QROM proofs.
