# Claim ledger — Article 4 V4.4

- PROVED in the exact stated distribution: honest error identity and containment.
- PROVED using Article 1 V4.1: delta_ik <= delta_wc < 2^-212.
- PROVED here: same-tape/two-independent-key second moment < 2^-247;
  sigma_deltaik < 2^-123.5. Explicit conditioning precedes final factorization.
- EXACTLY REPRODUCED: rational A2, B2, C2 and strict integer comparison.
- PROVED using the cited eQROM search lemma: exact threshold and integrated
  mean-only bounds; direct min(1,152(q+1)^2 delta_wc) under the NK game model.
- DIAGNOSTIC ONLY: the single leading variance summand; not a full bound.
- EXPERIMENTAL: selected bad tapes and the four 128-pair NG-like rules.
- NOT INFERRED: negligible true failure or true NG advantage from zero counts.
- ALREADY IN ARTICLE 2 V4.2: separately proved conservative conditional QROM
  composition, in its expressly limited model. Not newly audited here.
- OPEN: exact C1-K4 specialization of the newer FFP-NG theorem, sharper
  composition through it, practical NG attacks, and concrete PQ-128 certification.
- REVIEW: internal scoped mathematical closure, not independent peer review.
