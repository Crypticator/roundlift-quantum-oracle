# Experiments — Article 4 V4.4

## Original series, seed 20261113

`original_experiments/ffp_structured_tape_experiment.py` uses the zero message.
Three family rows have 2, 3 or 4 all-one components in r, zero active lift
coordinates, fresh e1/e2 and fresh non-active lift coordinates. Each uses 128
fresh keys and tapes: these are families, not complete fixed tapes.
The four public-key-dependent rules are signb, parityb, threshold, difference.
Each uses 128 fresh pairs, the same pk0-derived tape under both keys, and
e1=e2=rho=0. All four have zero observed failures in both arms. The empirical
statistic is abs(f0-f1)/(2*128); it is not a security upper bound for general
view-dependent guessing. There is no fifth sparse-selection search.

The FFT code retains its arithmetic path and random draw order. Every product
is now asserted equal to integer negacyclic convolution: 61,952 comparisons in
the delivered run. Coefficients and product sums stay within int64 for all these
inputs. Only output placement and verification/metadata were changed.

## Independent integer controls, seed 2026111302

`independent_controls/ffp_independent_fixed_tape_controls.py` uses the zero
message, e1=e2=0, and 2, 3 or 4 all-one r components. Each is tested with a
complete fixed zero lift and with fresh uniform lifts, 128 pairs per row.
Both keys in each pair see exactly the same tape. The tape is key-independent,
so the historical label matching_failures just denotes the first arm.
The script checks the decryption identity against the error expression.

## Additional exact-geometry controls, seed 2026111304

`certificates/verify_full_geometry.py` tests 24 full parameter key/tape cases,
each with zero, one and random message vectors: 72 encryptions/decryptions.
Random and deliberately extreme tapes are mixed; counts are not estimates
under the honest tape law. It also checks a simple cancellation example showing
why a marginal NG gap does not upper-bound view-dependent distinguishing.

## Interpretation

No pooling of these series. No measurement of 2^-212 or 2^-247 by Monte Carlo.
Seeds identify reproducible synthetic experiments, not production cryptographic
randomness. All current outputs were regenerated in the clean run. Historical
results and unmodified old scripts remain only under provenance/.
