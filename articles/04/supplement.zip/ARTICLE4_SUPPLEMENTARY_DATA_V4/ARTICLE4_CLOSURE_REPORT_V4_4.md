# Article 4 — Rapport de fermeture V4.4

**13 novembre 2026 — Samir Bouftass et ChatGPT (OpenAI)**

## Verdict et périmètre

**TAMPON INTERNE ACCORDÉ — résultats de probabilité et analyse FFP partielle, dans les modèles explicitement définis.**

Le second moment est conservé, avec une preuve détaillée et un certificat rationnel reproduit. La borne à seuil est corrigée pour un nombre fini de requêtes. La portée des expériences et la cohérence avec l'article 2 V4.2 sont clarifiées. Aucun paramètre cryptographique n'est changé.

Ce verdict ne signifie ni réduction FFP-NG spécialisée achevée, ni certification PQ-128, ni évaluation indépendante par un comité externe. L'éditeur et le vérificateur de cette révision sont le même assistant. Les bornes reposant sur le lemme quantique publié sont conditionnelles au modèle de ce lemme ; le code ne formalise pas sa preuve.

## Corpus et intégrité

Base : `THESIS_II_CORRECTED_ARTICLES_V4_2026-11-13.zip`, état après fermeture de l'article 3 V4.3, SHA-256 :

`bfe9e071b72bd1d7a5a01eec0197c755b8685b32a242738c383540ecae5f1d10`.

Le texte révisé est `ARTICLE4_REVISED_V4.md`, dont l'en-tête indique **V4.4**. Les anciennes versions restent des pièces de provenance. Les manuscrits et suppléments des articles 1 V4.1, 2 V4.2 et 3 V4.3 sont conservés byte pour byte. Leurs tests ne sont pas relancés et aucun nouveau tampon ne leur est attribué ici.

## Réserves et corrections

| Point | Classe | Avant | Correction vérifiée | Statut |
|---|---|---|---|---|
| A4-01 — conditionnement du second moment | M | La phrase de factorisation pouvait laisser croire qu'on moyennait déjà les secrets avant d'éliminer la dépendance des restes. | Les facteurs intermédiaires restent des fonctions des coefficients secrets ; ordre explicite : reste final, erreur de chiffrement, paire éphémère/lift, puis secrets et erreurs de génération. Permutations et signes négacycliques écrits. | CLOSED |
| A4-02 — certificat exact | m | Valeurs rationnelles présentes, logarithme approché. | Seconde énumération par bits indépendants ; comparaison entière stricte avec (2^{-247}) ; le logarithme ne décide pas le certificat. | CLOSED |
| A4-03 — borne à seuil | M | (2q\sqrt{304\delta_{ik}}) présenté comme diagnostic valide, sans compte exact de la dernière requête. | Avec (a=152(q+1)^2\delta_{ik}), borne (2\sqrt a-a) pour (0<a<1), cas limites et borne intégrée explicités. | CLOSED |
| A4-04 — moyen / pire message / variance | M | Portée des paramètres et du terme de variance insuffisamment délimitée. | Définitions avec emplacement du maximum, distinction variance/écart type, summand de variance séparé d'une borne complète. Borne directe via (\delta_{wc}) démontrée dans le jeu NK. | CLOSED |
| A4-05 — synchronisation QROM | M | Toute la composition figurait encore parmi les obligations ouvertes. | Renvoi à la composition conditionnelle conservatrice de l'article 2 V4.2, qui ne requiert pas FFP-NG. Seule la voie plus fine reste ouverte ici. | CLOSED |
| A4-06 — sens des expériences | M | Phrases générales sur les familles et « absence d'avantage », sans tous les comptes. | Tableau des comptes ; quatre règles exactement identifiées ; couples de clés, message zéro, tape fixé ou famille distingués. L'écart marginal divisé par deux ne borne pas un distingueur exploitant toute sa vue publique. | CLOSED |
| A4-07 — reproductibilité | M | Deux scripts écrivaient dans le répertoire appelant ; absence de lanceur autonome neuf propre à l'article 4. | Sorties relatives aux sources, copie propre sans JSON, contrôle des dates, journaux et empreintes. Chaque produit FFT est comparé au produit entier. | CLOSED |
| A4-08 — références et conventions | m | Jeu NG seulement décrit informellement ; références de versions anciennes. | Jeu à une requête et normalisation du biais explicités ; bibliographie actuelle ; copies inchangées des articles 1 et 2 comme dépendances. | CLOSED |

Aucune nouvelle erreur bloquante n'a été identifiée dans ce périmètre. Les contrôles finis étayent les calculs mais ne remplacent pas les preuves générales écrites.

## Résultats mathématiques retenus

Pour tout message fixé, sous la loi honnête des tapes :

\[
\mathbb E_\omega[p_m(\omega)^2]<2^{-247},
\qquad \sigma_{\delta ik}<2^{-123.5}.
\]

À (u=6/5), les trois facteurs sont exactement :

\[
A_2=\frac{99036386572201}{83980800000000},\quad
B_2=\frac{489677}{480000},\quad
C_2=\frac{3721}{2500}.
\]

Le logarithme de la borne rationnelle est environ (-247.02484164476834). La preuve ne suppose pas l'indépendance de deux blocs qui utilisent les mêmes restes cachés. Cauchy–Schwarz traite les sorties distinctes ; la factorisation n'est utilisée qu'après élimination des dépendances dans le cas diagonal.

La borne intégrée reste valide. La borne conservatrice directe supplémentaire est :

\[
\operatorname{Adv}^{\mathrm{FFP\text{-}NK}}
\le\min\{1,152(q+1)^2\delta_{wc}\}.
\]

Le paramètre est bien (\delta_{wc}=\mathbb E_K\max_m\Pr_\omega(F\mid K,m)), et non (\delta_{ik}=\max_m\mathbb E_K\Pr_\omega(F\mid K,m)). La clé cible du jeu NK est indépendante et cachée. Les valeurs numériques associées sont des logarithmes de bornes de probabilité dans ce jeu, pas des bits de sécurité du KEM.

## Vérifications effectivement exécutées

Commande depuis le supplément décompressé :

```bash
python run_clean_checks.py
```

Environnement du passage livré : Python 3.12.14, NumPy 2.3.5.

Les six scripts sont copiés dans un répertoire temporaire sans aucun JSON de résultat et exécutés depuis un répertoire de travail étranger. Chaque sortie doit être créée pendant l'exécution courante. Les résultats anciens ne servent que de comparaisons explicites, jamais d'entrées aux calculs. Les scripts écrivent à côté de leurs sources. Le lanceur et les empreintes sont livrés.

- Certificat initial reproduit, avec sortie rendue portable.
- Énumération indépendante des facteurs en arithmétique rationnelle ; 32 768 évaluations clé/tape dans l'analogue scalaire (P=8,n=k=1), avec multiplicité des bits CBD ; contrôle des deux messages, de la géométrie exacte et des moments diagonaux.
- 289 permutations signées vérifiées, incluant toutes les sorties de dimension 256 ; loi induite par les octets et deux valeurs limites du décodage contrôlées.
- 72 chiffrements/déchiffrements complets aux paramètres (n=256,k=4,P=4096), avec messages zéro, un et aléatoires ; identité d'erreur et inclusion de l'échec dans l'événement majorant vérifiées.
- Expériences initiales reproduites : trois familles de tapes et quatre stratégies dépendant de la clé publique, 128 essais chacune ; **61 952 produits FFT** vérifiés individuellement contre la convolution entière.
- Contrôles à tape fixé ou lift resamplé reproduits : six lignes, 128 paires de clés par ligne, soit 1 536 déchiffrements.
- Budgets recalculés, avec la correction à seuil et la borne directe ; comparaison avec l'évaluation indépendante à 90 chiffres décimaux pour les valeurs tabulées.

La petite énumération scalaire ne prouve pas le théorème en dimension 256. Les expériences choisies ne mesurent pas une probabilité honnête de l'ordre de (2^{-212}). NumPy sert aux expériences synthétiques, pas à générer des clés de production.

## Questions qui restent ouvertes

| Question | Statut | Conséquence |
|---|---|---|
| Adapter exactement le résultat FFP-NG de Majenz–Sisinni à C1-K4 | OPEN | La lecture de l'abstract confirme la pertinence CBD / Ring / Module ; aucune instanciation du théorème complet n'est revendiquée. |
| Obtenir une composition plus fine exploitant cette réduction | OPEN | Distinct de la voie conservatrice déjà établie dans l'article 2 V4.2. |
| Trouver une attaque FFP-NG pratique | OPEN | Les quatre tests élémentaires ne l'excluent pas. |
| Certifier PQ-128 avec ressources et hypothèses concrètes | OPEN | Aucun tampon de certification cryptographique. |

Ces questions sont des limites expressément conservées, pas des résultats supposés acquis pour fermer l'article.

## Livraison et portée du tampon

Le supplément contient le manuscrit, ce rapport, les scripts, sorties fraîches, journaux, sources de provenance, différences et manifeste SHA-256. Il contient également les deux manuscrits de dépendance, inchangés. Le manuscrit autonome, celui du supplément et celui du dossier général sont byte-identiques.

**Conclusion : fermeture interne accordée pour cet article de résultats probabilistes et d'analyse FFP partielle. La borne du second moment reste valable ; la portée cryptographique annoncée correspond désormais aux preuves disponibles.**
