#!/usr/bin/env python3
from fractions import Fraction
import itertools, math, json
from pathlib import Path

CBD={-1:Fraction(1,4),0:Fraction(1,2),1:Fraction(1,4)}
N=256
K=4
P=4096
Q=4
C=2
u=Fraction(6,5)

def A2():
    best=Fraction(0)
    detail={}
    for a1,a2 in itertools.product((-1,1),repeat=2):
        total=Fraction(0)
        for E1,E2 in itertools.product(CBD, repeat=2):
            pE=CBD[E1]*CBD[E2]
            m=None
            for t1,t2 in itertools.product(range(Q),repeat=2):
                v=Fraction(0)
                for R in CBD:
                    for T in range(Q):
                        exponent=R*(a1*(E1+T-t1)+a2*(E2+T-t2))
                        v += CBD[R]*Fraction(1,Q)*(u**exponent)
                m=v if m is None or v>m else m
            total += pE*m
        detail[(a1,a2)]=total
        best=max(best,total)
    return best,detail

def B2():
    best=Fraction(0)
    detail={}
    for a1,a2 in itertools.product((-1,1),repeat=2):
        total=Fraction(0)
        for S1,S2 in itertools.product(CBD,repeat=2):
            pS=CBD[S1]*CBD[S2]
            m=None
            for c1,c2 in itertools.product(range(C),repeat=2):
                v=Fraction(0)
                for E in CBD:
                    d1=((c1+E)%C)-E
                    d2=((c2+E)%C)-E
                    exponent=a1*S1*d1+a2*S2*d2
                    v += CBD[E]*(u**exponent)
                m=v if m is None or v>m else m
            total += pS*m
        detail[(a1,a2)]=total
        best=max(best,total)
    return best,detail

def C2():
    best=Fraction(0)
    detail={}
    for a1,a2 in itertools.product((-1,1),repeat=2):
        v=Fraction(0)
        for E in CBD:
            m=max(
                u**(a1*(E-t1)+a2*(E-t2))
                for t1,t2 in itertools.product(range(C),repeat=2)
            )
            v += CBD[E]*m
        detail[(a1,a2)]=v
        best=max(best,v)
    return best,detail

a,da=A2()
b,db=B2()
c,dc=C2()

bound=Fraction(4)*(N**2)*(a*b)**(K*N)*c*u**(-(P//2))
cert_247=(2**247)*bound.numerator < bound.denominator
log2_bound=math.log2(bound.numerator)-math.log2(bound.denominator)

out={
  "u":"6/5",
  "A2":f"{a.numerator}/{a.denominator}",
  "B2":f"{b.numerator}/{b.denominator}",
  "C2":f"{c.numerator}/{c.denominator}",
  "log2_second_moment_upper":log2_bound,
  "certified_less_than_2^-247":cert_247,
  "sigma_log2_upper":log2_bound/2,
  "claim":"E_tape[p_m(tape)^2] < 2^-247, hence sigma_deltaik < 2^-123.5"
}
print(json.dumps(out,indent=2))
with (Path(__file__).resolve().parent/"SECOND_MOMENT_RESULTS.json").open("w") as f:
    json.dump(out,f,indent=2)
assert cert_247
