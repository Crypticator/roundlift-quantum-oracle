#!/usr/bin/env python3
"""Independent exact checks, not a machine-checked QROM proof."""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

U=F(6,5)
coin=[a-b for a,b in product((0,1),repeat=2)]
law=Counter(coin)
powu={i:U**i for i in range(-32,33)}
def avg(v):
    v=list(v)
    return sum(v,F(0))/len(v)
def factor_values():
    result=[]
    for a,b in product((-1,1),repeat=2):
        aa=avg(max(avg(powu[r*(a*(e+t-h)+b*(ep+t-hp))]
                       for r,t in product(coin,range(4)))
                   for h,hp in product(range(4),repeat=2))
               for e,ep in product(coin,repeat=2))
        bb=avg(max(avg(powu[a*s*((c+e)%2-e)+b*sp*((cp+e)%2-e)] for e in coin)
                   for c,cp in product(range(2),repeat=2))
               for s,sp in product(coin,repeat=2))
        cc=avg(max(powu[a*(e-h)+b*(e-hp)] for h,hp in product(range(2),repeat=2)) for e in coin)
        result.append({'signs':[a,b],'A':str(aa),'B':str(bb),'C':str(cc)})
    return result

details=factor_values()
A=max(F(r['A']) for r in details)
B=max(F(r['B']) for r in details)
C=max(F(r['C']) for r in details)
assert (A,B,C)==(F(99036386572201,83980800000000),F(489677,480000),F(3721,2500))
bound=4*256**2*(A*B)**1024*C*U**-2048
assert bound.numerator*2**247 < bound.denominator

# Independently enumerate the whole scalar analogue: P=8, Q=4, C=2,
# n=k=1, A uniform in Z_8. Coin multiplicities are retained explicitly.
# This validates dependence/order on a finite model; the 256-dimensional
# theorem follows from the written proof, not this small exhaustive check.
diagonal={-1:F(0),1:F(0)}
mean=[F(0),F(0)]; second=[F(0),F(0)]
cases=0
for r,e1,e2,rho in product(coin,coin,coin,range(4)):
    g={-1:F(0),1:F(0)}; failures=[0,0]
    for mat,s,e0 in product(range(8),coin,coin):
        y=(mat*s+e0)%8; r0=y%4; b=y//4
        c1=((mat*r+e1)%8)//2; r1=(mat*r+e1)%2
        r2=((4*b+rho)*r+e2)%2
        eps=(e0+rho-r0)*r+(r1-e1)*s+e2-r2
        for sign in (-1,1):g[sign]+=powu[sign*eps]/128
        for m in (0,1):
            c2=(((4*b+rho)*r+e2+4*m)%8)//2
            z=(2*c2-2*c1*s)%8
            assert z==(4*m+eps)%8
            f=int(int(2<z<6)!=m)
            assert not f or abs(eps)>=2
            failures[m]+=f
        cases+=1
    for sign in (-1,1):diagonal[sign]+=g[sign]**2/256
    for m in (0,1):
        p=F(failures[m],128)
        mean[m]+=p/256; second[m]+=p*p/256
assert all(d<=A*B*C for d in diagonal.values())
assert all(mean[m]**2<=second[m]<=mean[m] for m in (0,1))

# Signed permutations are valid for every index, including wraparound.
permutations=0
for n in (1,2,3,4,7,16,256):
    for i in range(n):
        pi=[(i-j)%n for j in range(n)]
        assert sorted(pi)==list(range(n))
        for j in range(n):
            exp=pi[j]+j
            assert exp%n==i
            assert (1 if j<=i else -1)==(1 if exp<n else -1)
        permutations+=1

# Raw-byte pushforward of the exact tape map, including ignored bits.
assert Counter((x&1)-((x>>1)&1) for x in range(256))=={-1:64,0:128,1:64}
assert set(Counter((x&3,(x>>4)&3) for x in range(256)).values())=={16}
assert len(Counter((x&3,(x>>4)&3) for x in range(256)))==16

rows=[]
with localcontext() as ctx:
    ctx.prec=90
    d=Decimal(2)**-212
    def bits(x): return float(-x.ln()/Decimal(2).ln())
    def integrated(a):
        if a==0:return Decimal(0)
        if a>=1:return Decimal(1)
        return a*(1-a.ln())
    assert integrated(Decimal(0))==0 and integrated(Decimal(1))==1
    assert integrated(Decimal(2))==1
    for qlog in (0,16,32,64):
        q=2**qlog; D=152*(q+1)**2; a=Decimal(D)*d
        single=2*a.sqrt()-a; integ=integrated(a); direct=min(Decimal(1),a)
        assert 0<direct<=integ<=single<1
        assert single>=a # even the single-threshold bound has the final query
        rows.append({'q_log2':qlog,'D_q':str(D),
                     'single_threshold_bits':bits(single),
                     'integrated_mean_bits':bits(integ),
                     'direct_delta_wc_bits':bits(direct),
                     'variance_leading_summand_bits':bits(3*(Decimal(304*q)*Decimal(2)**Decimal('-123.5')).sqrt())})
    logarithm=float((Decimal(bound.numerator).ln()-Decimal(bound.denominator).ln())/Decimal(2).ln())

# Decoder ties: both ties output zero, hence a failed one and a successful zero.
ties=[]
for mu in (0,1):
    for eps in (-1024,1024):
        z=(2048*mu+eps)%4096
        decoded=int(1024<z<3072)
        assert decoded==0 and ((decoded!=mu)==bool(mu))
        ties.append({'mu':mu,'eps':eps,'z':z,'failure':bool(decoded!=mu)})

out={'status':'PASS','factors_by_sign':details,'A2':str(A),'B2':str(B),'C2':str(C),
     'second_moment_log2':logarithm,'strict_integer_certificate_below_2^-247':True,
     'scalar_full_model':{'parameters':'P=8,Q=4,C=2,n=k=1','key_tape_evaluations_with_coin_multiplicity':cases,
        'diagonal_moments':{str(s):str(v) for s,v in diagonal.items()},
        'diagonal_bound':str(A*B*C),'mean':[str(x) for x in mean],'second_moment':[str(x) for x in second]},
     'signed_permutations_checked':permutations,'uniform_byte_pushforward_checked':True,
     'query_budget_rows':rows,'decoder_ties':ties,
     'scope':'exact finite checks and rational certificate; not a machine-checked proof of the QROM lemma or full security'}
target=Path(__file__).resolve().parent/'ARTICLE4_EXACT_CHECKS.json'
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
