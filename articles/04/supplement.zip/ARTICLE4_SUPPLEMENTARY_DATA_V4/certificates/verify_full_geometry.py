#!/usr/bin/env python3
"""Full dimension integer checks of the exact C1-K4 error identity."""
import json
from pathlib import Path
import numpy as np

N=256; K=4; P=4096
rng=np.random.default_rng(2026111304)
def cbd(shape): return rng.integers(0,2,shape,dtype=np.int64)-rng.integers(0,2,shape,dtype=np.int64)
def mul(a,b):
    c=np.convolve(a,b); v=c[:N].copy(); v[:-1]-=c[N:]; return v
def dot(a,b): return sum((mul(x,y) for x,y in zip(a,b)),start=np.zeros(N,dtype=np.int64))
checks=failures=0
for case in range(24):
    A=rng.integers(0,P,(K,K,N),dtype=np.int64)
    s=cbd((K,N)); e0=cbd((K,N))
    r=cbd((K,N)); e1=cbd((K,N)); e2=cbd(N); rho=rng.integers(0,4,(K,N),dtype=np.int64)
    if case%4==1:
        r[:3]=1; r[3]=0; rho[:]=0; e1[:]=0; e2[:]=0
    if case%4==2:
        r[:]=np.where(np.arange(N)%2,1,-1); rho[:]=3
    if case%4==3:
        s[:]=0; e0[:]=-1; r[:3]=1; r[3]=0; e1[:]=0; e2[:]=0; rho[:]=0
    As=np.stack([dot(A[i],s) for i in range(K)])
    b=((As+e0)%P)//4; r0=(As+e0)%4
    Ar=np.stack([dot(A[:,j],r) for j in range(K)])
    c1=((Ar+e1)%P)//2; r1=(Ar+e1)%2; v=4*b+rho
    before=dot(v,r)+e2
    eps=dot(e0+rho-r0,r)+dot(r1-e1,s)+e2-before%2
    for mu in (np.zeros(N,dtype=np.int64),np.ones(N,dtype=np.int64),rng.integers(0,2,N,dtype=np.int64)):
        c2=((before+2048*mu)%P)//2
        assert np.array_equal((before+2048*mu)%2,before%2)
        z=(2*c2-dot(2*c1,s))%P
        assert np.array_equal(z,(2048*mu+eps)%P)
        decoded=((z>1024)&(z<3072)).astype(np.int64)
        f=bool(np.any(decoded!=mu)); failures+=f
        assert not f or np.max(np.abs(eps))>=1024
        checks+=1

# A zero marginal NG statistic need not bound a view-dependent distinguisher.
# For two equally likely public views the conditional gaps can be +1 and -1.
conditional_gaps=[1,-1]
assert abs(sum(conditional_gaps)/2)/2==0
assert sum(abs(x) for x in conditional_gaps)/2/2==0.5
out={'status':'PASS','seed':2026111304,'parameter_set':'P4096,n256,k4,Q4,C2',
     'complete_encryption_decryption_checks':checks,'observed_failures_in_deliberately_mixed_controls':failures,
     'message_patterns':['zero','one','fresh bits'],'integer_convolution':True,
     'ng_marginal_statistic_is_not_general_advantage_bound':True,
     'scope':'identity and containment checks on chosen cases, not statistical security estimates'}
(Path(__file__).resolve().parent/'FULL_GEOMETRY_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
