# Sources and theorem use — Article 4 V4.4

1. Article 1, V4.1, Sections 3–5 / Corollary 4: exact construction, tape mapping,
   failure identity and averaged worst-message bound. Unchanged dependency copy.
2. Article 2, V4.2, Theorem 4: conservative conditional QROM composition in the
   single-user, key-first, fresh-independent-oracle model. Unchanged dependency.
3. Hoevelmanns, Huelsing, Majenz, *Failing Gracefully*, ASIACRYPT 2022,
   DOI https://doi.org/10.1007/978-3-031-22972-5_15.
   Full primary version: https://arxiv.org/abs/2203.10182v1
   Figure 15 / Theorem 10: NK and one-query NG games and their advantage units.
   Definition 5: delta_ik, sigma and distinction from averaged delta_wc.
   Lemma 5, Eq. (51), p. 34: extractable-oracle search bound 152(q+1)^2 times
   maximum relation density, final evaluation included. The published version
   renumbers this as Lemma 4, Eq. (30), p. 439. Theorem 11's variance summand
   is evaluated only as a diagnostic, not as a complete bound.
4. Majenz, Sisinni, *Provable decryption failure security for practical
   lattice-based PKE*, ePrint 2025/1997, preprint.
   https://eprint.iacr.org/2025/1997
   The primary public abstract, checked on 13 November 2026, covers Ring/Module
   LWE and a subgaussian family including centered binomials. This update uses
   only the abstract for scope; the full theorem was not instantiated for C1-K4.

No external scientific paper is redistributed in this supplement. The second
moment proof and its rational certificate are stated directly in the manuscript;
prior audit reports are not used as proof authorities.
